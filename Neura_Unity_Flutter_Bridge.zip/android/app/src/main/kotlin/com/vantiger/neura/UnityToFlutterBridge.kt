package com.vantiger.neura

import io.flutter.plugin.common.MethodChannel

/**
 * Minimal static bridge used by Unity (AndroidJavaClass) to emit JSON to Flutter.
 *
 * Unity calls:
 *   UnityToFlutterBridge.emitToFlutter("{...}")
 *
 * Flutter receives on MethodChannel "neura/unity_events" method "onUnityEvent".
 */
object UnityToFlutterBridge {
    private var eventChannel: MethodChannel? = null

    fun attach(channel: MethodChannel) {
        eventChannel = channel
    }

    @JvmStatic
    fun emitToFlutter(jsonLine: String) {
        eventChannel?.invokeMethod("onUnityEvent", jsonLine)
    }
}
