using System;
using System.Collections.Concurrent;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using UnityEngine;

/// <summary>
/// Windows-friendly TCP bridge (Unity listens, Flutter connects).
/// Messages are JSON lines separated by '\n'.
/// </summary>
public class TcpBridgeServer : MonoBehaviour
{
    [Header("Bridge")]
    public int port = 49152;
    public bool autoStart = true;

    private TcpListener _listener;
    private TcpClient _client;
    private StreamReader _reader;
    private StreamWriter _writer;
    private Thread _thread;

    private readonly ConcurrentQueue<string> _inbound = new();
    private readonly ConcurrentQueue<string> _outbound = new();

    void Start()
    {
        if (autoStart) StartServer();
    }

    void OnDestroy()
    {
        StopServer();
    }

    public void StartServer()
    {
        if (_thread != null) return;

        _listener = new TcpListener(IPAddress.Loopback, port);
        _listener.Start();

        _thread = new Thread(AcceptLoop) { IsBackground = true };
        _thread.Start();

        Debug.Log($"[NeuraBridge] TCP server listening on 127.0.0.1:{port}");
    }

    public void StopServer()
    {
        try { _client?.Close(); } catch { }
        try { _listener?.Stop(); } catch { }
        try { _thread?.Interrupt(); } catch { }
        _thread = null;
    }

    private void AcceptLoop()
    {
        while (true)
        {
            try
            {
                _client = _listener.AcceptTcpClient();
                var stream = _client.GetStream();
                _reader = new StreamReader(stream, Encoding.UTF8);
                _writer = new StreamWriter(stream, Encoding.UTF8) { AutoFlush = true };

                Debug.Log("[NeuraBridge] Client connected.");

                string line;
                while ((line = _reader.ReadLine()) != null)
                {
                    if (!string.IsNullOrWhiteSpace(line))
                        _inbound.Enqueue(line);
                }

                Debug.Log("[NeuraBridge] Client disconnected.");
            }
            catch (ThreadInterruptedException) { return; }
            catch (Exception ex)
            {
                Debug.LogWarning($"[NeuraBridge] AcceptLoop error: {ex.Message}");
                Thread.Sleep(500);
            }
        }
    }

    void Update()
    {
        while (_inbound.TryDequeue(out var msg))
        {
            BridgeRouter.Instance?.HandleFromFlutter(msg);
        }

        while (_outbound.TryDequeue(out var msg))
        {
            try { _writer?.WriteLine(msg); }
            catch { /* client may be gone */ }
        }
    }

    public void SendToFlutter(string jsonLine)
    {
        _outbound.Enqueue(jsonLine);
    }
}
