using UnityEngine;

/// <summary>
/// Android return-channel: Unity -> Android (Kotlin) -> Flutter.
/// Requires Android plugin class `com.vantiger.neura.UnityToFlutterBridge`.
/// </summary>
public static class UnityAndroidEmitter
{
#if UNITY_ANDROID && !UNITY_EDITOR
    private static AndroidJavaClass _bridge;
#endif

    public static void Emit(string jsonLine)
    {
        if (string.IsNullOrWhiteSpace(jsonLine)) return;

#if UNITY_ANDROID && !UNITY_EDITOR
        try
        {
            _bridge ??= new AndroidJavaClass("com.vantiger.neura.UnityToFlutterBridge");
            _bridge.CallStatic("emitToFlutter", jsonLine);
        }
        catch (System.Exception e)
        {
            Debug.LogWarning("[UnityAndroidEmitter] Failed: " + e.Message);
        }
#else
        Debug.Log("[UnityAndroidEmitter] (editor/no-android) " + jsonLine);
#endif
    }
}
