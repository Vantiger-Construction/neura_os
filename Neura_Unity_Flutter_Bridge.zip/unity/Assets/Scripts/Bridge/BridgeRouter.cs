using System;
using UnityEngine;

/// <summary>
/// Minimal router. Parses a tiny JSON subset without dependencies.
/// Upgrade later to proper JSON parsing (Newtonsoft or a small parser).
/// </summary>
public class BridgeRouter : MonoBehaviour
{
    public static BridgeRouter Instance { get; private set; }

    [Header("Refs")]
    [SerializeField] private TcpBridgeServer tcp;
    [SerializeField] private NeuraController neura;
    [SerializeField] private WorldManager world;

    void Awake()
    {
        if (Instance != null) { Destroy(gameObject); return; }
        Instance = this;
        DontDestroyOnLoad(gameObject);
    }

    public void HandleFromFlutter(string jsonLine)
    {
        if (string.IsNullOrWhiteSpace(jsonLine)) return;
        Debug.Log($"[NeuraBridge] <= {jsonLine}");

        if (jsonLine.Contains("\"type\":\"SET_STATE\""))
        {
            var mood = Extract(jsonLine, "mood");
            var room = Extract(jsonLine, "room");
            var energyStr = Extract(jsonLine, "energy");

            if (!string.IsNullOrEmpty(mood)) neura.SetMood(mood);
            if (!string.IsNullOrEmpty(energyStr) && float.TryParse(energyStr, out var e)) neura.SetEnergy(e);
            if (!string.IsNullOrEmpty(room)) world.GoToRoom(room);

            return;
        }

        if (jsonLine.Contains("\"type\":\"ACTION\""))
        {
            var action = Extract(jsonLine, "action");
            var value = Extract(jsonLine, "value");

            if (action == "PLAY_ANIM") neura.PlayAnim(value);
            else if (action == "GO_TO_ROOM") world.GoToRoom(value);
            else if (action == "LOOK_AT") neura.LookAtTargetName(value);
            else Debug.Log($"[NeuraBridge] Unknown action: {action}");

            return;
        }

        Debug.Log($"[NeuraBridge] Unhandled: {jsonLine}");
    }

    // Tiny extractor for string/number fields (good enough for v0)
    private string Extract(string json, string key)
    {
        var token = $"\"{key}\":";
        var idx = json.IndexOf(token, StringComparison.OrdinalIgnoreCase);
        if (idx < 0) return null;
        idx += token.Length;

        while (idx < json.Length && json[idx] == ' ') idx++;

        if (idx < json.Length && json[idx] == '"')
        {
            idx++;
            var end = json.IndexOf('"', idx);
            if (end < 0) return null;
            return json.Substring(idx, end - idx);
        }
        else
        {
            var end = json.IndexOfAny(new[] { ',', '}' }, idx);
            if (end < 0) end = json.Length;
            return json.Substring(idx, end - idx).Trim();
        }
    }

    public void EmitEvent(string eventName, string value)
    {
        var msg = $"{{\"type\":\"EVENT\",\"event\":\"{eventName}\",\"value\":\"{value}\"}}";
        Debug.Log($"[NeuraBridge] => {msg}");
        tcp?.SendToFlutter(msg);
    }
}
