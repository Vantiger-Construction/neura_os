using UnityEngine;

/// <summary>
/// Attach this to a GameObject named "NeuraBridge" for Android.
/// Flutter/Android can call UnitySendMessage("NeuraBridge","ReceiveFromFlutter", jsonLine)
/// </summary>
public class AndroidBridgeReceiver : MonoBehaviour
{
    public void ReceiveFromFlutter(string jsonLine)
    {
        BridgeRouter.Instance?.HandleFromFlutter(jsonLine);
    }
}
