
import 'package:flutter/material.dart';

/// Central place to compute mood-reactive colors.
class NeuraMoodTheme {
  static Color appBarColorFor(String mood, ThemeData base) {
    final lower = mood.toLowerCase();
    if (lower == 'low') {
      return Colors.deepPurple.shade700;
    }
    if (lower == 'high') {
      return Colors.tealAccent.shade700;
    }
    return base.colorScheme.primary;
  }

  static Color backgroundFor(String mood, ThemeData base) {
    final lower = mood.toLowerCase();
    if (lower == 'low') {
      return Colors.deepPurple.shade900.withOpacity(0.9);
    }
    if (lower == 'high') {
      return Colors.teal.shade900.withOpacity(0.9);
    }
    return base.scaffoldBackgroundColor;
  }

  static Gradient? appBarGradientFor(String mood) {
    final lower = mood.toLowerCase();
    if (lower == 'low') {
      return LinearGradient(
        colors: [
          Colors.deepPurple.shade900,
          Colors.indigo.shade700,
        ],
      );
    }
    if (lower == 'high') {
      return LinearGradient(
        colors: [
          Colors.tealAccent.shade400,
          Colors.greenAccent.shade400,
        ],
      );
    }
    return null;
  }
}
