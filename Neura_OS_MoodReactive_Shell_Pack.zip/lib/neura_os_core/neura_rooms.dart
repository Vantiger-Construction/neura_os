
/// Canonical room IDs for Neura's penthouse / sky palace.
class NeuraRoomIds {
  static const dashboard = 'room_dashboard';
  static const reflectionBay = 'room_reflection_bay';
  static const joyLounge = 'room_joy_lounge';
  static const moodDen = 'room_mood_den';
  static const dreamBay = 'room_dream_bay';
  static const settings = 'room_settings';
}
