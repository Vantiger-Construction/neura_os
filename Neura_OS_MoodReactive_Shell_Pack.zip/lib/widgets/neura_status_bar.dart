
import 'package:flutter/material.dart';

import '../neura_os_core/neura_status_center.dart';
import '../neura_os_core/neura_mood_theme.dart';

/// Optional global hook where you can register your animated Neura avatar
/// widget builder. If not set, the status bar falls back to a simple icon.
typedef NeuraAvatarBuilder = Widget Function(BuildContext context);

class NeuraAvatarRegistry {
  NeuraAvatarRegistry._();

  static NeuraAvatarBuilder? _builder;

  static void register(NeuraAvatarBuilder builder) {
    _builder = builder;
  }

  static NeuraAvatarBuilder? get builder => _builder;
}

/// Top bar showing Neura avatar, mood, and OS indicators, with mood-reactive
/// background color and gradient.
class NeuraStatusBar extends StatelessWidget implements PreferredSizeWidget {
  const NeuraStatusBar({super.key});

  @override
  Size get preferredSize => const Size.fromHeight(56);

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return AnimatedBuilder(
      animation: NeuraStatusCenter.instance,
      builder: (context, _) {
        final status = NeuraStatusCenter.instance.status;

        final moodIcon = _moodIcon(status.mood);
        final moodColor = _moodColor(status.mood);
        final autoIcon = status.automationsEnabled
            ? Icons.auto_mode
            : Icons.pause_circle_filled;

        final appBarColor = NeuraMoodTheme.appBarColorFor(
          status.mood,
          theme,
        );
        final gradient = NeuraMoodTheme.appBarGradientFor(status.mood);

        return AppBar(
          elevation: 0,
          backgroundColor: appBarColor,
          flexibleSpace: gradient == null
              ? null
              : Container(
                  decoration: BoxDecoration(gradient: gradient),
                ),
          titleSpacing: 0,
          title: Row(
            children: [
              _buildAvatar(context),
              const SizedBox(width: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('Neura Companion'),
                  Text(
                    'Mood: ${status.mood}, Energy: ${status.energy}',
                    style: theme.textTheme.bodySmall,
                  ),
                ],
              ),
              const Spacer(),
              Icon(moodIcon, color: moodColor),
              const SizedBox(width: 8),
              Icon(
                autoIcon,
                color: status.automationsEnabled
                    ? Colors.lightBlueAccent
                    : Colors.grey,
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildAvatar(BuildContext context) {
    final builder = NeuraAvatarRegistry.builder;
    if (builder != null) {
      return SizedBox(
        width: 40,
        height: 40,
        child: ClipOval(
          child: builder(context),
        ),
      );
    }
    // Fallback placeholder avatar.
    return const CircleAvatar(
      radius: 18,
      child: Icon(Icons.android),
    );
  }

  IconData _moodIcon(String mood) {
    switch (mood.toLowerCase()) {
      case 'low':
        return Icons.sentiment_dissatisfied;
      case 'high':
        return Icons.sentiment_very_satisfied;
      default:
        return Icons.sentiment_neutral;
    }
  }

  Color _moodColor(String mood) {
    switch (mood.toLowerCase()) {
      case 'low':
        return Colors.redAccent;
      case 'high':
        return Colors.greenAccent;
      default:
        return Colors.amberAccent;
    }
  }
}
