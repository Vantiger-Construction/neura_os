
import 'package:flutter/material.dart';

import '../neura_os_core/neura_status_center.dart';
import '../neura_os_core/neura_mood_theme.dart';
import '../neura_os_core/neura_rooms.dart';
import 'neura_status_bar.dart';
import 'neura_quick_actions_row.dart';

/// Main mood-reactive shell scaffold.
///
/// - Uses NeuraStatusBar with mood-reactive colors.
/// - Applies mood-reactive scaffold background.
/// - Tracks active room using canonical room IDs if provided.
class NeuraShellScaffold extends StatefulWidget {
  final List<Widget> rooms;
  final List<BottomNavigationBarItem> navItems;

  /// Optional room IDs matching the `rooms` list.
  /// If not provided, it will fall back to default indexed IDs.
  final List<String>? roomIds;

  final int initialIndex;

  const NeuraShellScaffold({
    super.key,
    required this.rooms,
    required this.navItems,
    this.roomIds,
    this.initialIndex = 0,
  }) : assert(rooms.length == navItems.length);

  /// Helper factory that sets up a canonical penthouse-style shell.
  factory NeuraShellScaffold.penthouse({
    required Widget dashboard,
    required Widget reflectionBay,
    required Widget joyLounge,
    required Widget moodDen,
    required Widget settings,
    int initialIndex,
  }) {
    final rooms = [
      dashboard,
      reflectionBay,
      joyLounge,
      moodDen,
      settings,
    ];
    final navItems = const [
      BottomNavigationBarItem(icon: Icon(Icons.home), label: 'Home'),
      BottomNavigationBarItem(icon: Icon(Icons.water), label: 'Reflect'),
      BottomNavigationBarItem(icon: Icon(Icons.celebration), label: 'Joy'),
      BottomNavigationBarItem(icon: Icon(Icons.mood), label: 'Mood Den'),
      BottomNavigationBarItem(icon: Icon(Icons.settings), label: 'Settings'),
    ];
    final roomIds = [
      NeuraRoomIds.dashboard,
      NeuraRoomIds.reflectionBay,
      NeuraRoomIds.joyLounge,
      NeuraRoomIds.moodDen,
      NeuraRoomIds.settings,
    ];
    return NeuraShellScaffold(
      rooms: rooms,
      navItems: navItems,
      roomIds: roomIds,
      initialIndex: initialIndex,
    );
  }

  @override
  State<NeuraShellScaffold> createState() => _NeuraShellScaffoldState();
}

class _NeuraShellScaffoldState extends State<NeuraShellScaffold> {
  late int _index;

  @override
  void initState() {
    super.initState();
    _index = widget.initialIndex;
    _setActiveRoom();
  }

  void _setActiveRoom() {
    final ids = widget.roomIds;
    String roomId;
    if (ids != null && _index < ids.length) {
      roomId = ids[_index];
    } else {
      roomId = 'room_$_index';
    }
    NeuraStatusCenter.instance.setActiveRoom(roomId);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return AnimatedBuilder(
      animation: NeuraStatusCenter.instance,
      builder: (context, _) {
        final status = NeuraStatusCenter.instance.status;
        final bgColor = NeuraMoodTheme.backgroundFor(
          status.mood,
          theme,
        );

        return Scaffold(
          appBar: const NeuraStatusBar(),
          backgroundColor: bgColor,
          body: Column(
            children: [
              const SizedBox(height: 8),
              const NeuraQuickActionsRow(),
              const Divider(height: 16),
              Expanded(
                child: widget.rooms[_index],
              ),
            ],
          ),
          bottomNavigationBar: BottomNavigationBar(
            currentIndex: _index,
            items: widget.navItems,
            onTap: (i) {
              setState(() {
                _index = i;
                _setActiveRoom();
              });
            },
          ),
        );
      },
    );
  }
}
