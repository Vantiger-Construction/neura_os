
# Neura Companion OS – Mood-Reactive Shell Pack

This pack extends the previous **Shell & Status Pack** by implementing
the "next step" suggestions:

1. Mood-reactive colors and theming for the shell.
2. Canonical room IDs mapped to your penthouse rooms
   (Reflection Bay, Joy Lounge, Mood Den, Dream Bay, etc.).
3. A cleaner hook point to swap the placeholder avatar for your
   animated Neura widget.

It is designed to **replace/extend** some of the shell widgets:

- ADDS: `lib/neura_os_core/neura_mood_theme.dart`
- ADDS: `lib/neura_os_core/neura_rooms.dart`
- REPLACES: `lib/widgets/neura_status_bar.dart`
- REPLACES: `lib/widgets/neura_shell_scaffold.dart`

You can drop this on top of your current Neura Companion OS UI and
wire it in with minimal changes.
