# Neura OS Patch v8 — Focus + Ambient FX + Rooms Map

What this patch adds:
- **Focus Office** (Deep Work / Reflection / Social / Wind Down)
- **Global Focus banner** in the OS shell
- **Ambient background FX** toggle (subtle moving glow)
- **Rooms Map** (searchable module launcher) + optional portal transitions + shimmer path
- Cleans up the optional Azure stub so it no longer depends on missing packages
- Adds missing `cross_file` dependency and declares assets

## Apply
- Drop `neura_os/` over your existing project root (merge/overwrite).
- Run `flutter pub get`
- Run `flutter run`

## Files touched
- `pubspec.yaml`
- `lib/main.dart`
- `lib/src/app.dart`
- `lib/src/shell/*`
- `lib/src/modules/focus/*`
- `lib/src/modules/dashboard/dashboard.dart`
- `lib/src/modules/settings/settings.dart`
- `lib/services/avatar_service.dart`
- `lib/config/azure_config.dart`
- `lib/services/azure_storage_service.dart`
