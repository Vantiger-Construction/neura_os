Neura Final MegaBuild
=====================

This bundle was auto-assembled from all Neura / Neuro Companion
archives visible in the workspace.

Main app project:
  - Neura_Companion_App/
    This contains the Flutter project from
    Neura_Companion_All_Inclusive_Bundle.zip, with lib/main.dart
    overwritten by the latest uploaded main.dart.

Extras:
  - Extras/
    Each subfolder contains the contents of one of your other
    archived bundles (Final, FullSource, WithTests, Azure, etc.),
    extracted side-by-side so nothing is lost.

To open the main app:
  1) cd Neura_Companion_App
  2) flutter pub get
  3) flutter run

You can manually copy over any missing pieces from Extras/ into
Neura_Companion_App if you know a newer file exists there.
