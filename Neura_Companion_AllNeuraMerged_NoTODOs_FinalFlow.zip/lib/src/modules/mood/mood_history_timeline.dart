import 'package:flutter/material.dart';

import '../../../neura_shell/state/neura_shell_scope.dart';
import '../../../neura_core/neura_emotion_engine.dart';

class MoodHistoryTimeline extends StatelessWidget {
  const MoodHistoryTimeline({super.key});

  IconData _iconForSample(NeuraEmotionSample sample) {
    final v = sample.valence;
    final a = sample.arousal;
    if (v > 0.5 && a >= 0) return Icons.wb_sunny;
    if (v > 0.2 && a < 0.2) return Icons.cloud;
    if (v < -0.4 && a < -0.2) return Icons.nights_stay;
    if (v < -0.2 && a > 0.4) return Icons.bolt;
    return Icons.blur_on;
  }

  String _labelForSample(NeuraEmotionSample sample) {
    final v = sample.valence;
    final a = sample.arousal;
    if (v > 0.5 && a >= 0) return 'Upbeat & energized';
    if (v > 0.2 && a < 0.2) return 'Calm and mostly okay';
    if (v < -0.4 && a < -0.2) return 'Heavy and low-energy';
    if (v < -0.2 && a > 0.4) return 'Tense and wired';
    return 'Mixed or shifting mood';
  }

  @override
  Widget build(BuildContext context) {
    final shell = NeuraShellScope.maybeOf(context);
    final theme = Theme.of(context);

    if (shell == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Mood History')),
        body: const Center(
          child: Text('Neura shell not found – open this from inside Neura Companion.'),
        ),
      );
    }

    final emotion = shell.emotionEngine;
    final samples = emotion.historyForDays(7);
    final samplesDesc = samples.reversed.toList();

    return Scaffold(
      appBar: AppBar(title: const Text('Mood History (Last 7 Days)')),
      body: samplesDesc.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'No mood history yet.

Check in a few times and Neura will start drawing a pattern for you.',
                  textAlign: TextAlign.center,
                ),
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: samplesDesc.length,
              itemBuilder: (context, index) {
                final s = samplesDesc[index];
                final time = TimeOfDay.fromDateTime(s.timestamp);
                final dayLabel =
                    '${s.timestamp.year}-${s.timestamp.month.toString().padLeft(2, '0')}-${s.timestamp.day.toString().padLeft(2, '0')}';
                final tLabel =
                    '${time.hourOfPeriod.toString().padLeft(2, '0')}:${time.minute.toString().padLeft(2, '0')} ${time.period == DayPeriod.am ? 'AM' : 'PM'}';

                return Card(
                  margin: const EdgeInsets.only(bottom: 12),
                  child: ListTile(
                    leading: Icon(_iconForSample(s), color: theme.colorScheme.primary),
                    title: Text(_labelForSample(s)),
                    subtitle: Text(
                      '$dayLabel  ·  $tLabel\n'
                      'valence ${s.valence.toStringAsFixed(2)}, '
                      'arousal ${s.arousal.toStringAsFixed(2)}',
                    ),
                  ),
                );
              },
            ),
    );
  }
}
