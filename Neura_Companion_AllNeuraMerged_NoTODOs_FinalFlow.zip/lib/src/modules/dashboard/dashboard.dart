import 'package:flutter/material.dart';
import '../../../features/voice/neura_voice_greeter.dart';
import '../../../neura_megabuild/neura_joke_panel_animated.dart';
import '../../../neura_megabuild/neura_humor_engine.dart';
import '../../../neura_megabuild/neura_joke_preferences_manager.dart';
import '../../../features/mood_dashboard_tile.dart';
import '../../modules/mood/mood_history_timeline.dart';
import '../../../features/weekly_life_snapshot.dart';
import '../../../modules/mirror/mirror_screen.dart';
import '../../../modules/synaptic/synaptic_screen.dart';
import '../../../modules/clinical/clinical_dashboard.dart';
import '../../../modules/legacy/legacy_hall_screen.dart';
import '../../../persona/screens/audience_settings_screen.dart';

class DashboardScreen extends StatefulWidget {
  const DashboardScreen({super.key});

  @override
  State<DashboardScreen> createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  late final NeuraVoiceGreeter _greeter = NeuraVoiceGreeter();
  late final NeuraHumorEngine _humorEngine = NeuraHumorEngine();
  late final NeuraJokePreferencesManager _prefs = NeuraJokePreferencesManager();
  bool _prefsLoaded = false;

  @override
  void initState() {
    super.initState();
    _initPrefs();
    _greeter.greetIfNeeded();
  }

  Future<void> _initPrefs() async {
    await _prefs.loadPreferences();
    if (!mounted) return;
    setState(() {
      _prefsLoaded = true;
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(title: const Text('Dashboard')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Text(
              'Today with Neura',
              style: theme.textTheme.headlineSmall,
            ),
            const SizedBox(height: 8),
            const Text(
              'Quick snapshot of your day, plus a little humor boost.',
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                OutlinedButton.icon(
                  icon: const Icon(Icons.mirror),
                  label: const Text('Mirror Mode'),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const MirrorScreen(),
                      ),
                    );
                  },
                ),
                OutlinedButton.icon(
                  icon: const Icon(Icons.bolt),
                  label: const Text('Synaptic Growth'),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const SynapticGrowthScreen(),
                      ),
                    );
                  },
                ),
                OutlinedButton.icon(
                  icon: const Icon(Icons.local_hospital),
                  label: const Text('Clinical Mode'),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const ClinicalDashboard(),
                      ),
                    );
                  },
                ),
                OutlinedButton.icon(
                  icon: const Icon(Icons.favorite),
                  label: const Text('Legacy Hall'),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const LegacyHallScreen(),
                      ),
                    );
                  },
                ),
                OutlinedButton.icon(
                  icon: const Icon(Icons.person_pin),
                  label: const Text('Persona Setup'),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const AudienceSettingsScreen(),
                      ),
                    );
                  },
                ),
                OutlinedButton.icon(
                  icon: const Icon(Icons.timeline),
                  label: const Text('Mood History'),
                  onPressed: () {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => const MoodHistoryTimeline(),
                      ),
                    );
                  },
                ),
              ],
            ),
            const SizedBox(height: 16),
            const WeeklyLifeSnapshot(),
            const SizedBox(height: 12),
            Expanded(
              child: Row(
                children: [
                  Expanded(
                    flex: 2,
                    child: Card(
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: const MoodDashboardTile(),
                      ),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    flex: 2,
                    child: Card(
                      elevation: 4,
                      child: Padding(
                        padding: const EdgeInsets.all(12),
                        child: _prefsLoaded
                            ? NeuraJokePanelAnimated(
                                humorEngine: _humorEngine,
                                prefs: _prefs,
                              )
                            : const Center(
                                child: CircularProgressIndicator(),
                              ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
