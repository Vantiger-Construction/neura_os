import 'package:provider/provider.dart';
import '../features/config/neura_config_model.dart';
import '../features/config/neura_config_screen.dart';
import '../features/diagnostics/diagnostics_hooks.dart';
import '../features/voice/viseme_timing_controller.dart';
import 'package:flutter/material.dart';
import 'modules/navigation/enhanced_navigation.dart';
import 'modules/core/ai_engine.dart';

class NeuroCompanionApp extends StatelessWidget {
  const NeuroCompanionApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => NeuraConfigModel()..load()),
        Provider(create: (_) => VisemeTimingController()),
        ProxyProvider<VisemeTimingController, DiagnosticsHooks>(
          update: (_, timing, __) => DiagnosticsHooks(timing),
        ),
      ],
      child: MaterialApp(
        title: 'Neuro Companion',
        theme: ThemeData.dark(),
        home: const EnhancedNavigation(),
        routes: {
          '/config': (_) => const NeuraConfigScreen(),
        },
      ),
    );
  }
}