import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/billing_service.dart';

import '../neura_dreams/neura_dream_engine.dart';
import '../neura_megabuild/neura_dreamscape_generator.dart';
import '../neura_megabuild/dream_journal_entry.dart';

class DreamVisualizerScreen extends StatelessWidget {
  const DreamVisualizerScreen({super.key});

  List<DreamJournalEntry> _mapEntries(List<NeuraDreamEntry> entries) {
    return entries
        .map(
          (e) => DreamJournalEntry(
            id: e.id,
            recordedAt: e.timestamp,
            transcript: e.transcript,
            interpretation: e.interpretation,
            moodSummary: e.moodSummary,
          ),
        )
        .toList()
      ..sort((a, b) => a.recordedAt.compareTo(b.recordedAt));
  }


@override
Widget build(BuildContext context) {
  final billing = BillingService.instance;
  if (!billing.isPro) {
    return Scaffold(
      appBar: AppBar(title: const Text('Dream Visualizer')),
      body: const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            'Dream Visualizer is a Neura Pro feature. Upgrade when you\'re ready, and Neura will start painting your dreamscape.',
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
  return Consumer<NeuraDreamEngine>(
      builder: (context, engine, _) {
        final entries = _mapEntries(engine.entries);
        return NeuraDreamscapeGenerator(entries: entries);
      },
    );
  }
}
