import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../services/billing_service.dart';

import '../neura_dreams/neura_dream_engine.dart';
import '../neura_megabuild/dream_journal_entry.dart';
import '../neura_megabuild/neura_monthly_dream_replay.dart';
import '../neura_megabuild/neura_dream_show_player.dart';

class DreamShowScreen extends StatelessWidget {
  const DreamShowScreen({super.key});

  List<DreamJournalEntry> _mapEntries(List<NeuraDreamEntry> entries) {
    return entries
        .map(
          (e) => DreamJournalEntry(
            id: e.id,
            recordedAt: e.timestamp,
            transcript: e.transcript,
            interpretation: e.interpretation,
            moodSummary: e.moodSummary,
          ),
        )
        .toList()
      ..sort((a, b) => a.recordedAt.compareTo(b.recordedAt));
  }


@override
Widget build(BuildContext context) {
  final billing = BillingService.instance;
  if (!billing.isPro) {
    return Scaffold(
      appBar: AppBar(title: const Text('Dream Show')),
      body: const Center(
        child: Padding(
          padding: EdgeInsets.all(24),
          child: Text(
            'Dream Show is a Neura Pro feature. Once you\'re upgraded, Neura will stitch your month of dreams into a little show.',
            textAlign: TextAlign.center,
          ),
        ),
      ),
    );
  }
  return Consumer<NeuraDreamEngine>(
      builder: (context, engine, _) {
        final entries = _mapEntries(engine.entriesForCurrentMonth());
        final replay = NeuraMonthlyDreamReplay.fromEntries(entries);
        return NeuraDreamShowPlayer(replay: replay);
      },
    );
  }
}
