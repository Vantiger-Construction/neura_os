import 'package:flutter/material.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import '../services/billing_service.dart';

class PurchaseHistoryScreen extends StatefulWidget {
  @override
  _PurchaseHistoryScreenState createState() => _PurchaseHistoryScreenState();
}

class _PurchaseHistoryScreenState extends State<PurchaseHistoryScreen> {
  final BillingService _billing = BillingService.instance;
  bool _loading = true;
  List<PurchaseDetails> _purchases = [];

  @override
  void initState() {
    super.initState();
    _loadHistory();
  }

  Future<void> _loadHistory() async {
    await _billing.init();
    // In this minimal implementation we do not yet have a direct
    // query for past purchases, so the list stays empty. This keeps
    // the screen stable until you wire a backend or cached list.
    setState(() {
      _purchases = const [];
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Purchase History')),
      body: _purchases.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'No purchases found yet. Once you\'ve grabbed Neura Pro, '
                  'your purchase history will show up here.',
                  textAlign: TextAlign.center,
                ),
              ),
            )
          : ListView.builder(
              itemCount: _purchases.length,
              itemBuilder: (context, index) {
                final p = _purchases[index];
                return ListTile(
                  title: Text(p.productID),
                  subtitle: Text(p.status.toString()),
                );
              },
            ),
    );
  }
}
