import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../neura_dreams/neura_dream_engine.dart';
import '../neura_megabuild/neura_dream_calendar_navigator.dart';
import '../neura_megabuild/neura_dream_journal_screen.dart';
import '../neura_megabuild/dream_journal_entry.dart';

class DreamJournalCalendarScreen extends StatelessWidget {
  const DreamJournalCalendarScreen({super.key});

  List<DreamJournalEntry> _mapEntries(List<NeuraDreamEntry> entries) {
    return entries
        .map(
          (e) => DreamJournalEntry(
            id: e.id,
            recordedAt: e.timestamp,
            transcript: e.transcript,
            interpretation: e.interpretation,
            moodSummary: e.moodSummary,
          ),
        )
        .toList()
      ..sort((a, b) => a.recordedAt.compareTo(b.recordedAt));
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Consumer<NeuraDreamEngine>(
      builder: (context, engine, _) {
        final entries = engine.entries;
        final mapped = _mapEntries(entries);

        return Scaffold(
          appBar: AppBar(
            title: const Text('Dream Journal Calendar'),
          ),
          body: mapped.isEmpty
              ? const Center(
                  child: Padding(
                    padding: EdgeInsets.all(24),
                    child: Text(
                      'No dreams recorded yet. Once Neura has a few nights of data, '
                      'you\'ll see a calendar of dream dots here.',
                      textAlign: TextAlign.center,
                    ),
                  ),
                )
              : NeuraDreamCalendarNavigator(
                  entries: mapped,
                  onDaySelected: (dayEntries) {
                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (_) => NeuraDreamJournalScreen(
                          entries: dayEntries,
                        ),
                      ),
                    );
                  },
                ),
        );
      },
    );
  }
}
