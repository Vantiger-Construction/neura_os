/// Lightweight mood state helper for chat hints.
/// For now this just exposes a simple label; later you can wire it to real logs.
class MoodStateService {
  MoodStateService._internal();
  static final MoodStateService instance = MoodStateService._internal();

  String _currentMoodLabel = 'neutral';

  String get currentMoodLabel => _currentMoodLabel;

  Future<void> load() async {
    // Later: hydrate from mood history / last check-in.
  }

  Future<void> setCurrentMood(String label) async {
    _currentMoodLabel = label;
    // Later: persist if needed.
  }
}
