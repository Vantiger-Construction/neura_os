enum NeuraAudience {
  child,
  teen,
  adult,
}

extension NeuraAudienceLabel on NeuraAudience {
  String get label {
    switch (this) {
      case NeuraAudience.child:
        return 'child';
      case NeuraAudience.teen:
        return 'teen';
      case NeuraAudience.adult:
      default:
        return 'adult';
    }
  }

  String get displayName {
    switch (this) {
      case NeuraAudience.child:
        return 'Kids (under 13)';
      case NeuraAudience.teen:
        return 'Teens (13–17)';
      case NeuraAudience.adult:
      default:
        return 'Adults (18+)';
    }
  }

  String get description {
    switch (this) {
      case NeuraAudience.child:
        return 'Extra gentle explanations, simple language, and no heavy topics.';
      case NeuraAudience.teen:
        return 'Supportive, real-talk tone with care around sensitive topics.';
      case NeuraAudience.adult:
      default:
        return 'Full-depth conversations, including complex emotional themes.';
    }
  }
}
