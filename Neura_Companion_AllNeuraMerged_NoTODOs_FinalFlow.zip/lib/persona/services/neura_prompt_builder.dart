import '../models/neura_audience.dart';

class NeuraPromptStyle {
  final String toneLabel;      // e.g. "warm", "playful", "clinical"
  final String difficulty;     // e.g. "simple", "balanced", "deep"
  final int jokeFrequency;     // 0-10ish scale
  final String depthLevel;     // e.g. "surface", "medium", "deep"
  final String energyLevel;    // e.g. "low", "medium", "high"

  const NeuraPromptStyle({
    required this.toneLabel,
    required this.difficulty,
    required this.jokeFrequency,
    required this.depthLevel,
    required this.energyLevel,
  });
}

class NeuraPromptBuilder {
  NeuraPromptBuilder._internal();
  static final NeuraPromptBuilder instance = NeuraPromptBuilder._internal();

  /// Decide how Neura should "sound" for a given module + audience.
  Future<NeuraPromptStyle> resolveStyle({
    required String module,
    required NeuraAudience audience,
  }) async {
    switch (audience) {
      case NeuraAudience.child:
        return const NeuraPromptStyle(
          toneLabel: 'gentle-playful',
          difficulty: 'simple',
          jokeFrequency: 8,
          depthLevel: 'surface',
          energyLevel: 'high',
        );
      case NeuraAudience.teen:
        return const NeuraPromptStyle(
          toneLabel: 'supportive-real',
          difficulty: 'balanced',
          jokeFrequency: 5,
          depthLevel: 'medium',
          energyLevel: 'medium',
        );
      case NeuraAudience.adult:
      default:
        return const NeuraPromptStyle(
          toneLabel: 'warm-direct',
          difficulty: 'deep',
          jokeFrequency: 3,
          depthLevel: 'deep',
          energyLevel: 'medium',
        );
    }
  }

  /// Build a system prompt string that explains Neura's role.
  Future<String> buildSystemMessage({
    required String module,
    required NeuraAudience audience,
  }) async {
    final audienceLabel = audience.displayName;
    final moduleLabel = module.isEmpty ? 'general support' : module;

    return 'You are Neura, a caring AI companion designed to help people grow. '
        'Speak to a $audienceLabel user about $moduleLabel. '
        'Be honest, kind, and practical. Never give medical or safety-critical advice; '
        'always remind them to contact real-world professionals for emergencies.';
  }
}
