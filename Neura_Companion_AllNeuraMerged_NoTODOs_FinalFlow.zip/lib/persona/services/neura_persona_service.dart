/// Simple stub for persona configuration (coach, friend, teacher, etc.).
class NeuraPersonaService {
  NeuraPersonaService._internal();
  static final NeuraPersonaService instance = NeuraPersonaService._internal();

  String _currentPersona = 'friend';

  String get currentPersona => _currentPersona;

  Future<void> load() async {
    // Later: load from storage/settings; keep "friend" as default for now.
  }

  Future<void> setPersona(String persona) async {
    _currentPersona = persona;
    // Later: persist to storage.
  }
}
