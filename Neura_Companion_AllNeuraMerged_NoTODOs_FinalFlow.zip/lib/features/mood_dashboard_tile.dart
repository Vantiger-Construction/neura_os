import 'package:flutter/material.dart';

import '../neura_shell/state/neura_shell_scope.dart';

/// Small dashboard tile that shows Neura's current emotional read on the user.
class MoodDashboardTile extends StatelessWidget {
  const MoodDashboardTile({super.key});

  String _headline(double valence, double arousal) {
    if (valence > 0.5 && arousal >= 0) return 'You're glowing';
    if (valence > 0.2 && arousal < 0.2) return 'Calm & okay';
    if (valence < -0.4 && arousal < -0.2) return 'Heavy day';
    if (valence < -0.2 && arousal > 0.4) return 'Stressed & wired';
    return 'Mixed vibes';
  }

  String _subtitle(double valence, double arousal) {
    if (valence > 0.5 && arousal >= 0) {
      return 'Neura reads your mood as upbeat and energized.';
    }
    if (valence > 0.2 && arousal < 0.2) {
      return 'Soft, steady, and mostly okay. Good ground for small wins.';
    }
    if (valence < -0.4 && arousal < -0.2) {
      return 'Feels like a lot. Today might call for gentleness and rest.';
    }
    if (valence < -0.2 && arousal > 0.4) {
      return 'Tense and buzzing. Grounding or breathing rituals could help.';
    }
    return 'A bit of everything. Let's make a small move that feels kind.';
  }

  Color _chipColor(ThemeData theme, double valence, double arousal) {
    if (valence > 0.5 && arousal >= 0) return theme.colorScheme.primary;
    if (valence < -0.2) return theme.colorScheme.error;
    if (arousal > 0.4) return theme.colorScheme.tertiary;
    return theme.colorScheme.secondary;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final shell = NeuraShellScope.maybeOf(context);
    if (shell == null) {
      return const SizedBox.shrink();
    }
    final emotion = shell.emotionEngine;

    return AnimatedBuilder(
      animation: emotion,
      builder: (context, _) {
        final v = emotion.valence;
        final a = emotion.arousal;

        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              _headline(v, a),
              style: theme.textTheme.titleMedium,
            ),
            const SizedBox(height: 4),
            Text(
              _subtitle(v, a),
              style: theme.textTheme.bodySmall,
            ),
            const SizedBox(height: 8),
            Align(
              alignment: Alignment.centerLeft,
              child: Chip(
                label: Text('valence ${v.toStringAsFixed(2)}  ·  arousal ${a.toStringAsFixed(2)}'),
                backgroundColor: _chipColor(theme, v, a).withOpacity(0.16),
              ),
            ),
          ],
        );
      },
    );
  }
}
