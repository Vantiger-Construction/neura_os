import 'package:flutter/material.dart';

import '../neura_shell/state/neura_shell_scope.dart';
import '../neura_core/neura_emotion_engine.dart';

class WeeklyLifeSnapshot extends StatelessWidget {
  const WeeklyLifeSnapshot({super.key});

  String _trendText(List<NeuraEmotionSample> samples) {
    if (samples.isEmpty) {
      return 'Neura hasn\'t seen enough of your week yet. Check in a bit more and I\'ll start spotting patterns.';
    }
    final avgValence =
        samples.map((s) => s.valence).fold<double>(0, (a, b) => a + b) / samples.length;
    final avgArousal =
        samples.map((s) => s.arousal).fold<double>(0, (a, b) => a + b) / samples.length;

    if (avgValence > 0.3 && avgArousal >= 0) {
      return 'Overall, this week leans positive and reasonably energized. You\'re trending toward a glow-up arc.';
    }
    if (avgValence > 0.1 && avgArousal < 0.1) {
      return 'Mostly stable and okay. Quiet weeks can be powerful for slow, solid progress.';
    }
    if (avgValence < -0.2 && avgArousal < 0) {
      return 'This week felt heavy and low-energy. Neura recommends extra gentleness and small, easy wins.';
    }
    if (avgValence < -0.1 && avgArousal > 0.3) {
      return 'Tense and wired overall. Grounding rituals or shorter check-ins could help you decompress.';
    }
    return 'A mixed week emotionally. The important part is that you\'re paying attention—and Neura is, too.';
  }

  @override
  Widget build(BuildContext context) {
    final shell = NeuraShellScope.maybeOf(context);
    final theme = Theme.of(context);

    if (shell == null) {
      return const SizedBox.shrink();
    }

    final emotion = shell.emotionEngine;
    final weekly = emotion.historyForDays(7);
    final avgValence = weekly.isEmpty
        ? 0.0
        : weekly.map((s) => s.valence).fold<double>(0, (a, b) => a + b) / weekly.length;
    final avgArousal = weekly.isEmpty
        ? 0.0
        : weekly.map((s) => s.arousal).fold<double>(0, (a, b) => a + b) / weekly.length;

    final trend = _trendText(weekly);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Weekly Life Snapshot',
              style: theme.textTheme.titleMedium,
            ),
            const SizedBox(height: 4),
            Text(
              'Average valence ${avgValence.toStringAsFixed(2)}, '
              'average arousal ${avgArousal.toStringAsFixed(2)}',
              style: theme.textTheme.bodySmall,
            ),
            const SizedBox(height: 8),
            Text(
              trend,
              style: theme.textTheme.bodyMedium,
            ),
          ],
        ),
      ),
    );
  }
}
