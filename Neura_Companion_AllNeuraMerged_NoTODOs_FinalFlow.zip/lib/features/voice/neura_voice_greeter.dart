import 'package:shared_preferences/shared_preferences.dart';

import '../../neura_megabuild/neura_voice_engine.dart';

/// Simple helper that lets Neura greet the user once per day using TTS.
///
/// This uses the MegaBuild NeuraVoiceEngine so you can later expand it
/// to handle different tones, languages, or personalities.
class NeuraVoiceGreeter {
  static const _keyLastGreetDay = 'neura_last_voice_greet_day';

  final NeuraVoiceEngine _voice = NeuraVoiceEngine();

  Future<void> greetIfNeeded() async {
    final prefs = await SharedPreferences.getInstance();
    final now = DateTime.now();
    final todayKey = '${now.year}-${now.month}-${now.day}';
    final last = prefs.getString(_keyLastGreetDay);
    if (last == todayKey) {
      // Already greeted today.
      return;
    }

    // Friendly, neutral greeting. You can tune mood/style later.
    await _voice.speak(
      "Hey, I'm Neura. Glad you're here. Let's make today a little better together.",
      mood: NeuraMood.calm,
      voiceStyle: 'gentle',
    );

    await prefs.setString(_keyLastGreetDay, todayKey);
  }
}
