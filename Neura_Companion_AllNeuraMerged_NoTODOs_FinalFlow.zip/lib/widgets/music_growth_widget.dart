import 'package:flutter/material.dart';

/// Simple visualization of musical practice growth.
///
/// In this version we show a weekly practice streak and a friendly
/// summary. You can later replace this with real data from storage.
class MusicGrowthWidget extends StatelessWidget {
  const MusicGrowthWidget({super.key});

  @override
  Widget build(BuildContext context) {
    // Placeholder data – imagine these coming from a practice log.
    final weeklyMinutes = [10, 20, 0, 30, 15, 40, 25];
    final total = weeklyMinutes.fold<int>(0, (sum, v) => sum + v);
    final bestDay = weeklyMinutes.fold<int>(0, (a, b) => b > a ? b : a);

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Music Growth',
              style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            Text(
              'This week: $total minutes of practice.',
              style: const TextStyle(fontSize: 14),
            ),
            const SizedBox(height: 8),
            SizedBox(
              height: 48,
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  for (int i = 0; i < weeklyMinutes.length; i++)
                    Expanded(
                      child: Padding(
                        padding: const EdgeInsets.symmetric(horizontal: 2),
                        child: _Bar(
                          value: weeklyMinutes[i].toDouble(),
                          maxValue: bestDay.toDouble().clamp(1, double.infinity),
                        ),
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 8),
            const Text(
              'Neura tip: short, consistent sessions grow your musical brain '
              'faster than rare, giant marathons.',
              style: TextStyle(fontSize: 12),
            ),
          ],
        ),
      ),
    );
  }
}

class _Bar extends StatelessWidget {
  final double value;
  final double maxValue;

  const _Bar({required this.value, required this.maxValue});

  @override
  Widget build(BuildContext context) {
    final ratio = (value / maxValue).clamp(0.0, 1.0);
    return FractionallySizedBox(
      heightFactor: ratio,
      alignment: Alignment.bottomCenter,
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(4),
          color: Theme.of(context).colorScheme.primary.withOpacity(0.7),
        ),
      ),
    );
  }
}
