import 'package:flutter/material.dart';

import '../models/journal_entry.dart';

/// Handles local vs remote conflicts for journal entries.
class ConflictResolutionService {
  const ConflictResolutionService();

  /// Presents conflict data and resolves based on user choice.
  ///
  /// If [context] is null, prefers the newest entry by timestamp.
  Future<JournalEntry> resolve(
    JournalEntry local,
    JournalEntry remote, {
    BuildContext? context,
  }) async {
    // Prefer newest if we can't show UI.
    if (context == null) {
      return local.updatedAt.isAfter(remote.updatedAt) ? local : remote;
    }

    return showDialog<JournalEntry>(
          context: context,
          builder: (ctx) {
            return AlertDialog(
              title: const Text('Journal conflict detected'),
              content: Column(
                mainAxisSize: MainAxisSize.min,
                children: [
                  const Text('Neura found two versions of this entry.'),
                  const SizedBox(height: 12),
                  Text('Local (last edited ${local.updatedAt}):'),
                  Text(local.text, maxLines: 3, overflow: TextOverflow.ellipsis),
                  const SizedBox(height: 12),
                  Text('Cloud (last edited ${remote.updatedAt}):'),
                  Text(remote.text, maxLines: 3, overflow: TextOverflow.ellipsis),
                ],
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.of(ctx).pop(local),
                  child: const Text('Keep local'),
                ),
                TextButton(
                  onPressed: () => Navigator.of(ctx).pop(remote),
                  child: const Text('Keep cloud copy'),
                ),
              ],
            );
          },
        ) ??
        (local.updatedAt.isAfter(remote.updatedAt) ? local : remote);
  }
}
