/// Service that turns a raw chat session into a short reflective note.
///
/// This default implementation is deliberately simple and **offline-only**.
/// It extracts the last few lines and wraps them in a gentle reflection.
/// You can later replace the internals with a real LLM-backed summary.
class PostChatReflectionService {
  const PostChatReflectionService();

  Future<String> generateReflection(String sessionText) async {
    if (sessionText.trim().isEmpty) {
      return 'No chat content to reflect on yet. Once you talk with Neura, I\'ll help you look back on it.';
    }

    final lines = sessionText
        .split(RegExp(r'\r?\n'))
        .map((l) => l.trim())
        .where((l) => l.isNotEmpty)
        .toList();

    final tail = lines.length <= 6 ? lines : lines.sublist(lines.length - 6);
    final excerpt = tail.join(' • ');

    return 'Here\'s a quick reflection on this chat:\n\n'
        'You brought up: $excerpt\n\n'
        'Neura\'s gentle suggestion: Notice what felt most important or emotional in that list. '
        'That\'s usually the next good place to give yourself a little extra care.';
  }
}
