import 'package:connectivity_plus/connectivity_plus.dart';

import '../models/journal_entry.dart';

/// Very small sync coordinator.
///
/// This implementation deliberately **does not** talk to a real backend.
/// Instead it exposes hooks you can wire into your API layer. The goal
/// is that calling [syncAll] is safe and side-effect free until you
/// plug in actual HTTP calls.
class SyncService {
  const SyncService();

  /// Starts sync process when connectivity is available.
  Future<void> syncAll() async {
    final conn = await Connectivity().checkConnectivity();
    if (conn == ConnectivityResult.none) return;

    // In a real implementation you would:
    // 1. Fetch remote changes since last sync.
    // 2. Merge with local changes.
    // 3. Resolve conflicts (possibly via [ConflictResolutionService]).
    // 4. Push local changes upstream.
    //
    // This placeholder keeps the call safe and no-op until your API is ready.
  }

  /// Example hook signature for later:
  Future<List<JournalEntry>> fetchRemoteJournalSince(DateTime since) async {
    // Replace with a backend call when your API is ready.
    return const [];
  }

  /// Example hook to push local journal entries.
  Future<void> pushLocalJournal(List<JournalEntry> entries) async {
    // Replace with a backend call when your API is ready.
  }
}
