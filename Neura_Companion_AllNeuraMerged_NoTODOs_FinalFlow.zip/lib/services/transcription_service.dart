import 'dart:io';

/// Simple pluggable transcription service.
///
/// Out of the box, this implementation does **not** call any cloud API;
/// instead it returns a polite placeholder so the app never crashes.
/// You can later swap the internals for a real STT provider.
class TranscriptionService {
  const TranscriptionService();

  /// Transcribes audio file at [audioPath] and returns transcript text.
  ///
  /// In this default implementation, we just return a short placeholder
  /// so the rest of Neura's flow (journals, reflections) can still run.
  Future<String> transcribe(String audioPath) async {
    final file = File(audioPath);
    final exists = await file.exists();
    if (!exists) {
      return 'Audio file not found at $audioPath.';
    }
    // In a real implementation, upload [file] to your STT provider here.
    // This placeholder keeps the app stable and makes it obvious what
    // still needs real credentials.
    return 'Voice note recorded. (Transcription service not yet connected to a cloud STT API.)';
  }
}
