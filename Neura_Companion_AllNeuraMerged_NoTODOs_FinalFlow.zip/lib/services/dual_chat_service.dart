import '../models/ai_avatar.dart';

/// Dual chat service routing messages to Neura or Neuro.
///
/// This default implementation does **not** call an external AI API.
/// Instead, it generates a simple, mood-aware style of response based
/// purely on the avatar identity. You can later replace the internals
/// with a real LLM-backed client.
class DualChatService {
  const DualChatService();

  Future<String> sendMessage(String message, AIAvatar avatar) async {
    final trimmed = message.trim();
    if (trimmed.isEmpty) {
      return 'Let\'s start with a thought, a worry, or even just "hi".';
    }

    if (avatar.id == 'neuro') {
      return _neuroStyle(trimmed);
    }
    // Default to Neura.
    return _neuraStyle(trimmed);
  }

  String _neuraStyle(String message) {
    return 'Neura: I\'m here with you.

'
        'You said: "$message".

'
        'What I\'m hearing is that this matters to you. '
        'Let\'s take it one small, kind step at a time.';
  }

  String _neuroStyle(String message) {
    return 'Neuro: Brain engaged. 🧠

'
        'Input received: "$message".

'
        'Let\'s break this down logically and see what you can control, '
        'what you can influence, and what we can safely ignore.';
  }
}
