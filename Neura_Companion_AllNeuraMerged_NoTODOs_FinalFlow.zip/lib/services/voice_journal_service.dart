import 'dart:async';

import 'transcription_service.dart';

/// Voice journal service that coordinates recording and transcription.
///
/// This still uses a stub for actual audio capture, but it is now wired
/// through [TranscriptionService] so you have a single place to integrate
/// a real STT provider later.
class VoiceJournalService {
  bool _isRecording = false;
  String? _currentFilePath;
  final TranscriptionService _transcription;

  VoiceJournalService({TranscriptionService? transcription})
      : _transcription = transcription ?? const TranscriptionService();

  /// Starts voice "recording".
  ///
  /// In this default implementation we just mark the state and stash a
  /// pretend file path. Replace this with real microphone start logic.
  Future<void> startRecording({String? targetFilePath}) async {
    _isRecording = true;
    _currentFilePath = targetFilePath ?? 'voice_journal_note.aac';
  }

  /// Stops recording and runs transcription.
  ///
  /// If no recording was started, returns an explanatory message. Otherwise
  /// it hands the audio path off to [TranscriptionService].
  Future<String> stopRecording() async {
    if (!_isRecording) {
      return 'No active recording. Tap record before stopping.';
    }
    _isRecording = false;
    final path = _currentFilePath ?? 'voice_journal_note.aac';
    final transcript = await _transcription.transcribe(path);
    return transcript.isEmpty
        ? 'Voice entry recorded, but no transcript was produced.'
        : transcript;
  }
}
