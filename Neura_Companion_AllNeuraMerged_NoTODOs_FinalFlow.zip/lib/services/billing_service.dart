import 'dart:async';

import 'package:in_app_purchase/in_app_purchase.dart';

/// Simple billing service that wraps [InAppPurchase] and exposes a
/// high-level `isPro` entitlement flag.
///
/// This implementation does **not** define product IDs for you – set
/// them in [kProProductIds] and make sure they match your store config.
class BillingService {
  BillingService._();

  static final BillingService instance = BillingService._();

  final InAppPurchase _iap = InAppPurchase.instance;

  // Replace these with your actual product identifiers.
  static const Set<String> kProProductIds = {
    'neura_pro_monthly',
    'neura_pro_yearly',
    'neura_pro_lifetime',
  };

  final StreamController<bool> _proController = StreamController<bool>.broadcast();
  bool _isPro = false;

  bool get isPro => _isPro;
  Stream<bool> get proStream => _proController.stream;

  Future<void> init() async {
    final available = await _iap.isAvailable();
    if (!available) {
      // Billing not available; keep user in free mode.
      _setPro(false);
      return;
    }

    // Listen to purchase updates.
    _iap.purchaseStream.listen(_handlePurchaseUpdate, onError: (Object error) {
      // Log or surface billing errors if desired.
    });

    // Restore any past purchases.
    await _iap.restorePurchases();
  }

  Future<void> _handlePurchaseUpdate(List<PurchaseDetails> detailsList) async {
    var hasPro = false;
    for (final purchase in detailsList) {
      if (purchase.status == PurchaseStatus.purchased ||
          purchase.status == PurchaseStatus.restored) {
        if (kProProductIds.contains(purchase.productID)) {
          hasPro = true;
        }
      }
    }
    _setPro(hasPro);
  }

  void _setPro(bool value) {
    if (_isPro == value) return;
    _isPro = value;
    _proController.add(_isPro);
  }

  /// Starts a purchase flow for the given [productDetails].
  Future<void> buy(ProductDetails productDetails) async {
    final purchaseParam = PurchaseParam(productDetails: productDetails);
    await _iap.buyNonConsumable(purchaseParam: purchaseParam);
  }

  /// Clean up resources.
  void dispose() {
    _proController.close();
  }
}
