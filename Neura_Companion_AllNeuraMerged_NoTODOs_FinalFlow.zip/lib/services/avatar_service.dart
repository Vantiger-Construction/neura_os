import 'package:shared_preferences/shared_preferences.dart';

import '../models/ai_avatar.dart';

class AvatarService {
  static const _selectedAvatarKey = 'selected_avatar_id';

  /// Returns available AI Avatars.
  List<AIAvatar> getAvailableAvatars() {
    return const [
      AIAvatar(id: 'neura', name: 'Neura', assetPath: 'assets/animations/neura_idle.json'),
      AIAvatar(id: 'neuro', name: 'Neuro', assetPath: 'assets/animations/neuro_idle.json'),
    ];
  }

  /// Persist selected avatar ID.
  Future<void> selectAvatar(String id) async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_selectedAvatarKey, id);
  }

  /// Load the currently selected avatar, defaulting to Neura.
  Future<AIAvatar> getSelectedAvatar() async {
    final prefs = await SharedPreferences.getInstance();
    final id = prefs.getString(_selectedAvatarKey) ?? 'neura';
    final avatars = getAvailableAvatars();
    return avatars.firstWhere(
      (a) => a.id == id,
      orElse: () => avatars.first,
    );
  }
}
