import 'dart:convert';

import 'package:http/http.dart' as http;

/// Stripe web/desktop helper.
///
/// This does **not** talk directly to Stripe from the app; instead it
/// expects you to expose a small backend endpoint that returns a
/// Checkout session URL and handles webhooks.
class StripeService {
  StripeService({required this.backendBaseUrl});

  final String backendBaseUrl;

  /// Creates a Stripe Checkout session and returns the session URL.
  Future<String> createCheckoutSession(String priceId) async {
    final uri = Uri.parse('\$backendBaseUrl/create-checkout-session');
    final resp = await http.post(
      uri,
      headers: {'Content-Type': 'application/json'},
      body: jsonEncode({'priceId': priceId}),
    );
    if (resp.statusCode != 200) {
      throw Exception('Failed to create Checkout session: \${resp.statusCode}');
    }
    final data = jsonDecode(resp.body) as Map<String, dynamic>;
    return data['url'] as String;
  }

  /// Stub handler; real webhook handling must live on your backend.
  Future<void> handleWebhook(Map<String, dynamic> event) async {
    // Intentionally left as a no-op on the client.
    // Your backend should mark the user as "pro" and your app should
    // read that via your sync/auth layer.
  }
}
