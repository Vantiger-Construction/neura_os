import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/neura_room.dart';
import '../../neura_avatar/neura_avatar_controller.dart';
import '../../neura_voice/neura_voice_service.dart';
import '../../neura_brain/neura_persona_model.dart';
import '../../neura_brain/neura_emotion_engine.dart';
import '../../neura_brain/neura_self_heal_service.dart';
import '../../neura_dreams/neura_dream_engine.dart';
import '../../neura_rituals/neura_ritual_engine.dart';
import '../../neura_reflection/neura_reflection_engine.dart';
import '../../neura_clinical/neura_clinical_engine.dart';
import '../../neura_legacy/neura_legacy_engine.dart';

/// Root application shell state for Neura OS.
///
/// Single source of truth for:
///   * Current + startup room
///   * Shared avatar controller
///   * Shared voice service
///   * Persona model
///   * Emotion engine
///   * Ritual engine
///   * Dream engine
///   * Reflection engine
///   * Clinical engine
///   * Legacy engine
///   * Self-heal / Dimensional Sync brain
class NeuraShellState extends ChangeNotifier {
  static const _prefKeyStartupRoom = 'neura_startup_room_v1';

  NeuraRoomId _currentRoom = NeuraRoomId.penthouse;
  NeuraRoomId? _startupRoom;
  bool _isLoading = true;

  /// Shared Neura avatar controller for the entire OS shell.
  final NeuraAvatarController avatarController;

  /// Central voice/STT/TTS orchestrator.
  late final NeuraVoiceService voiceService;

  /// Friendly persona profile that evolves with the user.
  final NeuraPersona persona;

  /// Emotion "weather" engine for mood + forecast.
  final NeuraEmotionEngine emotionEngine;

  /// Ritual / habit engine.
  final NeuraRitualEngine ritualEngine;

  /// Dream journal + visualizer engine.
  final NeuraDreamEngine dreamEngine;

  /// Reflection / daily summary engine.
  final NeuraReflectionEngine reflectionEngine;

  /// Clinical structured check-ins.
  final NeuraClinicalEngine clinicalEngine;

  /// Legacy stories / values / messages engine.
  final NeuraLegacyEngine legacyEngine;

  /// Central self-heal / error brain.
  final NeuraSelfHealService selfHeal;

  NeuraShellState()
      : avatarController = NeuraAvatarController(),
        persona = NeuraPersona(displayName: 'Friend'),
        emotionEngine = NeuraEmotionEngine(),
        ritualEngine = NeuraRitualEngine(),
        dreamEngine = NeuraDreamEngine(),
        reflectionEngine = NeuraReflectionEngine(),
        clinicalEngine = NeuraClinicalEngine(),
        legacyEngine = NeuraLegacyEngine(),
        selfHeal = NeuraSelfHealService() {
    voiceService = NeuraVoiceService(avatarController: avatarController);
    _loadStartupRoomAndEngines();
  }

  bool get isLoading => _isLoading;
  NeuraRoomId get currentRoom => _currentRoom;
  NeuraRoomId? get startupRoom => _startupRoom;

  /// Convenient alias so you can call `NeuraShellScope.of(context).voice`.
  NeuraVoiceService get voice => voiceService;

  Future<void> _loadStartupRoomAndEngines() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final roomName = prefs.getString(_prefKeyStartupRoom);

      if (roomName != null) {
        final parsed = NeuraRoomId.values.firstWhere(
          (r) => r.name == roomName,
          orElse: () => NeuraRoomId.penthouse,
        );
        _startupRoom = parsed;
        _currentRoom = parsed;
      }

      // Load engines that touch disk.
      await Future.wait([
        ritualEngine.ensureLoaded(),
        dreamEngine.ensureLoaded(),
        reflectionEngine.ensureLoaded(),
        clinicalEngine.ensureLoaded(),
        legacyEngine.ensureLoaded(),
      ]);
    } catch (_) {
      // swallow & use defaults
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> setStartupRoom(NeuraRoomId id) async {
    _startupRoom = id;
    _currentRoom = id;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_prefKeyStartupRoom, id.name);
    } catch (_) {
      // ignore persist failure; state is still live in memory
    }
  }

  void switchRoom(NeuraRoomId id) {
    if (id == _currentRoom) return;
    _currentRoom = id;
    notifyListeners();
  }

  @override
  void dispose() {
    avatarController.dispose();
    voiceService.dispose();
    persona.dispose();
    emotionEngine.dispose();
    ritualEngine.dispose();
    dreamEngine.dispose();
    reflectionEngine.dispose();
    clinicalEngine.dispose();
    legacyEngine.dispose();
    super.dispose();
  }
}
