  import 'package:flutter/widgets.dart';

  import 'neura_shell_state.dart';

  /// Inherited wrapper around [NeuraShellState].
  ///
  /// This gives you a simple way to access the Neura OS shell anywhere
  /// in your widget tree via:
  ///
  ///   final shell = NeuraShellScope.of(context);
  ///
  /// The shell is a [ChangeNotifier], so widgets that call `of(context)`
  /// will rebuild when the shell notifies listeners.
  class NeuraShellScope extends InheritedNotifier<NeuraShellState> {
    const NeuraShellScope({
      super.key,
      required NeuraShellState state,
      required Widget child,
    }) : super(
            notifier: state,
            child: child,
          );

    /// Returns the nearest [NeuraShellState] above in the widget tree.
    ///
    /// This will throw an assertion in debug mode if no scope is found.
    static NeuraShellState of(BuildContext context) {
      final scope =
          context.dependOnInheritedWidgetOfExactType<NeuraShellScope>();
      assert(
        scope != null,
        'NeuraShellScope.of() called with no NeuraShellScope in the widget tree.
'
        'Make sure you have wrapped your app with NeuraShellScope, e.g.:
'
        '
'
        '  final shellState = NeuraShellState();
'
        '  runApp(NeuraShellScope(state: shellState, child: MyApp()));
',
      );
      return scope!.notifier!;
    }

    /// Returns the nearest [NeuraShellState] if present, else null.
    static NeuraShellState? maybeOf(BuildContext context) {
      final scope =
          context.dependOnInheritedWidgetOfExactType<NeuraShellScope>();
      return scope?.notifier;
    }

    @override
    bool updateShouldNotify(covariant NeuraShellScope oldWidget) {
      // InheritedNotifier already listens to notifier changes,
      // so here we only care if the notifier instance itself changed.
      return oldWidget.notifier != notifier;
    }
  }
