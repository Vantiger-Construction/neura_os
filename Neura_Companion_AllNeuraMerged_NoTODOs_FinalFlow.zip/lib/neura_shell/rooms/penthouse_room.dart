import 'package:flutter/material.dart';

    /// Main hub room – you can later embed your dashboard and live Neura here.
    class PenthouseRoom extends StatelessWidget {
      const PenthouseRoom({super.key});

      @override
      Widget build(BuildContext context) {
        final theme = Theme.of(context);
        return Center(
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.home, size: 64, color: theme.colorScheme.primary),
              const SizedBox(height: 16),
              Text(
                "Neura Penthouse",
                style: theme.textTheme.headlineSmall,
              ),
              const SizedBox(height: 8),
              Text(
                "This is Neura's main home base. You can dock your
"
                "dashboard, quick actions, and avatar here.",
                textAlign: TextAlign.center,
              ),
            ],
          ),
        );
      }
    }
