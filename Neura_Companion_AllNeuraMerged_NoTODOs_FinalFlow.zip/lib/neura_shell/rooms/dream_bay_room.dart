import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../../neura_dreams/neura_dream_engine.dart';
import '../../neura_megabuild/dream_journal_entry.dart';
import '../../neura_megabuild/neura_dream_journal_screen.dart';
import '../../neura_megabuild/dream_replay_launcher_widget.dart';

/// Dream Bay room – wired into Neura's dream engine and replay tools.
class DreamBayRoom extends StatelessWidget {
  const DreamBayRoom({super.key});

  List<DreamJournalEntry> _mapEntries(List<NeuraDreamEntry> entries) {
    // Simple mapping from the minimal engine to the richer replay model.
    return entries
        .map(
          (e) => DreamJournalEntry(
            timestamp: e.createdAt,
            transcript: e.body,
            emotion: 'calm',
            interpretation: e.title.isEmpty ? 'Untitled dream' : e.title,
            dreamscapeTheme: 'default',
          ),
        )
        .toList();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Consumer<NeuraDreamEngine>(
      builder: (context, engine, _) {
        final entries = _mapEntries(engine.entries);

        return Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Icon(Icons.nightlight_round,
                  size: 64, color: theme.colorScheme.secondary),
              const SizedBox(height: 16),
              Text(
                "Dream Bay",
                style: theme.textTheme.headlineSmall,
              ),
              const SizedBox(height: 8),
              const Text(
                "Neura stores your dreams here and can replay them
"
                "as a monthly dream show. Log a few dreams, then
"
                "launch the replay when you're ready.",
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 24),
              Wrap(
                alignment: WrapAlignment.center,
                spacing: 12,
                runSpacing: 12,
                children: [
                  ElevatedButton.icon(
                    icon: const Icon(Icons.book),
                    label: const Text("Open Dream Journal"),
                    onPressed: entries.isEmpty
                        ? null
                        : () {
                            Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (_) => NeuraDreamJournalScreen(
                                  dreamEntries: entries,
                                ),
                              ),
                            );
                          },
                  ),
                  DreamReplayLauncherWidget(entries: entries),
                ],
              ),
              const SizedBox(height: 24),
              if (entries.isEmpty)
                const Text(
                  "No dreams saved yet. Add a few via Neura's journal
"
                  "or sleep notes and they'll appear here.",
                  textAlign: TextAlign.center,
                )
              else
                Text(
                  "Dreams saved this month: ${entries.length}",
                  style: theme.textTheme.bodyLarge,
                ),
            ],
          ),
        );
      },
    );
  }
}
