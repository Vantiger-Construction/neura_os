  import 'package:flutter/material.dart';

  import '../../neura_legacy/neura_legacy_engine.dart';
  import '../../neura_legacy/neura_legacy_models.dart';
  import '../../neura_legacy/widgets/neura_legacy_entry_card.dart';
  import '../state/neura_shell_scope.dart';

  /// Legacy Hall – a place to store stories, values, and messages
  /// you want future-you (or others) to remember.
  ///
  /// This is *not* a legal document vault, not encrypted cloud storage,
  /// and not a will. It's just a structured memory space.
  class LegacyHallRoom extends StatefulWidget {
    const LegacyHallRoom({super.key});

    @override
    State<LegacyHallRoom> createState() => _LegacyHallRoomState();
  }

  class _LegacyHallRoomState extends State<LegacyHallRoom> {
    bool _initialized = false;

    @override
    void didChangeDependencies() {
      super.didChangeDependencies();
      if (_initialized) return;
      _initialized = true;
      final shell = NeuraShellScope.of(context);
      shell.legacyEngine.ensureLoaded();
    }

    @override
    Widget build(BuildContext context) {
      final shell = NeuraShellScope.of(context);
      final legacy = shell.legacyEngine;

      return AnimatedBuilder(
        animation: legacy,
        builder: (context, _) {
          final total = legacy.totalCount;
          final lastUpdated = legacy.lastUpdatedAt;
          final entries = legacy.entries;

          return Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Legacy Hall',
                  style: Theme.of(context)
                      .textTheme
                      .headlineSmall
                      ?.copyWith(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 4),
                Text(
                  'A calmer wing of Neura where you can write down the stories, '
                  'values, and messages that matter most to you.',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                const SizedBox(height: 8),
                _buildInfoNotice(context),
                const SizedBox(height: 12),
                _buildStatsRow(context, total, lastUpdated),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        icon: const Icon(Icons.auto_stories_rounded),
                        label: const Text('New memory / story'),
                        onPressed: () =>
                            _openEditor(context, category: NeuraLegacyCategory.memory),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton.tonalIcon(
                        icon: const Icon(Icons.mail_outline_rounded),
                        label: const Text('Message to future self'),
                        onPressed: () =>
                            _openEditor(context, category: NeuraLegacyCategory.message),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Expanded(
                  child: entries.isEmpty
                      ? Center(
                          child: Text(
                            'No legacy entries saved yet.
'
                            'You can start with a small story that still makes you smile, '
                            'or a short note to future-you.',
                            textAlign: TextAlign.center,
                            style:
                                Theme.of(context).textTheme.bodyMedium,
                          ),
                        )
                      : ListView.separated(
                          itemCount: entries.length,
                          separatorBuilder: (_, __) =>
                              const SizedBox(height: 8),
                          itemBuilder: (context, index) {
                            final entry = entries[index];
                            return NeuraLegacyEntryCard(
                              entry: entry,
                              onTap: () =>
                                  _showEntryDetails(context, entry),
                              onLongPress: () =>
                                  _showEntryMenu(context, entry),
                            );
                          },
                        ),
                ),
              ],
            ),
          );
        },
      );
    }

    Widget _buildInfoNotice(BuildContext context) {
      final theme = Theme.of(context);
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: theme.colorScheme.surfaceVariant.withOpacity(0.95),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Text(
          'Important: Legacy Hall is meant for reflection and storytelling. '
          'It is not a legal will, not encrypted cloud storage, and not a '
          'substitute for talking with the people you care about. '
          'If something is critical, keep your own backups outside the app too.',
          style: theme.textTheme.bodySmall,
        ),
      );
    }

    Widget _buildStatsRow(
      BuildContext context,
      int total,
      DateTime? lastUpdated,
    ) {
      final theme = Theme.of(context);
      final lastLabel = lastUpdated == null
          ? 'Nothing saved yet'
          : 'Last updated: '
            '${lastUpdated.year}-${lastUpdated.month.toString().padLeft(2, '0')}-'
            '${lastUpdated.day.toString().padLeft(2, '0')}';

      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: theme.colorScheme.primaryContainer.withOpacity(0.9),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            Icon(
              Icons.museum_rounded,
              color: theme.colorScheme.onPrimaryContainer,
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    '$total piece${total == 1 ? "" : "s"} in your Legacy Hall',
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: theme.colorScheme.onPrimaryContainer,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    lastLabel,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onPrimaryContainer
                          .withOpacity(0.9),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    Future<void> _openEditor(
      BuildContext context, {
      required NeuraLegacyCategory category,
      NeuraLegacyEntry? existing,
    }) async {
      final draft = await showModalBottomSheet<_LegacyDraft>(
        context: context,
        isScrollControlled: true,
        builder: (context) {
          return _LegacyEditorSheet(
            category: category,
            existing: existing,
          );
        },
      );

      if (draft == null) return;

      final now = DateTime.now();

      final entry = (existing ??
              NeuraLegacyEntry(
                id: 'legacy_${now.millisecondsSinceEpoch}',
                createdAt: now,
                updatedAt: now,
                category: category,
                title: draft.title,
                body: draft.body,
                tags: draft.tags,
              ))
          .copyWith(
        updatedAt: now,
        title: draft.title,
        body: draft.body,
        tags: draft.tags,
        category: draft.category,
      );

      final shell = NeuraShellScope.of(context);
      await shell.legacyEngine.upsertEntry(entry);

      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Legacy entry saved.'),
        ),
      );
    }

    void _showEntryDetails(
      BuildContext context,
      NeuraLegacyEntry entry,
    ) {
      final theme = Theme.of(context);
      final created = entry.createdAt;
      final updated = entry.updatedAt;

      final createdLabel =
          '${created.year}-${created.month.toString().padLeft(2, '0')}-'
          '${created.day.toString().padLeft(2, '0')}';

      final updatedLabel =
          '${updated.year}-${updated.month.toString().padLeft(2, '0')}-'
          '${updated.day.toString().padLeft(2, '0')}';

      showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: Text(entry.title),
            content: SizedBox(
              width: double.maxFinite,
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    Text(
                      _categoryLabel(entry.category),
                      style: theme.textTheme.labelMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                        color: theme.colorScheme.primary,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Created: $createdLabel',
                      style: theme.textTheme.bodySmall,
                    ),
                    Text(
                      'Last updated: $updatedLabel',
                      style: theme.textTheme.bodySmall,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      entry.body,
                      style: theme.textTheme.bodyMedium,
                    ),
                    if (entry.tags.isNotEmpty) ...[
                      const SizedBox(height: 12),
                      Wrap(
                        spacing: 6,
                        runSpacing: -4,
                        children: entry.tags
                            .map(
                              (t) => Chip(
                                label: Text(t),
                                visualDensity: VisualDensity.compact,
                              ),
                            )
                            .toList(),
                      ),
                    ],
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('Close'),
              ),
              TextButton(
                onPressed: () {
                  Navigator.of(context).pop();
                  _openEditor(
                    context,
                    category: entry.category,
                    existing: entry,
                  );
                },
                child: const Text('Edit'),
              ),
              TextButton(
                onPressed: () => _confirmDelete(context, entry),
                child: const Text('Delete'),
              ),
            ],
          );
        },
      );
    }

    void _showEntryMenu(BuildContext context, NeuraLegacyEntry entry) {
      showModalBottomSheet<void>(
        context: context,
        builder: (context) {
          return SafeArea(
            child: Wrap(
              children: [
                ListTile(
                  leading: const Icon(Icons.edit_rounded),
                  title: const Text('Edit'),
                  onTap: () {
                    Navigator.of(context).pop();
                    _openEditor(
                      context,
                      category: entry.category,
                      existing: entry,
                    );
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.delete_outline_rounded),
                  title: const Text('Delete'),
                  onTap: () {
                    Navigator.of(context).pop();
                    _confirmDelete(context, entry);
                  },
                ),
                ListTile(
                  leading: const Icon(Icons.close_rounded),
                  title: const Text('Cancel'),
                  onTap: () => Navigator.of(context).pop(),
                ),
              ],
            ),
          );
        },
      );
    }

    Future<void> _confirmDelete(
      BuildContext context,
      NeuraLegacyEntry entry,
    ) async {
      final confirm = await showDialog<bool>(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: const Text('Delete this entry?'),
            content: const Text(
              'This will remove it from Legacy Hall on this device. '
              'If you saved a copy anywhere else, that won’t be affected.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: const Text('Cancel'),
              ),
              FilledButton(
                onPressed: () => Navigator.of(context).pop(true),
                child: const Text('Delete'),
              ),
            ],
          );
        },
      );

      if (confirm != true) return;

      final shell = NeuraShellScope.of(context);
      await shell.legacyEngine.deleteEntry(entry.id);

      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Legacy entry deleted.'),
        ),
      );
    }

    String _categoryLabel(NeuraLegacyCategory category) {
      switch (category) {
        case NeuraLegacyCategory.memory:
          return 'Memory';
        case NeuraLegacyCategory.lesson:
          return 'Lesson';
        case NeuraLegacyCategory.message:
          return 'Message';
        case NeuraLegacyCategory.value:
          return 'Value';
        case NeuraLegacyCategory.bucketList:
          return 'Bucket list';
      }
    }
  }

  class _LegacyDraft {
    _LegacyDraft({
      required this.category,
      required this.title,
      required this.body,
      this.tags = const [],
    });

    final NeuraLegacyCategory category;
    final String title;
    final String body;
    final List<String> tags;
  }

  class _LegacyEditorSheet extends StatefulWidget {
    const _LegacyEditorSheet({
      required this.category,
      this.existing,
    });

    final NeuraLegacyCategory category;
    final NeuraLegacyEntry? existing;

    @override
    State<_LegacyEditorSheet> createState() => _LegacyEditorSheetState();
  }

  class _LegacyEditorSheetState extends State<_LegacyEditorSheet> {
    late NeuraLegacyCategory _category;
    late TextEditingController _titleController;
    late TextEditingController _bodyController;
    late TextEditingController _tagsController;

    @override
    void initState() {
      super.initState();
      _category = widget.existing?.category ?? widget.category;
      _titleController = TextEditingController(text: widget.existing?.title);
      _bodyController = TextEditingController(text: widget.existing?.body);
      _tagsController = TextEditingController(
        text: widget.existing?.tags.join(', '),
      );
    }

    @override
    void dispose() {
      _titleController.dispose();
      _bodyController.dispose();
      _tagsController.dispose();
      super.dispose();
    }

    @override
    Widget build(BuildContext context) {
      final theme = Theme.of(context);
      final bottomInset = MediaQuery.of(context).viewInsets.bottom;

      return Padding(
        padding: EdgeInsets.only(
          left: 16,
          right: 16,
          top: 16,
          bottom: bottomInset + 16,
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  margin: const EdgeInsets.only(bottom: 10),
                  decoration: BoxDecoration(
                    color: theme.dividerColor,
                    borderRadius: BorderRadius.circular(999),
                  ),
                ),
              ),
              Text(
                widget.existing == null
                    ? 'New legacy entry'
                    : 'Edit legacy entry',
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'This is a place for memories, values, and messages that matter '
                'to you. You can always edit or delete it later.',
                style: theme.textTheme.bodyMedium,
              ),
              const SizedBox(height: 16),
              Text(
                'Type',
                style: theme.textTheme.titleSmall,
              ),
              const SizedBox(height: 6),
              Wrap(
                spacing: 8,
                children: NeuraLegacyCategory.values.map((cat) {
                  final selected = _category == cat;
                  return ChoiceChip(
                    label: Text(_categoryLabel(cat)),
                    selected: selected,
                    onSelected: (_) => setState(() => _category = cat),
                  );
                }).toList(),
              ),
              const SizedBox(height: 16),
              TextField(
                controller: _titleController,
                decoration: const InputDecoration(
                  labelText: 'Title',
                  hintText: 'A short label, like "That road trip with Sam"',
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _bodyController,
                maxLines: 6,
                decoration: const InputDecoration(
                  labelText: 'Story / message / value',
                  hintText:
                      'Write in your own words. There's no wrong way to do this.',
                ),
              ),
              const SizedBox(height: 12),
              TextField(
                controller: _tagsController,
                decoration: const InputDecoration(
                  labelText: 'Tags (optional)',
                  hintText: 'Comma separated, e.g. family, courage, 2024',
                ),
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.of(context).pop(),
                      child: const Text('Cancel'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: FilledButton(
                      onPressed: _submit,
                      child: const Text('Save'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      );
    }

    void _submit() {
      final title = _titleController.text.trim();
      final body = _bodyController.text.trim();
      final tagsRaw = _tagsController.text.trim();

      if (title.isEmpty && body.isEmpty) {
        Navigator.of(context).pop();
        return;
      }

      final tags = tagsRaw.isEmpty
          ? <String>[]
          : tagsRaw.split(',').map((s) => s.trim()).where((s) => s.isNotEmpty).toList();

      Navigator.of(context).pop(
        _LegacyDraft(
          category: _category,
          title: title.isEmpty ? 'Untitled entry' : title,
          body: body,
          tags: tags,
        ),
      );
    }

    String _categoryLabel(NeuraLegacyCategory category) {
      switch (category) {
        case NeuraLegacyCategory.memory:
          return 'Memory';
        case NeuraLegacyCategory.lesson:
          return 'Lesson';
        case NeuraLegacyCategory.message:
          return 'Message';
        case NeuraLegacyCategory.value:
          return 'Value';
        case NeuraLegacyCategory.bucketList:
          return 'Bucket list';
      }
    }
  }
