  import 'package:flutter/material.dart';

  import '../../neura_brain/neura_emotion_engine.dart';
  import '../../neura_dreams/neura_dream_engine.dart';
  import '../../neura_rituals/neura_ritual_engine.dart';
  import '../../neura_reflection/neura_reflection_engine.dart';
  import '../../neura_reflection/neura_reflection_models.dart';
  import '../../neura_reflection/widgets/neura_reflection_entry_card.dart';
  import '../state/neura_shell_scope.dart';

  /// Reflection Bay – daily/weekly reflection hub.
  ///
  /// Shows:
  ///   * Today summary (rituals, dreams, emotional weather)
  ///   * Button to write or auto-generate today's reflection
  ///   * List of recent reflections
  class ReflectionBayRoom extends StatefulWidget {
    const ReflectionBayRoom({super.key});

    @override
    State<ReflectionBayRoom> createState() => _ReflectionBayRoomState();
  }

  class _ReflectionBayRoomState extends State<ReflectionBayRoom> {
    bool _initialized = false;
    late DateTime _today;

    @override
    void initState() {
      super.initState();
      final now = DateTime.now();
      _today = DateTime(now.year, now.month, now.day);
    }

    @override
    void didChangeDependencies() {
      super.didChangeDependencies();
      if (_initialized) return;
      _initialized = true;

      final shell = NeuraShellScope.of(context);
      shell.reflectionEngine.ensureLoaded();
      shell.ritualEngine.ensureLoaded();
      shell.dreamEngine.ensureLoaded();
    }

    @override
    Widget build(BuildContext context) {
      final shell = NeuraShellScope.of(context);
      final reflection = shell.reflectionEngine;
      final rituals = shell.ritualEngine;
      final dreams = shell.dreamEngine;
      final emotion = shell.emotionEngine;

      return AnimatedBuilder(
        animation: reflection,
        builder: (context, _) {
          final todaySummary = rituals.dailySummary(_today);
          final todayDreams = dreams.entriesForDay(_today).length;
          final forecast = emotion.shortForecastLabel();

          final todayReflection = reflection.latestForDay(_today);
          final recent = reflection.recentEntries(30);

          return Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Reflection Bay',
                  style: Theme.of(context)
                      .textTheme
                      .headlineSmall
                      ?.copyWith(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 4),
                Text(
                  'A quiet place to see how your days are adding up.',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                const SizedBox(height: 16),
                _buildTodaySummaryCard(
                  context,
                  todaySummary,
                  todayDreams,
                  forecast,
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        onPressed: () =>
                            _promptManualReflection(context, reflection),
                        icon: const Icon(Icons.edit_note_rounded),
                        label: Text(
                          todayReflection == null
                              ? 'Write today's reflection'
                              : 'Edit today's reflection',
                        ),
                      ),
                    ),
                    const SizedBox(width: 12),
                    IconButton.filledTonal(
                      onPressed: () =>
                          _createAutoReflection(context, reflection),
                      icon: const Icon(Icons.auto_awesome_rounded),
                      tooltip: 'Auto-generate summary for today',
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Expanded(
                  child: recent.isEmpty
                      ? Center(
                          child: Text(
                            'No reflections saved yet.
'
                            'You can start with a short note about how today felt.',
                            textAlign: TextAlign.center,
                            style:
                                Theme.of(context).textTheme.bodyMedium,
                          ),
                        )
                      : ListView.separated(
                          itemCount: recent.length,
                          separatorBuilder: (_, __) =>
                              const SizedBox(height: 8),
                          itemBuilder: (context, index) {
                            final entry = recent[index];
                            return NeuraReflectionEntryCard(
                              entry: entry,
                              onTap: () =>
                                  _showReflectionDetails(context, entry),
                              onDelete: () =>
                                  _confirmDelete(context, reflection, entry),
                            );
                          },
                        ),
                ),
              ],
            ),
          );
        },
      );
    }

    Widget _buildTodaySummaryCard(
      BuildContext context,
      NeuraRitualDailySummary summary,
      int dreamCount,
      String forecast,
    ) {
      final theme = Theme.of(context);

      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: theme.colorScheme.surfaceVariant.withOpacity(0.9),
          borderRadius: BorderRadius.circular(18),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              'Today so far',
              style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'Rituals: ${summary.completed}/${summary.totalAvailable} • '
              'Dreams logged: $dreamCount',
              style: theme.textTheme.bodyMedium,
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Icon(
                  Icons.wb_cloudy_rounded,
                  color: theme.colorScheme.primary,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    forecast,
                    style: theme.textTheme.bodyMedium,
                  ),
                ),
              ],
            ),
          ],
        ),
      );
    }

    Future<void> _promptManualReflection(
      BuildContext context,
      NeuraReflectionEngine engine,
    ) async {
      final existing = engine.latestForDay(_today);

      final headlineController = TextEditingController(
        text: existing?.headline ?? '',
      );
      final bodyController = TextEditingController(
        text: existing?.body ?? '',
      );

      final result = await showDialog<_ReflectionDraft>(
        context: context,
        builder: (context) {
          final theme = Theme.of(context);
          return AlertDialog(
            title: const Text('Today's reflection'),
            content: SizedBox(
              width: double.maxFinite,
              child: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: headlineController,
                      decoration: const InputDecoration(
                        labelText: 'Headline',
                        hintText: 'A short title for today',
                      ),
                    ),
                    const SizedBox(height: 12),
                    TextField(
                      controller: bodyController,
                      maxLines: 6,
                      decoration: const InputDecoration(
                        labelText: 'Details',
                        hintText:
                            'What stood out to you about today?'
                            ' Anything you want future-you to remember?',
                      ),
                    ),
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('Cancel'),
              ),
              FilledButton(
                onPressed: () {
                  final headline = headlineController.text.trim();
                  final body = bodyController.text.trim();
                  if (headline.isEmpty && body.isEmpty) {
                    Navigator.of(context).pop();
                    return;
                  }
                  Navigator.of(context).pop(
                    _ReflectionDraft(
                      headline: headline.isEmpty
                          ? 'A quiet but important day'
                          : headline,
                      body: body.isEmpty ? 'No details added.' : body,
                    ),
                  );
                },
                child: const Text('Save'),
              ),
            ],
          );
        },
      );

      if (result == null) return;

      final now = DateTime.now();
      final id = existing?.id ?? 'manual_${now.millisecondsSinceEpoch}';

      final entry = NeuraReflectionEntry(
        id: id,
        date: _today,
        headline: result.headline,
        body: result.body,
        moodLabel: null,
        tags: const <String>['manual'],
        autoGenerated: false,
      );

      await engine.addEntry(entry);
    }

    Future<void> _createAutoReflection(
      BuildContext context,
      NeuraReflectionEngine engine,
    ) async {
      final shell = NeuraShellScope.of(context);
      final rituals = shell.ritualEngine;
      final dreams = shell.dreamEngine;
      final emotion = shell.emotionEngine;

      final auto = engine.buildAutoSummary(
        day: _today,
        rituals: rituals,
        dreams: dreams,
        emotion: emotion,
      );

      await engine.addEntry(auto);

      if (!mounted) return;

      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Neura drafted a summary for today.'),
        ),
      );
    }

    void _showReflectionDetails(
      BuildContext context,
      NeuraReflectionEntry entry,
    ) {
      showDialog(
        context: context,
        builder: (context) {
          final theme = Theme.of(context);
          final date = entry.date;
          final dateLabel =
              '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')}';

          return AlertDialog(
            title: Text(entry.headline),
            content: SizedBox(
              width: double.maxFinite,
              child: SingleChildScrollView(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      dateLabel,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.hintColor,
                      ),
                    ),
                    const SizedBox(height: 8),
                    Text(
                      entry.body,
                      style: theme.textTheme.bodyMedium,
                    ),
                    if (entry.tags.isNotEmpty) ...[
                      const SizedBox(height: 12),
                      Wrap(
                        spacing: 6,
                        children: entry.tags
                            .map(
                              (t) => Chip(
                                label: Text(t),
                                visualDensity: VisualDensity.compact,
                              ),
                            )
                            .toList(),
                      ),
                    ],
                    if (entry.moodLabel != null) ...[
                      const SizedBox(height: 12),
                      Text(
                        'Mood note:',
                        style: theme.textTheme.titleSmall,
                      ),
                      const SizedBox(height: 4),
                      Text(entry.moodLabel!),
                    ],
                  ],
                ),
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('Close'),
              ),
            ],
          );
        },
      );
    }

    Future<void> _confirmDelete(
      BuildContext context,
      NeuraReflectionEngine engine,
      NeuraReflectionEntry entry,
    ) async {
      final confirm = await showDialog<bool>(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: const Text('Delete reflection?'),
            content: const Text(
              'This will remove the reflection permanently from Neura's memory.',
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(false),
                child: const Text('Cancel'),
              ),
              FilledButton(
                onPressed: () => Navigator.of(context).pop(true),
                child: const Text('Delete'),
              ),
            ],
          );
        },
      );

      if (confirm != true) return;

      await engine.deleteEntry(entry.id);
    }
  }

  class _ReflectionDraft {
    _ReflectionDraft({
      required this.headline,
      required this.body,
    });

    final String headline;
    final String body;
  }
