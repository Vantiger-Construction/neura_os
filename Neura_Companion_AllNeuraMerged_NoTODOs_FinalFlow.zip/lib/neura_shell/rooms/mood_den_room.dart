import 'package:flutter/material.dart';

import '../../neura_avatar/neura_avatar_mood.dart';
import '../../neura_rituals/neura_ritual_engine.dart';
import '../../neura_rituals/neura_ritual_models.dart';
import '../state/neura_shell_scope.dart';

/// Mood Den – daily ritual hub + quick emotional summary.
class MoodDenRoom extends StatefulWidget {
  const MoodDenRoom({super.key});

  @override
  State<MoodDenRoom> createState() => _MoodDenRoomState();
}

class _MoodDenRoomState extends State<MoodDenRoom> {
  bool _initialized = false;
  late DateTime _today;

  @override
  void initState() {
    super.initState();
    _today = DateTime.now();
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_initialized) return;
    _initialized = true;

    final shell = NeuraShellScope.of(context);
    shell.ritualEngine.ensureLoaded();
  }

  @override
  Widget build(BuildContext context) {
    final shell = NeuraShellScope.of(context);
    final rituals = shell.ritualEngine;
    final emotion = shell.emotionEngine;

    return AnimatedBuilder(
      animation: rituals,
      builder: (context, _) {
        final summary = rituals.dailySummary(_today);
        final forecast = emotion.shortForecastLabel();

        return Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Mood Den',
                style: Theme.of(context)
                    .textTheme
                    .headlineSmall
                    ?.copyWith(fontWeight: FontWeight.bold),
              ),
              const SizedBox(height: 4),
              Text(
                'Your daily rituals, streaks, and emotional weather.',
                style: Theme.of(context).textTheme.bodyMedium,
              ),
              const SizedBox(height: 16),
              _buildSummaryRow(context, summary, rituals.currentStreak()),
              const SizedBox(height: 12),
              _buildForecastCard(context, forecast),
              const SizedBox(height: 16),
              Expanded(
                child: ListView.separated(
                  itemCount: rituals.rituals.length,
                  separatorBuilder: (_, __) => const SizedBox(height: 8),
                  itemBuilder: (context, index) {
                    final ritual = rituals.rituals[index];
                    return _buildRitualCard(context, ritual, rituals);
                  },
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildSummaryRow(
    BuildContext context,
    NeuraRitualDailySummary summary,
    int streak,
  ) {
    final theme = Theme.of(context);

    return Row(
      children: [
        Expanded(
          child: Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: theme.colorScheme.primaryContainer.withOpacity(0.7),
              borderRadius: BorderRadius.circular(18),
            ),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  '${summary.completed}/${summary.totalAvailable} rituals done today',
                  style: theme.textTheme.titleMedium?.copyWith(
                    color: theme.colorScheme.onPrimaryContainer,
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 4),
                LinearProgressIndicator(
                  value: summary.totalAvailable == 0
                      ? 0
                      : summary.completed / summary.totalAvailable,
                  backgroundColor: theme.colorScheme.onPrimaryContainer
                      .withOpacity(0.2),
                  valueColor: AlwaysStoppedAnimation<Color>(
                    theme.colorScheme.onPrimaryContainer,
                  ),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(width: 12),
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(
            color: theme.colorScheme.secondaryContainer.withOpacity(0.8),
            borderRadius: BorderRadius.circular(18),
          ),
          child: Column(
            children: [
              Text(
                'Streak',
                style: theme.textTheme.labelSmall?.copyWith(
                  color: theme.colorScheme.onSecondaryContainer,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                '$streak',
                style: theme.textTheme.headlineSmall?.copyWith(
                  color: theme.colorScheme.onSecondaryContainer,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 2),
              Text(
                'days',
                style: theme.textTheme.labelSmall?.copyWith(
                  color: theme.colorScheme.onSecondaryContainer,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildForecastCard(BuildContext context, String forecast) {
    final theme = Theme.of(context);
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceVariant.withOpacity(0.85),
        borderRadius: BorderRadius.circular(18),
      ),
      child: Row(
        children: [
          Icon(
            Icons.wb_cloudy_rounded,
            color: theme.colorScheme.primary,
          ),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              forecast,
              style: theme.textTheme.bodyMedium,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildRitualCard(
    BuildContext context,
    NeuraRitualDefinition ritual,
    NeuraRitualEngine engine,
  ) {
    final theme = Theme.of(context);
    final isFeatured = ritual.featured;

    return Card(
      elevation: isFeatured ? 5 : 2,
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
      ),
      child: Padding(
        padding: const EdgeInsets.all(14),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  _mapIcon(ritual.icon),
                  color: theme.colorScheme.primary,
                ),
                const SizedBox(width: 10),
                Expanded(
                  child: Text(
                    ritual.title,
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight:
                          isFeatured ? FontWeight.w700 : FontWeight.w600,
                    ),
                  ),
                ),
                _buildTypeChip(context, ritual.type),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              ritual.description,
              style: theme.textTheme.bodyMedium?.copyWith(
                color:
                    theme.textTheme.bodyMedium?.color?.withOpacity(0.9),
              ),
            ),
            const SizedBox(height: 10),
            Align(
              alignment: Alignment.centerRight,
              child: FilledButton.icon(
                onPressed: () => _runRitualFlow(context, ritual, engine),
                icon: const Icon(Icons.check_circle_outline_rounded),
                label: const Text('Complete'),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildTypeChip(BuildContext context, NeuraRitualType type) {
    final theme = Theme.of(context);
    String label;
    Color color;

    switch (type) {
      case NeuraRitualType.mind:
        label = 'Mind';
        color = Colors.indigoAccent;
        break;
      case NeuraRitualType.body:
        label = 'Body';
        color = Colors.greenAccent.shade400;
        break;
      case NeuraRitualType.soul:
        label = 'Soul';
        color = Colors.deepPurpleAccent.shade200;
        break;
      case NeuraRitualType.connection:
        label = 'Connection';
        color = Colors.orangeAccent.shade200;
        break;
      case NeuraRitualType.custom:
        label = 'Custom';
        color = theme.colorScheme.primary;
        break;
    }

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
      decoration: BoxDecoration(
        color: color.withOpacity(0.16),
        borderRadius: BorderRadius.circular(999),
        border: Border.all(color: color.withOpacity(0.7)),
      ),
      child: Text(
        label,
        style: theme.textTheme.labelSmall?.copyWith(
          color: color,
          fontWeight: FontWeight.w600,
        ),
      ),
    );
  }

  Future<void> _runRitualFlow(
    BuildContext context,
    NeuraRitualDefinition ritual,
    NeuraRitualEngine engine,
  ) async {
    final shell = NeuraShellScope.of(context);
    final emotion = shell.emotionEngine;
    final persona = shell.persona;

    final result = await showModalBottomSheet<_RitualResult>(
      context: context,
      isScrollControlled: true,
      builder: (context) {
        return _RitualCompletionSheet(ritual: ritual);
      },
    );

    if (result == null) return;

    await engine.logCompletion(
      ritual: ritual,
      moodBefore: result.beforeMood,
      moodAfter: result.afterMood,
      note: result.note,
    );

    // Lightly nudge persona + emotion.
    persona.registerCheckIn(positive: true);
    persona.updateLongestStreak(engine.currentStreak());

    emotion.recordSnapshot(
      mood: result.afterMood,
      energy: 0.5,
      calm: result.afterMood == NeuraAvatarMood.anxious ? 0.3 : 0.6,
      tension: result.afterMood == NeuraAvatarMood.anxious ? 0.7 : 0.3,
    );
  }

  IconData _mapIcon(String? icon) {
    switch (icon) {
      case 'self_improvement':
        return Icons.self_improvement_rounded;
      case 'fitness_center':
        return Icons.fitness_center_rounded;
      case 'bedtime':
        return Icons.bedtime_rounded;
      case 'chat_bubble':
        return Icons.chat_bubble_rounded;
      case 'directions_walk':
        return Icons.directions_walk_rounded;
      default:
        return Icons.checklist_rounded;
    }
  }
}

class _RitualResult {
  _RitualResult({
    required this.beforeMood,
    required this.afterMood,
    this.note,
  });

  final NeuraAvatarMood beforeMood;
  final NeuraAvatarMood afterMood;
  final String? note;
}

class _RitualCompletionSheet extends StatefulWidget {
  const _RitualCompletionSheet({
    required this.ritual,
  });

  final NeuraRitualDefinition ritual;

  @override
  State<_RitualCompletionSheet> createState() =>
      _RitualCompletionSheetState();
}

class _RitualCompletionSheetState extends State<_RitualCompletionSheet> {
  NeuraAvatarMood? _before;
  NeuraAvatarMood? _after;
  final TextEditingController _noteController = TextEditingController();

  @override
  void dispose() {
    _noteController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final bottom = MediaQuery.of(context).viewInsets.bottom;

    return Padding(
      padding: EdgeInsets.only(
        left: 16,
        right: 16,
        top: 16,
        bottom: bottom + 16,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Center(
              child: Container(
                width: 40,
                height: 4,
                margin: const EdgeInsets.only(bottom: 12),
                decoration: BoxDecoration(
                  color: theme.dividerColor,
                  borderRadius: BorderRadius.circular(999),
                ),
              ),
            ),
            Text(
              widget.ritual.title,
              style: theme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'Quick check-in with Neura about how this felt.',
              style: theme.textTheme.bodyMedium,
            ),
            const SizedBox(height: 16),
            Text(
              'Before starting, I felt…',
              style: theme.textTheme.titleSmall,
            ),
            const SizedBox(height: 8),
            _buildMoodChips(
              context,
              groupValue: _before,
              onChanged: (m) => setState(() => _before = m),
            ),
            const SizedBox(height: 16),
            Text(
              'Now I feel…',
              style: theme.textTheme.titleSmall,
            ),
            const SizedBox(height: 8),
            _buildMoodChips(
              context,
              groupValue: _after,
              onChanged: (m) => setState(() => _after = m),
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _noteController,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'Optional note',
                hintText: 'Anything you want Neura to remember?',
              ),
            ),
            const SizedBox(height: 16),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () => Navigator.of(context).pop(),
                    child: const Text('Cancel'),
                  ),
                ),
                const SizedBox(width: 12),
                Expanded(
                  child: FilledButton(
                    onPressed:
                        _before == null || _after == null ? null : _submit,
                    child: const Text('Save'),
                  ),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildMoodChips(
    BuildContext context, {
    required NeuraAvatarMood? groupValue,
    required ValueChanged<NeuraAvatarMood> onChanged,
  }) {
    final theme = Theme.of(context);

    NeuraAvatarMood moodFromLabel(String label) {
      switch (label) {
        case 'Calm':
          return NeuraAvatarMood.calm;
        case 'Happy':
          return NeuraAvatarMood.happy;
        case 'Tired':
          return NeuraAvatarMood.tired;
        case 'Stressed':
          return NeuraAvatarMood.anxious;
        case 'Sad':
          return NeuraAvatarMood.sad;
        default:
          return NeuraAvatarMood.neutral;
      }
    }

    final options = <String>['Calm', 'Happy', 'Tired', 'Stressed', 'Sad'];

    return Wrap(
      spacing: 8,
      runSpacing: -4,
      children: options.map((label) {
        final mood = moodFromLabel(label);
        final selected = groupValue == mood;

        return ChoiceChip(
          label: Text(label),
          selected: selected,
          onSelected: (_) => onChanged(mood),
          selectedColor: theme.colorScheme.primaryContainer,
        );
      }).toList(),
    );
  }

  void _submit() {
    if (_before == null || _after == null) return;
    Navigator.of(context).pop(
      _RitualResult(
        beforeMood: _before!,
        afterMood: _after!,
        note: _noteController.text.trim().isEmpty
            ? null
            : _noteController.text.trim(),
      ),
    );
  }
}
