import 'package:flutter/foundation.dart';


class NeuraEmotionSample {
  final DateTime timestamp;
  final double valence;
  final double arousal;

  const NeuraEmotionSample({
    required this.timestamp,
    required this.valence,
    required this.arousal,
  });
}


/// Lightweight affect model: valence (sad -> happy), arousal (tired -> wired).
class NeuraEmotionEngine extends ChangeNotifier {
  double _valence = 0.0; // -1..1
  double _arousal = 0.0; // -1..1
  final List<NeuraEmotionSample> _history = <NeuraEmotionSample>[];

  double get valence => _valence;
  double get arousal => _arousal;

  /// Read-only snapshot of recorded affect samples.
  List<NeuraEmotionSample> get history => List.unmodifiable(_history);

  /// Returns samples from the last [days] days.
  List<NeuraEmotionSample> historyForDays(int days) {
    if (days <= 0) return const [];
    final cutoff = DateTime.now().subtract(Duration(days: days));
    return _history.where((s) => s.timestamp.isAfter(cutoff)).toList();
  }

  /// Update affect and notify listeners.
  void setAffect({required double valence, required double arousal}) {
    final v = valence.clamp(-1.0, 1.0);
    final a = arousal.clamp(-1.0, 1.0);
    if (v == _valence && a == _arousal) return;
    _valence = v;
    _arousal = a;
    _history.add(
      NeuraEmotionSample(
        timestamp: DateTime.now(),
        valence: _valence,
        arousal: _arousal,
      ),
    );
    // Keep a bounded history so memory usage stays reasonable.
    if (_history.length > 500) {
      _history.removeRange(0, _history.length - 500);
    }
    notifyListeners();
  }

  /// Convenience helpers.
  bool get isLowEnergy => _arousal < -0.3;
  bool get isStressed => _arousal > 0.4 && _valence < 0;
  bool get isGlowUp => _valence > 0.5 && _arousal >= 0;
}
