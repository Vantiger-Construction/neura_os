using UnityEngine;

/// <summary>
/// Drives Neura visuals + posture + world lighting from mood+energy.
/// Call SetState() when BridgeRouter updates state.
/// </summary>
public class EmotionDriver : MonoBehaviour
{
    public string mood = "calm";
    [Range(0f,1f)] public float energy = 0.7f;

    public NeuraBreathingController breathing;
    public NeuraGlowController glow;
    public LightingMoodController worldLighting;
    public Animator animator;

    [Header("Animator")]
    public string paramPosture = "posture"; // float 0..1
    public bool setPosture = true;

    void Awake()
    {
        if (breathing == null) breathing = GetComponentInChildren<NeuraBreathingController>(true);
        if (glow == null) glow = GetComponentInChildren<NeuraGlowController>(true);
        if (animator == null) animator = GetComponentInChildren<Animator>(true);
        if (worldLighting == null) worldLighting = FindObjectOfType<LightingMoodController>();
    }

    public void SetState(string newMood, float newEnergy)
    {
        mood = string.IsNullOrWhiteSpace(newMood) ? "calm" : newMood;
        energy = Mathf.Clamp01(newEnergy);
        ApplyNow();
    }

    public void ApplyNow()
    {
        var p = EmotionLibrary.Resolve(mood, energy);
        if (breathing != null) breathing.SetBreathingRate(p.breathingRate);
        if (glow != null) glow.ApplyGlow(p.glowColor, p.glowIntensity);
        if (worldLighting != null) worldLighting.ApplyProfile(p);

        if (setPosture && animator != null && HasFloat(animator, paramPosture))
            animator.SetFloat(paramPosture, p.posture);
    }

    private bool HasFloat(Animator a, string name)
    {
        foreach (var p in a.parameters)
            if (p.type == AnimatorControllerParameterType.Float && p.name == name) return true;
        return false;
    }
}
