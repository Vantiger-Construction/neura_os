using UnityEngine;

/// <summary>
/// Drives emissive/glow via MaterialPropertyBlock. Works if materials expose
/// _EmissionColor or _EmissiveColor.
/// </summary>
public class NeuraGlowController : MonoBehaviour
{
    public Renderer[] renderers;
    public string[] emissionProps = new[] { "_EmissionColor", "_EmissiveColor" };

    private MaterialPropertyBlock _mpb;

    void Awake()
    {
        _mpb = new MaterialPropertyBlock();
        if (renderers == null || renderers.Length == 0)
            renderers = GetComponentsInChildren<Renderer>(true);
    }

    public void ApplyGlow(Color color, float intensity)
    {
        intensity = Mathf.Clamp01(intensity);
        var c = color * Mathf.LinearToGammaSpace(Mathf.Lerp(0.25f, 3.0f, intensity));

        foreach (var r in renderers)
        {
            if (r == null) continue;
            r.GetPropertyBlock(_mpb);

            foreach (var prop in emissionProps)
                if (r.sharedMaterial != null && r.sharedMaterial.HasProperty(prop))
                    _mpb.SetColor(prop, c);

            r.SetPropertyBlock(_mpb);
        }
    }
}
