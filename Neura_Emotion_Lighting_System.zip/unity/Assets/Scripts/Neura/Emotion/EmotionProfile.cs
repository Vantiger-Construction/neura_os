using UnityEngine;

[System.Serializable]
public class EmotionProfile
{
    public string mood = "calm";
    [Range(0f,1f)] public float energy = 0.7f;

    [Header("Avatar")]
    public Color glowColor = new Color(0.35f, 0.8f, 1f, 1f);
    [Range(0f,1f)] public float glowIntensity = 0.6f;
    [Range(0f,2f)] public float breathingRate = 1.0f; // 1.0 = baseline

    [Header("World Lighting")]
    [Range(0f,2f)] public float exposure = 1.0f;
    [Range(0f,2f)] public float lightIntensity = 1.0f;
    public Color ambientColor = new Color(0.2f,0.25f,0.3f,1f);

    [Header("Animation")]
    [Range(0f,1f)] public float posture = 0.5f; // 0 relaxed, 1 alert
}
