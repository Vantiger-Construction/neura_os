using UnityEngine;

/// <summary>
/// Maps mood keyword -> emotion profile. Keep it small and tweakable.
/// </summary>
public static class EmotionLibrary
{
    public static EmotionProfile Resolve(string mood, float energy)
    {
        mood = (mood ?? "calm").Trim().ToLowerInvariant();
        energy = Mathf.Clamp01(energy);

        var p = new EmotionProfile { mood = mood, energy = energy };

        // Base scaling by energy
        p.breathingRate = Mathf.Lerp(0.85f, 1.35f, energy);
        p.glowIntensity = Mathf.Lerp(0.35f, 0.95f, energy);
        p.lightIntensity = Mathf.Lerp(0.85f, 1.25f, energy);
        p.exposure = Mathf.Lerp(0.95f, 1.10f, energy);
        p.posture = Mathf.Lerp(0.35f, 0.75f, energy);

        switch (mood)
        {
            case "anxious":
            case "anxiety":
                p.glowColor = new Color(1f, 0.65f, 0.2f, 1f);
                p.ambientColor = new Color(0.25f, 0.20f, 0.18f, 1f);
                p.breathingRate *= 1.25f;
                p.posture = Mathf.Clamp01(p.posture + 0.20f);
                p.exposure *= 0.98f;
                break;

            case "sad":
            case "down":
                p.glowColor = new Color(0.35f, 0.55f, 1f, 1f);
                p.ambientColor = new Color(0.15f, 0.18f, 0.25f, 1f);
                p.breathingRate *= 0.90f;
                p.posture = Mathf.Clamp01(p.posture - 0.15f);
                p.lightIntensity *= 0.90f;
                break;

            case "angry":
            case "frustrated":
                p.glowColor = new Color(1f, 0.2f, 0.2f, 1f);
                p.ambientColor = new Color(0.22f, 0.12f, 0.12f, 1f);
                p.breathingRate *= 1.15f;
                p.posture = Mathf.Clamp01(p.posture + 0.25f);
                p.exposure *= 0.96f;
                break;

            case "focused":
            case "flow":
                p.glowColor = new Color(0.25f, 1f, 0.65f, 1f);
                p.ambientColor = new Color(0.12f, 0.18f, 0.14f, 1f);
                p.breathingRate *= 0.95f;
                p.posture = Mathf.Clamp01(p.posture + 0.10f);
                p.exposure *= 1.02f;
                break;

            case "happy":
            case "joy":
                p.glowColor = new Color(1f, 0.95f, 0.35f, 1f);
                p.ambientColor = new Color(0.20f, 0.20f, 0.12f, 1f);
                p.breathingRate *= 1.05f;
                p.posture = Mathf.Clamp01(p.posture + 0.05f);
                p.lightIntensity *= 1.10f;
                p.exposure *= 1.03f;
                break;

            default:
                p.glowColor = new Color(0.35f, 0.8f, 1f, 1f);
                p.ambientColor = new Color(0.18f, 0.22f, 0.28f, 1f);
                break;
        }
        return p;
    }
}
