using UnityEngine;

/// <summary>
/// Subtle "alive" motion: scales a transform to simulate breathing.
/// Assign chest/upper-spine for best results.
/// </summary>
public class NeuraBreathingController : MonoBehaviour
{
    public Transform breathingTransform;
    [Range(0f, 0.08f)] public float amplitude = 0.02f;
    [Range(0.2f, 2.0f)] public float baseRate = 1.0f;

    private Vector3 _baseScale;
    private float _rate = 1.0f;

    void Start()
    {
        if (breathingTransform == null) breathingTransform = transform;
        _baseScale = breathingTransform.localScale;
    }

    void Update()
    {
        if (breathingTransform == null) return;
        var t = Time.time * baseRate * _rate;
        var wave = Mathf.Sin(t) * 0.5f + 0.5f; // 0..1
        breathingTransform.localScale = _baseScale * (1f + wave * amplitude);
    }

    public void SetBreathingRate(float rate) => _rate = Mathf.Clamp(rate, 0.2f, 2.0f);
}
