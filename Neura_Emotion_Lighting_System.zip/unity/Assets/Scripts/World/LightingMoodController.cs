using UnityEngine;

/// <summary>
/// Mood-driven ambient + key light. Exposure is a placeholder for URP/HDRP Volumes.
/// </summary>
public class LightingMoodController : MonoBehaviour
{
    public Light keyLight;
    public bool driveAmbient = true;
    [Range(0.1f, 20f)] public float lerpSpeed = 6f;

    private Color _targetAmbient;
    private float _targetKeyIntensity;

    void Start()
    {
        if (keyLight == null) keyLight = FindObjectOfType<Light>();
        _targetAmbient = RenderSettings.ambientLight;
        _targetKeyIntensity = keyLight != null ? keyLight.intensity : 1f;
    }

    void Update()
    {
        var t = Time.deltaTime * lerpSpeed;
        if (driveAmbient)
            RenderSettings.ambientLight = Color.Lerp(RenderSettings.ambientLight, _targetAmbient, t);
        if (keyLight != null)
            keyLight.intensity = Mathf.Lerp(keyLight.intensity, _targetKeyIntensity, t);
    }

    public void ApplyProfile(EmotionProfile p)
    {
        if (p == null) return;
        _targetAmbient = p.ambientColor;
        _targetKeyIntensity = p.lightIntensity;
    }
}
