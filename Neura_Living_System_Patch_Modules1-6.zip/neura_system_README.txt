
This patch contains:
• Module 1–3: Memory, Emotion, Behavior (already installed)
• Module 4: Presence (Apartment OS)
• Module 5: Avatar Idle & Motion
• Module 6: Speech Readiness Layer

Drop into lib/core/neura_system + lib/core/presence + lib/core/avatar + lib/core/speech
