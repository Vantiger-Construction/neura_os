using UnityEngine;

/// <summary>
/// Orchestrates "click prop -> Neura walks there -> emit PROP_ACTIVATED".
/// Attach this to a scene singleton (e.g., NeuraWorldRoot).
/// Wire references in Inspector.
/// </summary>
public class NeuraCinematicOrchestrator : MonoBehaviour
{
    [Header("References")]
    public NeuraController_Nav neuraNav;
    public TargetRegistry registry;

    [Header("Events")]
    public bool emitActivatedAfterArrive = true;

    void Awake()
    {
        if (neuraNav == null) neuraNav = FindObjectOfType<NeuraController_Nav>();
        if (registry == null) registry = FindObjectOfType<TargetRegistry>();
    }

    public void OnPropSelected(string propId)
    {
        if (string.IsNullOrWhiteSpace(propId))
            return;

        var target = registry != null ? registry.Get(propId) : null;

        // If no target registered, just emit click as-is.
        if (target == null || neuraNav == null)
        {
            BridgeRouter.Instance?.EmitEvent("PROP_CLICKED", propId);
            if (emitActivatedAfterArrive)
                BridgeRouter.Instance?.EmitEvent("PROP_ACTIVATED", propId);
            return;
        }

        // Walk Neura there, then emit activated event.
        neuraNav.MoveTo(target, () =>
        {
            BridgeRouter.Instance?.EmitEvent("NEURA_ARRIVED", propId);
            if (emitActivatedAfterArrive)
                BridgeRouter.Instance?.EmitEvent("PROP_ACTIVATED", propId);
        });

        BridgeRouter.Instance?.EmitEvent("PROP_SELECTED", propId);
    }
}
