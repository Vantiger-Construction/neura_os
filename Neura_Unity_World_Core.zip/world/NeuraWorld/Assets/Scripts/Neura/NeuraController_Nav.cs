using System;
using UnityEngine;
using UnityEngine.AI;

/// <summary>
/// Minimal NavMesh locomotion for Neura.
/// Requirements:
///  - A NavMesh baked in the scene
///  - Neura GameObject has a NavMeshAgent
///  - (Optional) Animator with "Speed" float param and triggers for gestures
/// </summary>
[RequireComponent(typeof(NavMeshAgent))]
public class NeuraController_Nav : MonoBehaviour
{
    [Header("Animation (optional)")]
    public Animator animator;
    public string speedParam = "Speed";
    public string arriveTrigger = "Arrive";   // optional trigger
    public string readyTrigger = "Ready";     // optional trigger

    [Header("Arrive Tuning")]
    public float arriveDistance = 0.35f;
    public float faceTargetTurnSpeed = 540f; // degrees/sec
    public float readyDelaySeconds = 0.2f;

    private NavMeshAgent _agent;
    private Action _onArrived;
    private Transform _currentTarget;
    private bool _isArriving;

    void Awake()
    {
        _agent = GetComponent<NavMeshAgent>();
        if (animator == null) animator = GetComponentInChildren<Animator>();
    }

    void Update()
    {
        if (animator != null)
        {
            var spd = _agent.velocity.magnitude;
            animator.SetFloat(speedParam, spd);
        }

        if (_currentTarget == null) return;

        // Consider arrived when agent is close enough and path is done.
        if (!_agent.pathPending &&
            _agent.remainingDistance != Mathf.Infinity &&
            _agent.remainingDistance <= Mathf.Max(arriveDistance, _agent.stoppingDistance))
        {
            if (!_isArriving)
            {
                _isArriving = true;
                _agent.isStopped = true;
                if (animator != null && !string.IsNullOrEmpty(arriveTrigger))
                    animator.SetTrigger(arriveTrigger);

                // Face target
                FaceTarget();

                // small delay then ready gesture and callback
                Invoke(nameof(DoReadyAndCallback), readyDelaySeconds);
            }
        }
    }

    public void MoveTo(Transform target, Action onArrived = null)
    {
        if (target == null) return;

        _agent.isStopped = false;
        _isArriving = false;
        _currentTarget = target;
        _onArrived = onArrived;

        _agent.SetDestination(target.position);
    }

    private void FaceTarget()
    {
        if (_currentTarget == null) return;
        var dir = (_currentTarget.position - transform.position);
        dir.y = 0f;
        if (dir.sqrMagnitude < 0.0001f) return;

        var desired = Quaternion.LookRotation(dir.normalized);
        transform.rotation = Quaternion.RotateTowards(transform.rotation, desired, faceTargetTurnSpeed * Time.deltaTime);
    }

    private void DoReadyAndCallback()
    {
        if (animator != null && !string.IsNullOrEmpty(readyTrigger))
            animator.SetTrigger(readyTrigger);

        var cb = _onArrived;
        _onArrived = null;
        _currentTarget = null;
        _isArriving = false;

        cb?.Invoke();
    }
}
