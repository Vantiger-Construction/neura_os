using UnityEngine;
using UnityEngine.AI;

/// <summary>
/// Minimal Neura controller:
/// - Animator parameters: mood (int), energy (float), isSpeaking (bool)
/// - Optional NavMeshAgent for walking.
/// - Simple API: SetMood, SetEnergy, PlayAnim, MoveTo, LookAt.
/// </summary>
public class NeuraController : MonoBehaviour
{
    [Header("Refs")]
    public Animator animator;
    public NavMeshAgent agent;
    public Transform lookAtTarget;

    [Header("Tuning")]
    public float lookAtSpeed = 7f;

    // Mood mapping for v0
    // calm=0, happy=1, anxious=2, focused=3, sad=4
    public void SetMood(string mood)
    {
        int id = mood switch
        {
            "happy" => 1,
            "anxious" => 2,
            "focused" => 3,
            "sad" => 4,
            _ => 0
        };

        if (animator != null) animator.SetInteger("mood", id);
    }

    public void SetEnergy(float energy01)
    {
        if (animator != null) animator.SetFloat("energy", Mathf.Clamp01(energy01));
        if (agent != null) agent.speed = Mathf.Lerp(1.1f, 3.2f, Mathf.Clamp01(energy01));
    }

    public void SetSpeaking(bool speaking)
    {
        if (animator != null) animator.SetBool("isSpeaking", speaking);
    }

    public void PlayAnim(string triggerName)
    {
        if (animator == null || string.IsNullOrWhiteSpace(triggerName)) return;
        animator.SetTrigger(triggerName);
    }

    public void MoveTo(Vector3 position)
    {
        if (agent == null) return;
        agent.isStopped = false;
        agent.SetDestination(position);
    }

    public void LookAt(Transform target)
    {
        lookAtTarget = target;
    }

    public void LookAtTargetName(string gameObjectName)
    {
        if (string.IsNullOrWhiteSpace(gameObjectName)) { lookAtTarget = null; return; }
        var obj = GameObject.Find(gameObjectName);
        if (obj != null) lookAtTarget = obj.transform;
    }

    void LateUpdate()
    {
        if (lookAtTarget == null) return;

        var dir = (lookAtTarget.position - transform.position);
        dir.y = 0;
        if (dir.sqrMagnitude < 0.0001f) return;

        var targetRot = Quaternion.LookRotation(dir.normalized, Vector3.up);
        transform.rotation = Quaternion.Slerp(transform.rotation, targetRot, Time.deltaTime * lookAtSpeed);
    }
}
