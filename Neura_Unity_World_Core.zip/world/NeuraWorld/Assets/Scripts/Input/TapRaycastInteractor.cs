using UnityEngine;

/// Drop this on your Main Camera. Lets Android taps click props using a Physics raycast.
public class TapRaycastInteractor : MonoBehaviour
{
    public Camera cam;
    public LayerMask interactMask = ~0;

    private void Awake()
    {
        if (cam == null) cam = Camera.main;
    }

    private void Update()
    {
        if (Input.touchCount > 0 && Input.GetTouch(0).phase == TouchPhase.Began)
        {
            var t = Input.GetTouch(0);
            Ray r = cam.ScreenPointToRay(t.position);
            if (Physics.Raycast(r, out var hit, 100f, interactMask))
            {
                var prop = hit.collider.GetComponentInParent<NeuraPropInteractable>();
                if (prop != null) prop.Trigger();
            }
        }

#if UNITY_STANDALONE || UNITY_EDITOR
        if (Input.GetMouseButtonDown(0))
        {
            Ray r = cam.ScreenPointToRay(Input.mousePosition);
            if (Physics.Raycast(r, out var hit, 100f, interactMask))
            {
                var prop = hit.collider.GetComponentInParent<NeuraPropInteractable>();
                if (prop != null) prop.Trigger();
            }
        }
#endif
    }
}
