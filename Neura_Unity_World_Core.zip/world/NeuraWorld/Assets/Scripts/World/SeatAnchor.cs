using UnityEngine;

/// <summary>
/// A spot where Neura should align (position + facing) before an action.
/// Place this on a chair/desk anchor.
/// </summary>
public class SeatAnchor : MonoBehaviour
{
    public bool snapRotation = true;
    public float rotationSpeed = 8f;

    public void Align(Transform actor)
    {
        actor.position = transform.position;
        if (snapRotation)
            actor.rotation = transform.rotation;
    }

    public void SmoothAlign(Transform actor)
    {
        actor.position = transform.position;
        if (!snapRotation)
        {
            actor.rotation = Quaternion.Slerp(actor.rotation, transform.rotation, Time.deltaTime * rotationSpeed);
        }
    }
}
