using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Minimal world manager:
/// - Rooms are "anchors" registered in inspector.
/// - GoToRoom teleports camera and moves Neura to that anchor.
/// - Add rooms by dropping Transforms into the list.
/// </summary>
public class WorldManager : MonoBehaviour
{
    [System.Serializable]
    public class RoomAnchor
    {
        public string roomName;
        public Transform anchor;
        public Transform cameraSpot;
    }

    public List<RoomAnchor> rooms = new();
    public NeuraController neura;
    public Camera mainCamera;

    private readonly Dictionary<string, RoomAnchor> _map = new();

    void Awake()
    {
        foreach (var r in rooms)
        {
            if (r != null && !string.IsNullOrWhiteSpace(r.roomName) && r.anchor != null)
            {
                _map[r.roomName] = r;
            }
        }
        if (mainCamera == null) mainCamera = Camera.main;
    }

    public void GoToRoom(string roomName)
    {
        if (string.IsNullOrWhiteSpace(roomName)) return;
        if (!_map.TryGetValue(roomName, out var room))
        {
            Debug.LogWarning($"[World] Unknown room: {roomName}");
            return;
        }

        // Move Neura
        if (neura != null && room.anchor != null)
        {
            // Prefer NavMesh move if available; otherwise snap.
            if (neura.agent != null && neura.agent.enabled)
                neura.MoveTo(room.anchor.position);
            else
                neura.transform.position = room.anchor.position;

            neura.LookAt(room.cameraSpot != null ? room.cameraSpot : null);
        }

        // Move camera
        if (mainCamera != null && room.cameraSpot != null)
        {
            mainCamera.transform.position = room.cameraSpot.position;
            mainCamera.transform.rotation = room.cameraSpot.rotation;
        }

        BridgeRouter.Instance?.EmitEvent("ROOM_ENTERED", roomName);
    }
}
