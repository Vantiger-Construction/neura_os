using UnityEngine;

/// <summary>
/// Attach to any prop collider. Set propId (e.g., "journalDesk").
/// Requires TapRaycastInteractor to call Interact() on hit.
/// </summary>
public class NeuraPropInteractable : MonoBehaviour
{
    public string propId = "journalDesk";

    public void Interact()
    {
        var orch = FindObjectOfType<NeuraCinematicOrchestrator>();
        if (orch != null)
        {
            orch.OnPropSelected(propId);
        }
        else
        {
            BridgeRouter.Instance?.EmitEvent("PROP_CLICKED", propId);
            BridgeRouter.Instance?.EmitEvent("PROP_ACTIVATED", propId);
        }
    }
}
