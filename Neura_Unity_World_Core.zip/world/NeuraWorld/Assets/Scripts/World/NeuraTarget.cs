using UnityEngine;

[System.Serializable]
public class NeuraTarget
{
    public string id;
    public Transform transform;
}
