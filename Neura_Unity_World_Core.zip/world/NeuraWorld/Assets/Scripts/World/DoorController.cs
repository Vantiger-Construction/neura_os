using UnityEngine;

/// <summary>
/// Optional door controller. If you have an Animator with Open/Close triggers, hook it here.
/// Otherwise, it can simply enable/disable a door GameObject.
/// </summary>
public class DoorController : MonoBehaviour
{
    public Animator animator;
    public string openTrigger = "Open";
    public string closeTrigger = "Close";

    public GameObject doorMesh; // optional if no animator
    public bool disableOnOpen = false;

    public void Open()
    {
        if (animator) animator.SetTrigger(openTrigger);
        if (doorMesh && disableOnOpen) doorMesh.SetActive(false);
    }

    public void Close()
    {
        if (animator) animator.SetTrigger(closeTrigger);
        if (doorMesh && disableOnOpen) doorMesh.SetActive(true);
    }
}
