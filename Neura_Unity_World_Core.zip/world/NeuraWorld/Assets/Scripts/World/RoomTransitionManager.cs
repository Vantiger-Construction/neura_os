using System.Collections;
using System.Collections.Generic;
using UnityEngine;

/// <summary>
/// Room transitions + camera beats.
/// Works with TargetRegistry + CinematicCameraRig + NeuraController_Nav.
/// Emits ROOM_READY when the room cinematic finishes.
/// </summary>
public class RoomTransitionManager : MonoBehaviour
{
    [System.Serializable]
    public class RoomDef
    {
        public string id;
        public Transform entryPoint;      // where Neura should stand on entry
        public Transform cameraFocus;     // camera look target
        public Transform cameraPosition;  // optional camera position anchor
        public DoorController door;       // optional
    }

    public List<RoomDef> rooms = new List<RoomDef>();

    [Header("Refs")]
    public NeuraController_Nav neura;
    public CinematicCameraRig camRig;

    [Header("Timing")]
    public float prePanSeconds = 0.6f;
    public float postArriveSeconds = 0.25f;

    private readonly Dictionary<string, RoomDef> _map = new Dictionary<string, RoomDef>();
    private bool _busy;

    void Awake()
    {
        foreach (var r in rooms)
        {
            if (r != null && !string.IsNullOrEmpty(r.id) && !_map.ContainsKey(r.id))
                _map.Add(r.id, r);
        }
    }

    public void GoToRoom(string roomId)
    {
        if (_busy) return;
        if (!_map.TryGetValue(roomId, out var room)) return;

        StartCoroutine(DoRoomTransition(room));
    }

    private IEnumerator DoRoomTransition(RoomDef room)
    {
        _busy = true;

        // Door open
        if (room.door) room.door.Open();

        // Camera pre-pan
        if (camRig)
        {
            camRig.Focus(room.cameraFocus ? room.cameraFocus : room.entryPoint, room.cameraPosition);
            yield return new WaitForSeconds(prePanSeconds);
        }

        // Walk Neura to entry point
        if (neura && room.entryPoint)
        {
            neura.GoTo(room.entryPoint.position);
            while (!neura.HasArrived)
                yield return null;
        }

        yield return new WaitForSeconds(postArriveSeconds);

        // optional door close behind
        if (room.door) room.door.Close();

        // signal Flutter
        BridgeRouter.Instance?.EmitEvent("ROOM_READY", room.id);

        _busy = false;
    }

    public bool IsBusy => _busy;
}
