using System.Collections.Generic;
using UnityEngine;

public class TargetRegistry : MonoBehaviour
{
    [Header("Register interaction targets (desks, altars, room anchors, etc.)")]
    public List<NeuraTarget> targets = new List<NeuraTarget>();

    private Dictionary<string, Transform> _map;

    void Awake()
    {
        _map = new Dictionary<string, Transform>();
        foreach (var t in targets)
        {
            if (t == null || string.IsNullOrWhiteSpace(t.id) || t.transform == null) continue;
            if (!_map.ContainsKey(t.id)) _map.Add(t.id, t.transform);
        }
    }

    public Transform Get(string id)
    {
        if (_map == null) return null;
        _map.TryGetValue(id, out var tr);
        return tr;
    }
}
