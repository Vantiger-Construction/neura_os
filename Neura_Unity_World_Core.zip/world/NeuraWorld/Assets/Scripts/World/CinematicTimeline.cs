using System;
using System.Collections;
using UnityEngine;

/// <summary>
/// Tiny sequence helper: run a few timed beats.
/// Use for prop "approach -> gesture -> activate".
/// </summary>
public class CinematicTimeline : MonoBehaviour
{
    public IEnumerator Run(float delaySeconds, Action action)
    {
        if (delaySeconds > 0) yield return new WaitForSeconds(delaySeconds);
        action?.Invoke();
    }

    public IEnumerator Run2(float d1, Action a1, float d2, Action a2)
    {
        yield return Run(d1, a1);
        yield return Run(d2, a2);
    }
}
