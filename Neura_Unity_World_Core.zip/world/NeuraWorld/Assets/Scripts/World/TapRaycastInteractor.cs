using UnityEngine;

/// <summary>
/// Drop on Main Camera. On mouse click / single touch, raycasts forward and calls Interact() on NeuraPropInteractable.
/// Works for Windows + Android.
/// </summary>
public class TapRaycastInteractor : MonoBehaviour
{
    public float maxDistance = 50f;
    public LayerMask interactLayers = ~0;

    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            TryRay(Input.mousePosition);
        }

        if (Input.touchCount > 0)
        {
            var t = Input.GetTouch(0);
            if (t.phase == TouchPhase.Began)
                TryRay(t.position);
        }
    }

    private void TryRay(Vector2 screenPos)
    {
        var cam = GetComponent<Camera>();
        if (cam == null) return;

        var ray = cam.ScreenPointToRay(screenPos);
        if (Physics.Raycast(ray, out var hit, maxDistance, interactLayers))
        {
            var interact = hit.collider.GetComponentInParent<NeuraPropInteractable>();
            if (interact != null)
                interact.Interact();
        }
    }
}
