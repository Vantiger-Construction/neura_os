using UnityEngine;

/// <summary>
/// Lightweight camera rig (no Cinemachine required).
/// Smoothly moves to an optional position anchor and looks at a focus target.
/// </summary>
[RequireComponent(typeof(Camera))]
public class CinematicCameraRig : MonoBehaviour
{
    public Transform lookTarget;
    public Transform positionAnchor;

    [Header("Smoothing")]
    public float moveSmooth = 6f;
    public float lookSmooth = 10f;

    void LateUpdate()
    {
        if (positionAnchor)
        {
            transform.position = Vector3.Lerp(transform.position, positionAnchor.position, Time.deltaTime * moveSmooth);
        }

        if (lookTarget)
        {
            var dir = (lookTarget.position - transform.position);
            if (dir.sqrMagnitude > 0.0001f)
            {
                var targetRot = Quaternion.LookRotation(dir.normalized, Vector3.up);
                transform.rotation = Quaternion.Slerp(transform.rotation, targetRot, Time.deltaTime * lookSmooth);
            }
        }
    }

    public void Focus(Transform newLookTarget, Transform newPositionAnchor = null)
    {
        lookTarget = newLookTarget;
        if (newPositionAnchor) positionAnchor = newPositionAnchor;
    }
}
