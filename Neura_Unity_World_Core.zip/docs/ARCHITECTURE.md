# Neura OS Architecture (Up to this Point)

## Layers
- **Core (Flutter):** UI + Intent Engine + Encrypted Memory Graph + Bridge Client.
- **World (Unity):** Neura avatar, rooms, props, locomotion, cinematics, emotion lighting.
- **Shell:** Platform glue (Android embedded Unity, Windows TCP bridge).

## Privacy
- **Local-first**: memory stored on-device.
- **Encrypted at rest**: app-layer AES-GCM encryption of payloads before writing to SQLite.
- Optional cloud sync is not included here; add later with end-to-end encryption.
