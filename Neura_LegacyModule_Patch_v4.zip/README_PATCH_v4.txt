Neura Companion — Legacy Module Patch v4
=======================================

What’s new:
- One‑tap “Send to Grandma” button on Legacy Capsule detail screen.
  * If no Grandma/Nana/Granny contact exists, it offers to open Trusted Contacts so you can add one.
- PDF Letter export improved:
  * Optional recipient line and delivery note (your message template) included in the PDF.
- ZIP Delivery Packet now includes a human-friendly cover.pdf.

How to apply:
1) Copy the contents of this patch into your Neura OS project root.
2) Overwrite when prompted.
3) Run: flutter pub get
4) Build/run.

Files included:
- neura_os/lib/src/modules/legacy/legacy_detail_screen.dart
- neura_os/lib/src/modules/legacy/legacy_send_screen.dart
- neura_os/lib/src/modules/legacy/legacy_delivery_service.dart
- neura_os/lib/src/modules/legacy/legacy_pdf_export_service.dart
- neura_os/lib/src/modules/legacy/legacy_pdf_cover_builder.dart
- neura_os/lib/src/modules/legacy/legacy_vault_service.dart

