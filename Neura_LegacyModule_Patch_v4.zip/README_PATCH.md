# Neura Legacy Patch v4

Adds **One‑Tap “Send to Grandma”** and upgrades **PDF Letter + ZIP packet cover page**.

## What changed
- Legacy Capsule Detail screen: new buttons
  - **Grandma**: one‑tap send (uses trusted contact named Grandma/Nana/Granny)
  - **PDF**: exports a printable PDF letter version
- Send screen: supports pre‑selected contact/template/format + optional auto‑share
- Delivery packet: PDF exports can include recipient + delivery note
- ZIP packet: now includes a `cover.pdf` (pretty cover page) alongside `README.txt`

## How to apply
Copy the `neura_os/` folder from this patch **over** your existing project (same paths), then run your usual `flutter pub get` + build.

Files touched live under:
- `neura_os/lib/src/modules/legacy/`

