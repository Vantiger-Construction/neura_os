Neura Companion — Voice, Emotion, Memory & Legacy Patch

Adds:
• Voice style modulation (calm/supportive/focused/playful)
• Emotional smoothing (less jitter)
• Long-term memory archive
• Legacy Mode (messages preserved beyond sessions)

Drop into lib/core.
