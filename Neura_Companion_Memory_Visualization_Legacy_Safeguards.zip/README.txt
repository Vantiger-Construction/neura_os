Neura Companion — Memory Visualization & Legacy Safeguards

Adds:
• Memory constellation visualization (spatial recall)
• Interactive memory timeline nodes
• Legacy access rules (owner-only, timed unlock, future trusted contact)
• Guardian logic for legacy protection

Drop into lib/core and lib/ui.
