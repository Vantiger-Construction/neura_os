$ErrorActionPreference = "Stop"
Write-Host "============================================="
Write-Host "  Neura OS - One-Click Setup (PowerShell)"
Write-Host "============================================="
Write-Host ""

function Require-Cmd($name){
  if (-not (Get-Command $name -ErrorAction SilentlyContinue)) {
    throw "Missing command: $name. Install Flutter and ensure it's on PATH."
  }
}

Require-Cmd "flutter"

$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$proj = Join-Path $root ".."
Push-Location $proj

Write-Host "[1/3] flutter pub get"
flutter pub get

Write-Host "[2/3] flutter analyze"
flutter analyze

Write-Host "[3/3] flutter run"
flutter run

Pop-Location
