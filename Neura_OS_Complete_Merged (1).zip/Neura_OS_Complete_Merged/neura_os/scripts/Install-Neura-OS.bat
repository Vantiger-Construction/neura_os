@echo off
setlocal enabledelayedexpansion

echo =============================================
echo   Neura OS - One-Click Setup (Windows)
echo =============================================
echo.

where flutter >nul 2>&1
if errorlevel 1 (
  echo [ERROR] Flutter not found on PATH.
  echo Install Flutter and restart this script.
  pause
  exit /b 1
)

echo [1/3] Fetching dependencies...
pushd "%~dp0\.."
flutter pub get
if errorlevel 1 (
  echo [ERROR] flutter pub get failed.
  popd
  pause
  exit /b 1
)

echo [2/3] Running analyzer...
flutter analyze
if errorlevel 1 (
  echo [WARN] Analyzer reported issues. Continuing anyway.
)

echo [3/3] Launching app (debug)...
echo Tip: plug in a device or start an emulator.
flutter run
popd
endlocal
