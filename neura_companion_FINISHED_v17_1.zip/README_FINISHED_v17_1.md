
# Neura Companion — FINISHED v17.1

✅ Everything merged:
- Flutter client (Health Live + BLE pairing + Onboarding) with **Lottie animation** on the home screen.
- **HealthKit (iOS)** and **Health Connect (Android)** bridge files for HR + HRV (permission checks + recent reads).
- **Live HR event channel** overlay (BPM + RMSSD) and Recovery Mode.
- **Installers** scaffolds (Windows MSIX, macOS DMG, Linux AppImage).
- **Unity/Quest** timeline scene scaffold (StreamingAssets timeline + simple “next/highlight” intents).

## Run (Flutter)
```bash
cd app/flutter_client
flutter pub get
flutter run
```

## Assets
- Lottie: `assets/lottie/neura_aura.json` (animated logo aura) shown on **Home**.
- Data: `assets/data/timeline.json`

## Notes
- Replace signing placeholders for installers.
- Wire native BLE scan/connect on iOS/Android (channels are stubbed; Android HR stream expects EventChannel `neura.ble.hr`).
