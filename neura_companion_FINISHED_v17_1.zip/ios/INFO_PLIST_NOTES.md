Add HealthKit usage strings and capability.
