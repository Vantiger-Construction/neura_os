// See full bridge in earlier pack.
