// Minimal loader placeholder.
