Copy timeline.json here.
