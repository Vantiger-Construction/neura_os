
import 'package:flutter/material.dart';
import 'core/local_store.dart';
import 'modules/home_lottie.dart';
import 'modules/health_live.dart';
import 'modules/ble_pairing.dart';
import 'modules/onboarding/onboarding.dart';

void main() async{
  WidgetsFlutterBinding.ensureInitialized();
  await LocalStore.init();
  runApp(const NeuraApp());
}
class NeuraApp extends StatelessWidget{
  const NeuraApp({super.key});
  @override Widget build(BuildContext c)=>MaterialApp(
    title:'Neura Companion', theme:ThemeData.dark(), debugShowCheckedModeBanner:false, home: const _Root());
}
class _Root extends StatefulWidget{ const _Root({super.key}); @override State<_Root> createState()=>_R(); }
class _R extends State<_Root>{
  bool onboard=true; int tab=0;
  @override Widget build(BuildContext c){
    if(onboard) return Onboarding(onDone: ()=> setState(()=>onboard=false));
    final screens = const [HomeLottie(), HealthLiveScreen(), BlePairingScreen()];
    return Scaffold(
      appBar:AppBar(title:const Text('Neura Companion')),
      body:screens[tab],
      bottomNavigationBar: NavigationBar(
        selectedIndex:tab, onDestinationSelected:(v)=>setState(()=>tab=v),
        destinations: const [
          NavigationDestination(icon:Icon(Icons.auto_awesome),label:'Home'),
          NavigationDestination(icon:Icon(Icons.favorite),label:'Health'),
          NavigationDestination(icon:Icon(Icons.bluetooth),label:'Devices'),
        ],
      ),
    );
  }
}
