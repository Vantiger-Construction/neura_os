
import 'package:hive_flutter/hive_flutter.dart';
class LocalStore{ static bool _init=false; static Future<void> init() async{ if(_init) return; await Hive.initFlutter(); _init=true; } }
