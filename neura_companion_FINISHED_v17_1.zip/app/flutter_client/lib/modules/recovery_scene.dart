
import 'package:flutter/material.dart'; import '../platform/platform_feedback.dart';
class RecoveryScene extends StatelessWidget{
  const RecoveryScene({super.key});
  @override Widget build(BuildContext c)=>Scaffold(appBar:AppBar(title:const Text('Recovery Mode')), body:Center(child:Column(mainAxisAlignment:MainAxisAlignment.center,children:[
    const Text('Box Breathing 4‑2‑6',style:TextStyle(fontWeight:FontWeight.bold,fontSize:20)), const SizedBox(height:12),
    Container(width:220,height:220,decoration:BoxDecoration(shape:BoxShape.circle,border:Border.all(width:3))),
    const SizedBox(height:16),
    Wrap(spacing:8,children:[ElevatedButton.icon(onPressed:PlatformFeedback.softNudge,icon:const Icon(Icons.vibration),label:const Text('Soft Haptic')),
      ElevatedButton.icon(onPressed:PlatformFeedback.calmTone,icon:const Icon(Icons.music_note),label:const Text('Calm Tone'))])
  ])));
}
