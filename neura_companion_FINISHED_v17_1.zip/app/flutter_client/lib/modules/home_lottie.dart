
import 'package:flutter/material.dart'; import 'package:lottie/lottie.dart';
class HomeLottie extends StatelessWidget{ const HomeLottie({super.key});
  @override Widget build(BuildContext c)=>Scaffold(
    body: Stack(children:[
      Center(child:SizedBox(width:280,child:Lottie.asset('assets/lottie/neura_aura.json', repeat:true))),
      Positioned(bottom:40,left:20,right:20,child:Opacity(opacity:0.8,child:Text('Neura Companion',textAlign:TextAlign.center,style:TextStyle(fontSize:28,fontWeight:FontWeight.bold)))),
    ]),
  );
}
