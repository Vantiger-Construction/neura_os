
import 'package:flutter/material.dart';
import '../platform/health_ingest.dart';
class HealthImportSheet extends StatefulWidget{ const HealthImportSheet({super.key}); @override State<HealthImportSheet> createState()=>_S(); }
class _S extends State<HealthImportSheet>{ String status='Ready';
  Future<void> _check() async{ final ok=await HealthIngest.hasPermissions(); setState(()=>status=ok?'Permissions OK':'Missing permissions'); }
  Future<void> _req() async{ final ok=await HealthIngest.requestPermissions(); setState(()=>status=ok?'Granted':'Denied'); }
  Future<void> _import() async{ setState(()=>status='Importing last hour…'); final n=await HealthIngest.importRecentMinutes(60); setState(()=>status='Imported $n data points'); }
  @override Widget build(BuildContext c)=>Container(padding:const EdgeInsets.all(16), child:Column(mainAxisSize:MainAxisSize.min,crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    Text('Health Import',style:Theme.of(c).textTheme.titleLarge), const SizedBox(height:8), Text(status), const SizedBox(height:8),
    Wrap(spacing:8,children:[OutlinedButton(onPressed:_check,child:const Text('Check perms')), ElevatedButton(onPressed:_req,child:const Text('Request perms')), ElevatedButton(onPressed:_import,child:const Text('Import 1h'))]),
  ]));
}
