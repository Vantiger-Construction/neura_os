
import 'package:flutter/material.dart'; import 'package:flutter/services.dart'; import '../platform/control_presets.dart';
class BlePairingScreen extends StatefulWidget{ const BlePairingScreen({super.key}); @override State<BlePairingScreen> createState()=>_S(); }
class _S extends State<BlePairingScreen>{ static const _ch=MethodChannel('neura.ble'); List<Map<String,dynamic>> devs=[]; bool scanning=false; String status='Idle'; String? connected;
  Future<void> _perms() async{ final ok=await _ch.invokeMethod<bool>('requestPermissions')??false; setState(()=>status=ok?'Permissions granted':'Permissions denied'); }
  Future<void> _scan() async{ setState(()=>scanning=true); final res=await _ch.invokeMethod<List>('scanOnce')??[]; devs=res.map((e)=>Map<String,dynamic>.from(e as Map)).toList(); setState(()=>scanning=false); }
  Future<void> _connect(String id) async{ setState(()=>status='Connecting…'); final ok=await _ch.invokeMethod<bool>('connect',{'id':id})??false; setState(()=>{status=ok?'Connected':'Connect failed',connected=ok?id:null}); if(ok){ await _ch.invokeMethod('startHrNotifications',{'id':id}); setState(()=>status='HR streaming'); } }
  Future<void> _battery() async{ final n=await _ch.invokeMethod<int>('readBattery')??-1; if(!mounted) return; ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('Battery ${n<0?'n/a':'%d%%'%n}'))); }
  Future<void> _preset(String service,String chara,String hex) async{ final ok=await ControlPresets.send({'service':service,'characteristic':chara,'hex':hex}); if(!mounted)return; ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text(ok?'Sent preset':'Failed preset'))); }
  @override Widget build(BuildContext c)=>Padding(padding:const EdgeInsets.all(16),child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    Row(children:[ElevatedButton(onPressed:_perms,child:const Text('Permissions')),const SizedBox(width:8),ElevatedButton(onPressed:scanning?null:_scan,child:const Text('Scan (8s)')),const SizedBox(width:8), if(connected!=null) ElevatedButton(onPressed:_battery, child:const Text('Battery'))]),
    const SizedBox(height:8), Text('Status: $status'), const Divider(),
    Expanded(child:ListView.builder(itemCount:devs.length,itemBuilder:(_,i){final d=devs[i];return ListTile(leading:const Icon(Icons.watch),title:Text((d['name']??'')==''?'(unnamed)':d['name']),subtitle:Text('${d['id']} · rssi:${d['rssi']}'),
      trailing:Wrap(spacing:6,children:[ElevatedButton(onPressed:()=>_connect(d['id']),child:const Text('Connect')),PopupMenuButton<String>(onSelected:(k){ if(k=='start') _preset('0000180d-0000-1000-8000-00805f9b34fb','00002a39-0000-1000-8000-00805f9b34fb','01'); else _preset('0000180d-0000-1000-8000-00805f9b34fb','00002a39-0000-1000-8000-00805f9b34fb','00');},itemBuilder:(_)=>const[PopupMenuItem(value:'start',child:Text('StartWorkout')),PopupMenuItem(value:'stop',child:Text('StopWorkout'))])]); })),
  ]));
}
