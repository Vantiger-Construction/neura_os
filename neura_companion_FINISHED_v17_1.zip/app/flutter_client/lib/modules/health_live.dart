
import 'dart:async'; import 'dart:math'; import 'package:flutter/material.dart'; import 'package:flutter/services.dart';
import '../platform/platform_feedback.dart'; import 'recovery_scene.dart'; import 'health_import_sheet.dart';
class HealthLiveScreen extends StatefulWidget{ const HealthLiveScreen({super.key}); @override State<HealthLiveScreen> createState()=>_S(); }
class _S extends State<HealthLiveScreen>{
  static const _hr=EventChannel('neura.ble.hr'); StreamSubscription? _sub; final _vals=<int>[]; final _rr=<int>[];
  String status='Waiting…'; int? bpm; double? hrvRmssd; int calm=0, spikes=0; final int window=60; final double k=3.5;
  @override void initState(){ super.initState();
    _sub=_hr.receiveBroadcastStream().listen((e){ final m=Map<Object?,Object?>.from(e as Map);
      bpm=(m['bpm'] as num?)?.toInt();
      final rrs = (m['rr'] as List?)?.map((x)=> (x as num).toInt()).toList() ?? const [];
      if(rrs.isNotEmpty){ _rr.addAll(rrs); while(_rr.length>120) _rr.removeAt(0); _computeRmssd(); }
      if(bpm!=null){ _push(bpm!); } setState(()=>status='Live');}, onError: (_){ if(mounted) setState(()=>status='Stream error'); });
  }
  @override void dispose(){ _sub?.cancel(); super.dispose(); }
  void _computeRmssd(){ if(_rr.length<3){ hrvRmssd=null; return; } final diffs=<double>[]; for(int i=1;i<_rr.length;i++){ final d=_rr[i]-_rr[i-1]; diffs.add(d.toDouble()); } final sq=diffs.map((d)=>d*d).toList(); final mean=sq.reduce((a,b)=>a+b)/sq.length; hrvRmssd=sqrt(mean); }
  void _push(int v){ _vals.add(v); if(_vals.length>window) _vals.removeAt(0); if(_vals.length<8) return;
    final med=_median(_vals); final mad=_median(_vals.map((x)=>(x-med).abs()).toList()); final rstd=1.4826*mad; final thr=(med+k*rstd);
    if(v>thr && rstd>0.1){ spikes++; PlatformFeedback.softNudge(); PlatformFeedback.calmTone(); } else { calm++; } }
  double _median(List<int> v){ final w=[...v]..sort(); final mid=w.length~/2; return w.length.isOdd?w[mid].toDouble():(w[mid-1]+w[mid])/2.0; }
  @override Widget build(BuildContext c)=>Padding(padding:const EdgeInsets.all(16), child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    Row(children:[Text('Health Live',style:Theme.of(c).textTheme.titleLarge), const Spacer(), ElevatedButton(onPressed:()=>Navigator.of(c).push(MaterialPageRoute(builder:(_)=>const RecoveryScene())), child:const Text('Recovery'))]),
    const SizedBox(height:8), Text('Status: $status  ·  BPM: ${bpm??'—'}  ·  HRV (RMSSD ms): ${hrvRmssd?.toStringAsFixed(1) ?? '—'}  ·  calm:$calm spikes:$spikes'),
    const SizedBox(height:8), ElevatedButton(onPressed:()=>showModalBottomSheet(context:c,builder:(_)=>const HealthImportSheet()), child:const Text('Import from HealthKit/Connect')),
    const SizedBox(height:8), Expanded(child:CustomPaint(painter:_Spark(_vals.map((e)=>e.toDouble()).toList()))),
  ]));
}
class _Spark extends CustomPainter{ final List<double> d; _Spark(this.d); @override void paint(Canvas c, Size s){ if(d.isEmpty)return; final p=Paint()..strokeWidth=2..style=PaintingStyle.stroke; final mx=d.reduce(max), mn=d.reduce(min); double norm(double x)=>mx==mn?s.height/2:s.height-((x-mn)/(mx-mn)*s.height); final path=Path(); for(int i=0;i<d.length;i++){ final x=s.width*(i/max(1,d.length-1)); final y=norm(d[i]); if(i==0)path.moveTo(x,y); else path.lineTo(x,y);} c.drawPath(path,p);} @override bool shouldRepaint(covariant CustomPainter oldDelegate)=>true; }
