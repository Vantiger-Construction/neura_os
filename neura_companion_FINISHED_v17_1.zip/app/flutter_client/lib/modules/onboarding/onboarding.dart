
import 'package:flutter/material.dart';
class Onboarding extends StatelessWidget{ final VoidCallback onDone; const Onboarding({super.key, required this.onDone});
  @override Widget build(BuildContext c)=>Scaffold(body:SafeArea(child:Column(children:[ const SizedBox(height:24), const Text('Welcome to Neura',style:TextStyle(fontSize:22,fontWeight:FontWeight.bold)),
    const Padding(padding:EdgeInsets.all(16),child:Text('Pair devices, stream HR live, import HealthKit/Connect, and recover calmly.')), const Spacer(), ElevatedButton(onPressed:onDone, child:const Text('Start')) ]))); }
