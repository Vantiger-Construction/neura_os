
import 'package:flutter/services.dart';
class PlatformFeedback{
  static const _ch=MethodChannel('neura.feedback');
  static Future<void> softNudge() async{ try{ await _ch.invokeMethod('softNudge'); }catch(_){ } }
  static Future<void> calmTone() async{ try{ await _ch.invokeMethod('calmTone'); }catch(_){ } }
}
