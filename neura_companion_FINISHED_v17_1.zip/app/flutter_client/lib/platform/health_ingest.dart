
import 'package:flutter/services.dart';
class HealthIngest{
  static const _ch=MethodChannel('neura.health');
  static Future<bool> hasPermissions() async{ try{ return await _ch.invokeMethod<bool>('hasPerms')??false; }catch(_){ return false; } }
  static Future<bool> requestPermissions() async{ try{ return await _ch.invokeMethod<bool>('requestPerms')??false; }catch(_){ return false; } }
  static Future<int> importRecentMinutes(int minutes) async{ try{ return await _ch.invokeMethod<int>('importRecent',{'minutes':minutes})??0; }catch(_){ return 0; } }
}
