
import 'package:flutter/services.dart';
class ControlPresets{
  static const _ble=MethodChannel('neura.ble');
  static Future<bool> send(Map msg) async{
    try{ return await _ble.invokeMethod<bool>('writeControlPoint', msg)??false; }catch(_){ return false; }
  }
}
