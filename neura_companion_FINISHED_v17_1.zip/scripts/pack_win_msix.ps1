Write-Host 'Edit paths/certs, then run MakeAppx + SignTool.'
