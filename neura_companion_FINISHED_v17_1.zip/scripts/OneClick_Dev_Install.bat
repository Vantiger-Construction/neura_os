
@echo off
setlocal
cd /d %~dp0
pushd ..\app\flutter_client
flutter pub get || goto :err
flutter run
popd
exit /b 0
:err
echo Failed. Ensure Flutter 3.24+ is installed and on PATH.
exit /b 1
