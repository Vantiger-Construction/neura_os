
#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")/../app/flutter_client"
flutter pub get
flutter run
