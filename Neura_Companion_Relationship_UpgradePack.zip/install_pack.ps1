
param(
    [string]$TargetRoot = ""
)

function Copy-WithBackup {
    param(
        [string]$Src,
        [string]$Dst,
        [string]$BackupRoot
    )
    $dstDir = Split-Path $Dst -Parent
    if (!(Test-Path $dstDir)) {
        New-Item -ItemType Directory -Force -Path $dstDir | Out-Null
    }
    if (Test-Path $Dst) {
        $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
        $rel = $Dst.Substring($Env:SystemDrive.Length)
        $backupPath = Join-Path $BackupRoot ($rel -replace "[:\\/]", "_") + "_$stamp"
        $backupDir = Split-Path $backupPath -Parent
        if (!(Test-Path $backupDir)) { New-Item -ItemType Directory -Force -Path $backupDir | Out-Null }
        Copy-Item -LiteralPath $Dst -Destination $backupPath -Force
    }
    Copy-Item -LiteralPath $Src -Destination $Dst -Force
}

Write-Host "=== Neura Companion Relationship Brain Upgrade Pack ===" -ForegroundColor Cyan

if (-not $TargetRoot -or -not (Test-Path (Join-Path $TargetRoot 'pubspec.yaml'))) {
    $TargetRoot = Read-Host "Enter your Flutter app root path (folder containing pubspec.yaml)"
}

if (-not (Test-Path (Join-Path $TargetRoot 'pubspec.yaml'))) {
    Write-Error "pubspec.yaml not found at $TargetRoot. Aborting."
    exit 1
}

$BackupRoot = Join-Path $TargetRoot "_backup_neura_pack"
New-Item -ItemType Directory -Force -Path $BackupRoot | Out-Null

$Here = Split-Path -Parent $MyInvocation.MyCommand.Path

$Map = @(
    @{ src="lib\models\neura_promise.dart"; dst="lib\models\neura_promise.dart" },
    @{ src="lib\services\promise_service.dart"; dst="lib\services\promise_service.dart" },
    @{ src="lib\widgets\promises_summary_tile.dart"; dst="lib\widgets\promises_summary_tile.dart" },
    @{ src="lib\screens\promises_list_screen.dart"; dst="lib\screens\promises_list_screen.dart" },

    @{ src="lib\models\relationship_profile.dart"; dst="lib\models\relationship_profile.dart" },
    @{ src="lib\services\relationship_profile_service.dart"; dst="lib\services\relationship_profile_service.dart" },
    @{ src="lib\screens\relationship_list_screen.dart"; dst="lib\screens\relationship_list_screen.dart" },

    @{ src="lib\models\interaction_record.dart"; dst="lib\models\interaction_record.dart" },
    @{ src="lib\services\interaction_service.dart"; dst="lib\services\interaction_service.dart" },

    @{ src="lib\models\relationship_suggestion.dart"; dst="lib\models\relationship_suggestion.dart" },
    @{ src="lib\services\relationship_insight_service.dart"; dst="lib\services\relationship_insight_service.dart" },
    @{ src="lib\widgets\one_good_move_tile.dart"; dst="lib\widgets\one_good_move_tile.dart" },

    @{ src="lib\services\feedback_service.dart"; dst="lib\services\feedback_service.dart" },

    @{ src="lib\models\situation_playbook.dart"; dst="lib\models\situation_playbook.dart" },
    @{ src="lib\services\playbook_service.dart"; dst="lib\services\playbook_service.dart" },
    @{ src="lib\screens\playbook_run_screen.dart"; dst="lib\screens\playbook_run_screen.dart" },

    @{ src="lib\services\distress_detector.dart"; dst="lib\services\distress_detector.dart" },
    @{ src="lib\widgets\soft_landing_panel.dart"; dst="lib\widgets\soft_landing_panel.dart" }
)

foreach ($item in $Map) {
    $src = Join-Path $Here $item.src
    $dst = Join-Path $TargetRoot $item.dst
    Copy-WithBackup -Src $src -Dst $dst -BackupRoot $BackupRoot
    Write-Host "Installed: $($item.dst)"
}

Write-Host "All files copied." -ForegroundColor Green
Write-Host "Next:" -ForegroundColor Yellow
Write-Host "  1) Add uuid & shared_preferences to pubspec.yaml"
Write-Host "  2) flutter pub get"
Write-Host "  3) Wire tiles/screens into your routes & dashboard"
