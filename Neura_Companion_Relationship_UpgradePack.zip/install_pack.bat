
@echo off
setlocal enabledelayedexpansion
echo === Neura Companion Relationship Brain Upgrade Pack ===

set TARGET=
set /p TARGET=Enter your Flutter app root path (folder with pubspec.yaml): 

if not exist "%TARGET%\pubspec.yaml" (
  echo pubspec.yaml not found at "%TARGET%". Aborting.
  exit /b 1
)

set BACKUP=%TARGET%\_backup_neura_pack
if not exist "%BACKUP%" mkdir "%BACKUP%"

set HERE=%~dp0
set HERE=%HERE:~0,-1%

set FILES=^
 lib\models\neura_promise.dart|lib\models\neura_promise.dart;^
 lib\services\promise_service.dart|lib\services\promise_service.dart;^
 lib\widgets\promises_summary_tile.dart|lib\widgets\promises_summary_tile.dart;^
 lib\screens\promises_list_screen.dart|lib\screens\promises_list_screen.dart;^
 lib\models\relationship_profile.dart|lib\models\relationship_profile.dart;^
 lib\services\relationship_profile_service.dart|lib\services\relationship_profile_service.dart;^
 lib\screens\relationship_list_screen.dart|lib\screens\relationship_list_screen.dart;^
 lib\models\interaction_record.dart|lib\models\interaction_record.dart;^
 lib\services\interaction_service.dart|lib\services\interaction_service.dart;^
 lib\models\relationship_suggestion.dart|lib\models\relationship_suggestion.dart;^
 lib\services\relationship_insight_service.dart|lib\services\relationship_insight_service.dart;^
 lib\widgets\one_good_move_tile.dart|lib\widgets\one_good_move_tile.dart;^
 lib\services\feedback_service.dart|lib\services\feedback_service.dart;^
 lib\models\situation_playbook.dart|lib\models\situation_playbook.dart;^
 lib\services\playbook_service.dart|lib\services\playbook_service.dart;^
 lib\screens\playbook_run_screen.dart|lib\screens\playbook_run_screen.dart;^
 lib\services\distress_detector.dart|lib\services\distress_detector.dart;^
 lib\widgets\soft_landing_panel.dart|lib\widgets\soft_landing_panel.dart

for %%F in (%FILES%) do (
  for /f "tokens=1,2 delims=|" %%a in ("%%~F") do (
    set SRC=%%a
    set DST=%%b
    set FULLSRC=%HERE%\!SRC!
    set FULLDST=%TARGET%\!DST!
    if not exist "!FULLSRC!" (
      echo Missing file in pack: !SRC!
      exit /b 1
    )
    for %%d in ("!FULLDST!") do (
      if not exist "%%~dpd" mkdir "%%~dpd"
    )
    if exist "!FULLDST!" (
      for /f "tokens=1-3 delims=/ " %%i in ("%date%") do set D=%%k%%i%%j
      for /f "tokens=1-3 delims=:." %%i in ("%time%") do set T=%%i%%j%%k
      set STAMP=%D%_%T%
      set REL=!DST:\=_!
      set BAK=%BACKUP%\!REL!_!STAMP!
      if not exist "%BACKUP%" mkdir "%BACKUP%"
      copy /Y "!FULLDST!" "!BAK!" >nul
    )
    copy /Y "!FULLSRC!" "!FULLDST!" >nul
    echo Installed: !DST!
  )
)

echo.
echo All files copied.
echo Next steps:
echo   1) Add "uuid" and "shared_preferences" to pubspec.yaml
echo   2) Run "flutter pub get"
echo   3) Wire tiles/screens into dashboard and routes
exit /b 0
