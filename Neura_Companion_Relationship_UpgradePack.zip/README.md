
# Neura Companion – Relationship Brain Upgrade Pack (v1)

This pack installs the next wave of Neura's intelligence:
1) Promises Engine
2) People/Client Profiles 2.0
3) Interaction Summaries
4) Explainable Suggestions (“Why this?”)
5) Feedback Loop (learns what helps you)
6) Situation Playbooks
7) Soft Landing Mode (overwhelm-safe UI)

## Quick Install (Windows PowerShell)
```powershell
./install_pack.ps1
```
The script will ask for your Flutter app root (the folder containing `pubspec.yaml`), then copy files into `lib/` with backups in `_backup_neura_pack/`.

## Quick Install (Windows .bat)
```bat
install_pack.bat
```
Same as above, with a simple prompt.

## What it adds
- `lib/models`: Promise, Relationship Profile, Interaction Record, Playbooks
- `lib/services`: Promise/Relationship/Interaction services, Feedback, Playbooks, Distress detector
- `lib/widgets`: Dashboard tiles for Promises, One Good Move (with “Why”), Soft Landing panel
- `lib/screens`: Relationship list, Promises list, Playbook runner

Wire into your UI:
- Add tiles to your dashboard: `PromisesSummaryTile`, `OneGoodMoveTile`, `SoftLandingPanel`
- Add screens to routes: `RelationshipListScreen`, `PromisesListScreen`, `PlaybookRunScreen`
- After calls/notes: `InteractionService.logInteraction(...)`
- When detecting commitments: `PromiseService.create(...)`
- When text matches a situation: open `PlaybookRunScreen(...)`

## Dependencies
Add to `pubspec.yaml` (if not already):
```yaml
dependencies:
  uuid: ^4.4.0
  shared_preferences: ^2.3.0
```
Then run:
```bash
flutter pub get
```

Backups of overwritten files are saved under `<your app>/_backup_neura_pack/` with timestamps.
