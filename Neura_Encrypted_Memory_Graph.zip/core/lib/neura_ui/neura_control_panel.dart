import 'package:flutter/material.dart';
import '../core/intent/intent_engine.dart';
import '../core/memory/memory_graph_service.dart';

class NeuraControlPanel extends StatefulWidget {
  final MemoryGraphService memory;
  final IntentEngine intent;
  const NeuraControlPanel({super.key, required this.memory, required this.intent});

  @override
  State<NeuraControlPanel> createState() => _NeuraControlPanelState();
}

class _NeuraControlPanelState extends State<NeuraControlPanel> {
  bool _busy = false;
  List<Map<String, dynamic>> _recent = const [];

  Future<void> _load() async {
    setState(() => _busy = true);
    _recent = await widget.memory.recentNodes();
    setState(() => _busy = false);
  }

  @override
  void initState() {
    super.initState();
    _load();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Neura Control Panel')),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Wrap(
              spacing: 12,
              runSpacing: 12,
              children: [
                ElevatedButton(
                  onPressed: _busy
                      ? null
                      : () async {
                          await widget.intent.demoCheckIn();
                          await _load();
                        },
                  child: const Text('Demo Check-In'),
                ),
                ElevatedButton(
                  onPressed: _busy
                      ? null
                      : () async {
                          await widget.memory.resetAll();
                          await _load();
                        },
                  child: const Text('Reset Memory'),
                ),
                ElevatedButton(
                  onPressed: _busy
                      ? null
                      : () async {
                          final export = await widget.memory.exportJson();
                          if (!context.mounted) return;
                          showDialog(
                            context: context,
                            builder: (_) => AlertDialog(
                              title: const Text('Export (preview)'),
                              content: SingleChildScrollView(child: Text(export)),
                              actions: [TextButton(onPressed: () => Navigator.pop(context), child: const Text('Close'))],
                            ),
                          );
                        },
                  child: const Text('Export (Preview)'),
                ),
              ],
            ),
            const SizedBox(height: 16),
            const Text('Recent Memory Nodes:'),
            const SizedBox(height: 8),
            Expanded(
              child: _busy
                  ? const Center(child: CircularProgressIndicator())
                  : ListView.separated(
                      itemCount: _recent.length,
                      separatorBuilder: (_, __) => const Divider(height: 1),
                      itemBuilder: (_, i) {
                        final r = _recent[i];
                        return ListTile(
                          title: Text(r['type']?.toString() ?? 'node'),
                          subtitle: Text(r['ts']?.toString() ?? ''),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
