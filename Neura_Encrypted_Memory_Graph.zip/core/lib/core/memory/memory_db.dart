import 'dart:io';
import 'package:drift/drift.dart';
import 'package:drift/native.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

part 'memory_db.g.dart';

class MemoryNodes extends Table {
  TextColumn get id => text()();
  TextColumn get type => text()();
  DateTimeColumn get ts => dateTime()();
  TextColumn get encryptedPayload => text()();
  TextColumn get outcome => text().nullable()(); // positive/neutral/negative

  @override
  Set<Column> get primaryKey => {id};
}

class MemoryEdges extends Table {
  TextColumn get id => text()();
  TextColumn get src => text()();
  TextColumn get dst => text()();
  TextColumn get rel => text()();
  DateTimeColumn get ts => dateTime()();

  @override
  Set<Column> get primaryKey => {id};
}

@DriftDatabase(tables: [MemoryNodes, MemoryEdges])
class MemoryDb extends _$MemoryDb {
  MemoryDb() : super(_openConnection());

  @override
  int get schemaVersion => 1;
}

LazyDatabase _openConnection() {
  return LazyDatabase(() async {
    final dir = await getApplicationDocumentsDirectory();
    final file = File(p.join(dir.path, 'neura_memory.sqlite'));
    return NativeDatabase.createInBackground(file);
  });
}
