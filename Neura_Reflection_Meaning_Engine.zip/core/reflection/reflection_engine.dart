import 'dart:math';

import '../memory/memory_graph_service.dart';

/// ReflectionEngine turns raw memory events into user-safe reflections.
///
/// Design rules (safety-first):
/// - No diagnosis.
/// - No coercion.
/// - Always offer options and agency.
/// - If uncertainty is high, speak tentatively.
class ReflectionEngine {
  final MemoryGraphService _mem;
  ReflectionEngine(this._mem);

  Future<DailyReflection> buildDailyReflection({DateTime? dayUtc}) async {
    final target = dayUtc ?? DateTime.now().toUtc();
    final start = DateTime.utc(target.year, target.month, target.day);
    final end = start.add(const Duration(days: 1));

    final events = await _mem.queryEventsBetween(start, end);

    // Simple heuristics: count event types, pull top tags, and pick 1–2 "wins".
    final mood = <String, int>{};
    final tags = <String, int>{};
    int actions = 0, prompts = 0;

    for (final e in events) {
      if (e.type == 'mood') {
        final v = e.payload['value']?.toString() ?? 'unknown';
        mood[v] = (mood[v] ?? 0) + 1;
      }
      if (e.type == 'action') actions++;
      if (e.type == 'prompt') prompts++;

      final t = e.payload['tags'];
      if (t is List) {
        for (final x in t) {
          final k = x.toString();
          tags[k] = (tags[k] ?? 0) + 1;
        }
      }
    }

    String? topMood;
    if (mood.isNotEmpty) {
      topMood = mood.entries.toList()..sort((a,b)=>b.value.compareTo(a.value));
      topMood = (mood.entries.toList()..sort((a,b)=>b.value.compareTo(a.value))).first.key;
    }

    final topTags = tags.entries.toList()
      ..sort((a,b)=>b.value.compareTo(a.value));

    final tagList = topTags.take(3).map((e)=>e.key).toList();

    final headline = _headline(topMood, actions, prompts);
    final insight = _insight(topMood, tagList, actions, prompts);
    final nextStep = _nextStep(tagList);

    return DailyReflection(
      dayUtc: start,
      headline: headline,
      insight: insight,
      suggestedNextStep: nextStep,
      stats: {
        'events': events.length,
        'actions': actions,
        'prompts': prompts,
        'topMood': topMood ?? 'unknown',
        'tags': tagList,
      },
    );
  }

  String _headline(String? mood, int actions, int prompts) {
    final m = mood ?? 'unknown';
    if (m == 'stressed') return 'Today felt a bit heavy — and you still showed up.';
    if (m == 'calm') return 'A steadier day. Nice work keeping it grounded.';
    if (m == 'energized') return 'Momentum day. You had some spark.';
    if (actions + prompts > 0) return 'You made moves today — even small ones count.';
    return 'Quiet day. Quiet days still matter.';
  }

  String _insight(String? mood, List<String> tags, int actions, int prompts) {
    final m = mood ?? 'unknown';
    final t = tags.isEmpty ? '' : ' Themes that showed up: ${tags.join(', ')}.';

    if (m == 'stressed') {
      return 'You logged signs of stress. That doesn\'t mean you failed — it means your system was signaling for care.'
          '$t Try noticing one tiny thing that reduced friction (even 1%).';
    }
    if (m == 'calm') {
      return 'Calm showed up more than once. That\'s usually a sign your habits and environment were cooperating.'
          '$t Keep one of today\'s stabilizers on purpose tomorrow.';
    }
    if (m == 'energized') {
      return 'Energy was present. Great time to channel it into something meaningful — without burning out.'
          '$t Pick one goal to nudge forward, then stop while it\'s still fun.';
    }

    if (actions + prompts > 0) {
      return 'You interacted with Neura $prompts times and recorded $actions actions.'
          '$t The pattern matters more than perfection.';
    }

    return 'Not much was logged today. If this is accurate, it might have been a rest day. If not, we can make logging easier.';
  }

  String _nextStep(List<String> tags) {
    final options = <String>[
      'Do a 2-minute breath reset and write one sentence about what you actually need.';
      ,
      'Pick a single “next-right-thing” and do it for 5 minutes — set a timer.';
      ,
      'Send one kind message to someone (including future-you).'
      ,
      'Move your body for 3 minutes: stretch, walk, or shake out tension.'
    ];
    // Light tag hinting
    if (tags.any((t)=>t.toLowerCase().contains('sleep'))) {
      options.insert(0, 'Tonight: lower lights early and do a 30-second “brain dump” before bed.');
    }
    if (tags.any((t)=>t.toLowerCase().contains('focus'))) {
      options.insert(0, 'Try one 15-minute focus sprint: start messy, refine later.');
    }
    return options[Random().nextInt(options.length)];
  }
}

class DailyReflection {
  final DateTime dayUtc;
  final String headline;
  final String insight;
  final String suggestedNextStep;
  final Map<String, Object?> stats;

  DailyReflection({
    required this.dayUtc,
    required this.headline,
    required this.insight,
    required this.suggestedNextStep,
    required this.stats,
  });
}
