import 'package:flutter/material.dart';

import '../memory/memory_graph_service.dart';
import 'reflection_engine.dart';

class ReflectionScreen extends StatefulWidget {
  const ReflectionScreen({super.key, required this.memory});
  final MemoryGraphService memory;

  @override
  State<ReflectionScreen> createState() => _ReflectionScreenState();
}

class _ReflectionScreenState extends State<ReflectionScreen> {
  DailyReflection? _reflection;
  bool _loading = true;
  String? _error;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    try {
      setState(() { _loading = true; _error = null; });
      final engine = ReflectionEngine(widget.memory);
      final r = await engine.buildDailyReflection();
      setState(() { _reflection = r; });
    } catch (e) {
      setState(() { _error = e.toString(); });
    } finally {
      setState(() { _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Reflective Mirror'),
        actions: [
          IconButton(onPressed: _load, icon: const Icon(Icons.refresh)),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : _error != null
              ? Center(child: Text('Reflection error: $_error'))
              : Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(_reflection!.headline, style: Theme.of(context).textTheme.headlineSmall),
                      const SizedBox(height: 12),
                      Text(_reflection!.insight, style: Theme.of(context).textTheme.bodyLarge),
                      const SizedBox(height: 18),
                      Text('Suggested next step', style: Theme.of(context).textTheme.titleMedium),
                      const SizedBox(height: 8),
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(12),
                          border: Border.all(color: Colors.white24),
                        ),
                        child: Text(_reflection!.suggestedNextStep),
                      ),
                      const SizedBox(height: 18),
                      Text('Stats', style: Theme.of(context).textTheme.titleMedium),
                      const SizedBox(height: 8),
                      Text(_reflection!.stats.toString(), style: Theme.of(context).textTheme.bodySmall),
                    ],
                  ),
                ),
    );
  }
}
