import 'dart:math';
import 'package:drift/drift.dart';
import 'memory_db.dart';
import 'memory_crypto.dart';

class MemoryGraphService {
  late final MemoryDb db;
  late final MemoryCrypto crypto;

  MemoryGraphService() {
    db = MemoryDb();
  }

  Future<void> _ensureCrypto() async {
    crypto = crypto ?? await MemoryCrypto.demo();
  }

  // Workaround for late init: keep a nullable backing field.
  MemoryCrypto? crypto;

  String _id() {
    final r = Random.secure();
    const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
    return List.generate(20, (_) => chars[r.nextInt(chars.length)]).join();
  }

  Future<String> logUserAction({required String kind, required Map<String, dynamic> payload, String? outcome}) async {
    await _ensureCrypto();
    final id = _id();
    final encrypted = await crypto!.encryptJson(payload);
    await db.into(db.memoryNodes).insert(MemoryNodesCompanion.insert(
      id: id,
      type: 'ACTION:$kind',
      ts: DateTime.now(),
      encryptedPayload: encrypted,
      outcome: Value(outcome),
    ));
    return id;
  }

  Future<String> logSuggestion({required String kind, required Map<String, dynamic> payload, String? userResponse, String? outcome}) async {
    await _ensureCrypto();
    final id = _id();
    final encrypted = await crypto!.encryptJson({...payload, if (userResponse != null) 'response': userResponse});
    await db.into(db.memoryNodes).insert(MemoryNodesCompanion.insert(
      id: id,
      type: 'SUGGESTION:$kind',
      ts: DateTime.now(),
      encryptedPayload: encrypted,
      outcome: Value(outcome),
    ));
    return id;
  }

  Future<void> link({required String src, required String dst, required String rel}) async {
    final id = _id();
    await db.into(db.memoryEdges).insert(MemoryEdgesCompanion.insert(
      id: id,
      src: src,
      dst: dst,
      rel: rel,
      ts: DateTime.now(),
    ));
  }

  Future<List<Map<String, dynamic>>> recentNodes({int limit = 25}) async {
    await _ensureCrypto();
    final rows = await (db.select(db.memoryNodes)
          ..orderBy([(t) => OrderingTerm.desc(t.ts)])
          ..limit(limit))
        .get();

    final out = <Map<String, dynamic>>[];
    for (final r in rows) {
      final dec = await crypto!.decryptJson(r.encryptedPayload);
      out.add({
        'id': r.id,
        'type': r.type,
        'ts': r.ts.toIso8601String(),
        'outcome': r.outcome,
        'payload': dec,
      });
    }
    return out;
  }

  Future<void> resetAll() async {
    await db.delete(db.memoryEdges).go();
    await db.delete(db.memoryNodes).go();
  }

  Future<String> exportJson() async {
    final nodes = await recentNodes(limit: 1000);
    // Minimal export (nodes only) - extend to edges.
    return nodes.toString();
  }

  void dispose() {
    db.close();
  }
}
  Future<List<MemoryEvent>> queryEventsBetween(DateTime startUtc, DateTime endUtc) async {
    final rows = await _db.select(_db.memoryEvents)
      ..where((t) => t.createdAtUtc.isBiggerOrEqualValue(startUtc) & t.createdAtUtc.isSmallerThanValue(endUtc))
      ..orderBy([(t)=> OrderingTerm(expression: t.createdAtUtc)]);
    final list = await rows.get();
    final out = <MemoryEvent>[];
    for (final r in list) {
      out.append(await _toEvent(r));
    }
    return out;
  }


