# Neura Reflection + Meaning Engine (Module)

Drop-in module that turns daily memory events into a gentle, non-coercive reflection.

## Files
- core/reflection/reflection_engine.dart
- core/reflection/reflection_screen.dart

## Integration
- main.dart includes a button "Open Reflective Mirror" that shows ReflectionScreen.
- ReflectionEngine reads memory events between day start/end (UTC) and generates:
  - headline
  - insight
  - suggested next step

Safety rules:
- No diagnosis, no commands, always agency.
