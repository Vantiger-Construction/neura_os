
import 'package:flutter/material.dart';

import '../neura_os_core/neura_session_engine.dart';

/// Simple launcher card list for guided sessions.
class NeuraSessionLauncher extends StatefulWidget {
  const NeuraSessionLauncher({super.key});

  @override
  State<NeuraSessionLauncher> createState() => _NeuraSessionLauncherState();
}

class _NeuraSessionLauncherState extends State<NeuraSessionLauncher> {
  @override
  Widget build(BuildContext context) {
    final engine = NeuraSessionEngine.instance;
    final sessions = engine.allSessions;

    return ListView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      itemCount: sessions.length,
      itemBuilder: (context, index) {
        final s = sessions[index];
        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
          child: ListTile(
            title: Text(s.title),
            subtitle: Text(s.description),
            trailing: s.suggestedDuration != null
                ? Text('${s.suggestedDuration!.inMinutes} min')
                : null,
            onTap: () async {
              await engine.startSession(s.id);
              if (!mounted) return;
              ScaffoldMessenger.of(context).showSnackBar(
                SnackBar(content: Text('Started session: ${s.title}')),
              );
            },
          ),
        );
      },
    );
  }
}
