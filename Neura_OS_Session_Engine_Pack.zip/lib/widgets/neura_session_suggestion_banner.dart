
import 'package:flutter/material.dart';

import '../neura_os_core/neura_focus_modes.dart';
import '../neura_os_core/neura_session_engine.dart';

/// Suggests a session based on time-of-day & focus mode. Heuristic only.
class NeuraSessionSuggestionBanner extends StatelessWidget {
  const NeuraSessionSuggestionBanner({super.key});

  @override
  Widget build(BuildContext context) {
    final engine = NeuraSessionEngine.instance;
    final sessions = engine.allSessions;
    if (sessions.isEmpty) return const SizedBox.shrink();

    final now = DateTime.now();
    final hour = now.hour;
    final mode = NeuraFocusModeController.instance.mode;

    String? pickId;

    if (hour >= 6 && hour < 11) {
      pickId = 'morning_launch';
    } else if (mode == NeuraFocusMode.deepWork) {
      pickId = 'deep_work_sprint';
    } else if (mode == NeuraFocusMode.reflection) {
      pickId = 'reflection_micro';
    } else if (hour >= 21 || hour < 1) {
      pickId = 'wind_down_night';
    }

    final session = pickId != null ? engine.getSession(pickId) : null;
    if (session == null) return const SizedBox.shrink();

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      color: Theme.of(context).colorScheme.secondaryContainer,
      child: ListTile(
        leading: const Icon(Icons.play_circle_filled),
        title: Text('Neura Suggests: ${session.title}'),
        subtitle: Text(session.description),
        trailing: session.suggestedDuration != null
            ? Text('${session.suggestedDuration!.inMinutes} min')
            : null,
        onTap: () async {
          await engine.startSession(session.id);
          if (context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              SnackBar(content: Text('Started session: ${session.title}')),
            );
          }
        },
      ),
    );
  }
}
