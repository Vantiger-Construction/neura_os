
# Neura Companion OS – Guided Session Engine Pack

This pack adds a **Guided Session Engine** so Neura can run short,
structured flows such as:

- Morning Launch
- Deep Work Sprint
- Reflection Micro-Session
- Wind Down Night

Each session is a *script* composed of steps that can:

- Change focus mode
- Start rituals
- Suggest journaling
- Log good deeds
- Trigger smart home scenes
- Show friendly guidance text

Included:

1. `NeuraSessionStep` / `NeuraGuidedSession` models.
2. `NeuraSessionEngine` core for running sessions.
3. A default set of sessions wired to existing OS features.
4. `NeuraSessionLauncher` widget to start sessions from the UI.
5. `NeuraSessionSuggestionBanner` that recommends a session based on
   time-of-day + focus mode (basic heuristic).

You can expand the built-in sessions or register your own.
