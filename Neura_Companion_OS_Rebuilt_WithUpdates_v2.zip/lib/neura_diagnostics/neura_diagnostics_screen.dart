  import 'package:flutter/material.dart';

  import '../neura_brain/neura_self_heal_service.dart';
  import '../neura_shell/state/neura_shell_scope.dart';

  /// Diagnostics & Self-Heal screen.
  ///
  /// You can use this as:
  ///   * A standalone route (Navigator.push)
  ///   * Or embed it in a dedicated "Diagnostics" room.
  class NeuraDiagnosticsScreen extends StatelessWidget {
    const NeuraDiagnosticsScreen({super.key});

    @override
    Widget build(BuildContext context) {
      final shell = NeuraShellScope.of(context);
      final selfHeal = shell.selfHeal;

      return AnimatedBuilder(
        animation: selfHeal,
        builder: (context, _) {
          final lastResult = selfHeal.lastResult;
          final errors = selfHeal.recentErrors;
          final lastSync = selfHeal.lastDimensionalSyncAt;

          return Scaffold(
            appBar: AppBar(
              title: const Text('Diagnostics & Self-Heal'),
            ),
            body: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  _buildSafeModeCard(context, selfHeal.safeMode, lastSync),
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      Expanded(
                        child: FilledButton.icon(
                          icon: const Icon(Icons.health_and_safety_rounded),
                          label: const Text('Run quick health check'),
                          onPressed: () async {
                            final result =
                                await selfHeal.runHealthCheck();
                            if (!context.mounted) return;
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text(result.headline)),
                            );
                          },
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: FilledButton.tonalIcon(
                          icon: const Icon(
                              Icons.auto_fix_high_rounded),
                          label: const Text('Dimensional Sync'),
                          onPressed: () async {
                            final result =
                                await selfHeal.runDimensionalSync();
                            if (!context.mounted) return;
                            ScaffoldMessenger.of(context).showSnackBar(
                              SnackBar(content: Text(result.detail)),
                            );
                          },
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 16),
                  if (lastResult != null)
                    _buildLastResultBanner(context, lastResult),
                  const SizedBox(height: 8),
                  Expanded(
                    child: errors.isEmpty
                        ? Center(
                            child: Text(
                              'No recent internal errors recorded.
'
                              'If something still feels off, Neura can log details '
                              'here the next time an error is reported.',
                              textAlign: TextAlign.center,
                              style: Theme.of(context)
                                  .textTheme
                                  .bodyMedium,
                            ),
                          )
                        : _buildErrorsList(context, errors),
                  ),
                ],
              ),
            ),
          );
        },
      );
    }

    Widget _buildSafeModeCard(
      BuildContext context,
      bool safeMode,
      DateTime? lastSync,
    ) {
      final theme = Theme.of(context);

      final title = safeMode ? 'Safe Mode is ON' : 'Safe Mode is OFF';
      final desc = safeMode
          ? 'Neura is running with extra caution. Some heavier features may be '
            'paused while you investigate issues.'
          : 'Neura is running in normal mode. If the app feels unstable, you '
            'can enable Safe Mode so fewer risky actions run automatically.';

      final lastSyncText = lastSync == null
          ? 'No Dimensional Sync run yet.'
          : 'Last Dimensional Sync: '
            '${lastSync.year}-${lastSync.month.toString().padLeft(2, '0')}-'
            '${lastSync.day.toString().padLeft(2, '0')} '
            '${lastSync.hour.toString().padLeft(2, '0')}:'
            '${lastSync.minute.toString().padLeft(2, '0')}';

      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(14),
        decoration: BoxDecoration(
          color: safeMode
              ? theme.colorScheme.errorContainer.withOpacity(0.9)
              : theme.colorScheme.surfaceVariant.withOpacity(0.95),
          borderRadius: BorderRadius.circular(18),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  safeMode
                      ? Icons.shield_moon_rounded
                      : Icons.shield_rounded,
                  color: safeMode
                      ? theme.colorScheme.onErrorContainer
                      : theme.colorScheme.primary,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    title,
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: safeMode
                          ? theme.colorScheme.onErrorContainer
                          : null,
                    ),
                  ),
                ),
                Switch(
                  value: safeMode,
                  onChanged: (v) {
                    NeuraShellScope.of(context).selfHeal.setSafeMode(v);
                  },
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              desc,
              style: theme.textTheme.bodyMedium?.copyWith(
                color: safeMode
                    ? theme.colorScheme.onErrorContainer
                        .withOpacity(0.9)
                    : theme.textTheme.bodyMedium?.color
                        ?.withOpacity(0.9),
              ),
            ),
            const SizedBox(height: 8),
            Text(
              lastSyncText,
              style: theme.textTheme.labelMedium?.copyWith(
                color: safeMode
                    ? theme.colorScheme.onErrorContainer
                        .withOpacity(0.8)
                    : theme.textTheme.bodySmall?.color
                        ?.withOpacity(0.8),
              ),
            ),
          ],
        ),
      );
    }

    Widget _buildLastResultBanner(
      BuildContext context,
      NeuraSelfHealResult result,
    ) {
      final theme = Theme.of(context);
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(10),
        decoration: BoxDecoration(
          color: result.usedDimensionalSync
              ? theme.colorScheme.secondaryContainer
              : theme.colorScheme.primaryContainer,
          borderRadius: BorderRadius.circular(18),
        ),
        child: Row(
          children: [
            Icon(
              result.usedDimensionalSync
                  ? Icons.auto_fix_high_rounded
                  : Icons.info_rounded,
              color: result.usedDimensionalSync
                  ? theme.colorScheme.onSecondaryContainer
                  : theme.colorScheme.onPrimaryContainer,
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    result.headline,
                    style: theme.textTheme.labelLarge?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: result.usedDimensionalSync
                          ? theme.colorScheme.onSecondaryContainer
                          : theme.colorScheme.onPrimaryContainer,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    result.detail,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: result.usedDimensionalSync
                          ? theme.colorScheme.onSecondaryContainer
                              .withOpacity(0.9)
                          : theme.colorScheme.onPrimaryContainer
                              .withOpacity(0.9),
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    Widget _buildErrorsList(
      BuildContext context,
      List<NeuraErrorRecord> errors,
    ) {
      final theme = Theme.of(context);
      return Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Text(
                'Recent internal logs',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              const Spacer(),
              TextButton(
                onPressed: () =>
                    NeuraShellScope.of(context).selfHeal.clearErrors(),
                child: const Text('Clear'),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Expanded(
            child: ListView.separated(
              itemCount: errors.length,
              separatorBuilder: (_, __) => const Divider(height: 1),
              itemBuilder: (context, index) {
                final e = errors[errors.length - 1 - index];
                final time =
                    '${e.timestamp.hour.toString().padLeft(2, '0')}:'
                    '${e.timestamp.minute.toString().padLeft(2, '0')}';
                IconData icon;
                Color color;
                switch (e.severity) {
                  case NeuraErrorSeverity.info:
                    icon = Icons.info_outline_rounded;
                    color = theme.colorScheme.primary;
                    break;
                  case NeuraErrorSeverity.warning:
                    icon = Icons.warning_amber_rounded;
                    color = Colors.orangeAccent;
                    break;
                  case NeuraErrorSeverity.error:
                    icon = Icons.error_outline_rounded;
                    color = theme.colorScheme.error;
                    break;
                }

                return ListTile(
                  leading: Icon(icon, color: color),
                  title: Text(
                    e.source,
                    style: theme.textTheme.bodyMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  subtitle: Text(
                    e.message,
                    maxLines: 2,
                    overflow: TextOverflow.ellipsis,
                  ),
                  trailing: Text(
                    time,
                    style: theme.textTheme.labelSmall?.copyWith(
                      color: theme.textTheme.bodySmall?.color
                          ?.withOpacity(0.7),
                    ),
                  ),
                );
              },
            ),
          ),
        ],
      );
    }
  }
