  import 'package:flutter/material.dart';

  import '../neura_mirror_engine.dart';
  import '../neura_mirror_models.dart';
  import '../../neura_brain/neura_emotion_engine.dart';
  import '../../neura_shell/state/neura_shell_scope.dart';

  /// Mirror Mode screen.
  ///
  /// This is a UI shell with:
  ///   - A large "camera placeholder" panel where you can later plug
  ///     in a real camera widget.
  ///   - A fake emotion picker so you can test the integration without
  ///     platform-specific plugins.
  ///   - A history list of recent Mirror sessions.
  class NeuraMirrorModeScreen extends StatefulWidget {
    const NeuraMirrorModeScreen({super.key});

    @override
    State<NeuraMirrorModeScreen> createState() =>
        _NeuraMirrorModeScreenState();
  }

  class _NeuraMirrorModeScreenState extends State<NeuraMirrorModeScreen> {
    late final NeuraMirrorEngine _mirrorEngine;
    bool _initialized = false;

    String _selectedLabel = 'neutral';
    double _confidence = 0.7;

    @override
    void didChangeDependencies() {
      super.didChangeDependencies();
      if (_initialized) return;
      _initialized = true;
      final shell = NeuraShellScope.of(context);
      _mirrorEngine = NeuraMirrorEngine(emotionEngine: shell.emotionEngine);
      _mirrorEngine.ensureLoaded();
    }

    @override
    Widget build(BuildContext context) {
      final theme = Theme.of(context);

      return Scaffold(
        appBar: AppBar(
          title: const Text('Neura Mirror Mode'),
        ),
        body: AnimatedBuilder(
          animation: _mirrorEngine,
          builder: (context, _) {
            final sessions = _mirrorEngine.sessions;
            final latest = _mirrorEngine.latestSession();

            return Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                children: [
                  // Camera / face preview placeholder
                  AspectRatio(
                    aspectRatio: 16 / 9,
                    child: Container(
                      decoration: BoxDecoration(
                        borderRadius: BorderRadius.circular(20),
                        gradient: LinearGradient(
                          colors: [
                            theme.colorScheme.primaryContainer,
                            theme.colorScheme.secondaryContainer,
                          ],
                          begin: Alignment.topLeft,
                          end: Alignment.bottomRight,
                        ),
                      ),
                      child: Stack(
                        children: [
                          Center(
                            child: Icon(
                              Icons.videocam_rounded,
                              size: 64,
                              color: theme.colorScheme.onPrimaryContainer
                                  .withOpacity(0.6),
                            ),
                          ),
                          Align(
                            alignment: Alignment.bottomLeft,
                            child: Padding(
                              padding: const EdgeInsets.all(12),
                              child: Text(
                                'Camera placeholder
'
                                'You can plug in a real camera preview widget here later.',
                                style:
                                    theme.textTheme.bodySmall?.copyWith(
                                  color: theme.colorScheme
                                      .onPrimaryContainer
                                      .withOpacity(0.9),
                                ),
                              ),
                            ),
                          ),
                        ],
                      ),
                    ),
                  ),
                  const SizedBox(height: 16),
                  _buildFakeControls(context),
                  const SizedBox(height: 12),
                  if (latest != null)
                    _buildLatestSummary(context, latest)
                  else
                    Text(
                      'No Mirror sessions recorded yet. '
                      'Use the controls above to simulate one.',
                      style: theme.textTheme.bodyMedium,
                    ),
                  const SizedBox(height: 12),
                  Expanded(
                    child: sessions.isEmpty
                        ? const SizedBox.shrink()
                        : ListView.separated(
                            itemCount: sessions.length,
                            separatorBuilder: (_, __) =>
                                const SizedBox(height: 6),
                            itemBuilder: (context, index) {
                              final s = sessions[index];
                              return _buildSessionTile(context, s);
                            },
                          ),
                  ),
                ],
              ),
            );
          },
        ),
      );
    }

    Widget _buildFakeControls(BuildContext context) {
      final theme = Theme.of(context);

      return Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(16),
        ),
        elevation: 2,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                'Debug / placeholder controls',
                style: theme.textTheme.titleMedium?.copyWith(
                  fontWeight: FontWeight.w600,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                'Until you plug in a real camera + detector, you can '
                'simulate Mirror Mode by picking an emotion and confidence '
                'here. The snapshot is sent into the mirror engine and then '
                'forwarded to Neura's emotion engine.',
                style: theme.textTheme.bodySmall,
              ),
              const SizedBox(height: 8),
              Wrap(
                spacing: 8,
                children: [
                  _buildEmotionChip('happy'),
                  _buildEmotionChip('calm'),
                  _buildEmotionChip('neutral'),
                  _buildEmotionChip('tired'),
                  _buildEmotionChip('sad'),
                  _buildEmotionChip('stressed'),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                'Confidence: ${_confidence.toStringAsFixed(2)}',
                style: theme.textTheme.bodySmall,
              ),
              Slider(
                value: _confidence,
                min: 0.1,
                max: 1.0,
                onChanged: (v) {
                  setState(() {
                    _confidence = v;
                  });
                },
              ),
              Align(
                alignment: Alignment.centerRight,
                child: FilledButton.icon(
                  icon: const Icon(Icons.camera_enhance_rounded),
                  label: const Text('Record snapshot → session'),
                  onPressed: _recordFakeSession,
                ),
              ),
            ],
          ),
        ),
      );
    }

    Widget _buildEmotionChip(String label) {
      final selected = _selectedLabel == label;
      return ChoiceChip(
        label: Text(label),
        selected: selected,
        onSelected: (_) {
          setState(() {
            _selectedLabel = label;
          });
        },
      );
    }

    Future<void> _recordFakeSession() async {
      final now = DateTime.now();
      final snapshot = NeuraMirrorEmotionSnapshot(
        timestamp: now,
        primaryLabel: _selectedLabel,
        confidence: _confidence.clamp(0.0, 1.0),
        notes: 'Simulated snapshot from placeholder controls',
      );

      final session = NeuraMirrorSessionSummary(
        id: 'mirror_${now.millisecondsSinceEpoch}',
        startedAt: now,
        endedAt: now,
        snapshots: [snapshot],
      );

      await _mirrorEngine.recordSession(session);

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text('Mirror session recorded & fed to emotion engine.'),
        ),
      );
    }

    Widget _buildLatestSummary(
      BuildContext context,
      NeuraMirrorSessionSummary session,
    ) {
      final theme = Theme.of(context);
      final snap = session.latestSnapshot;
      if (snap == null) return const SizedBox.shrink();

      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: theme.colorScheme.primaryContainer.withOpacity(0.9),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            Icon(
              Icons.face_retouching_natural_rounded,
              color: theme.colorScheme.onPrimaryContainer,
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Latest Mirror read: ${snap.primaryLabel}',
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: theme.colorScheme.onPrimaryContainer,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    'Confidence: ${snap.confidence.toStringAsFixed(2)}',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.colorScheme.onPrimaryContainer
                          .withOpacity(0.9),
                    ),
                  ),
                  if (snap.notes.isNotEmpty) ...[
                    const SizedBox(height: 2),
                    Text(
                      snap.notes,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onPrimaryContainer
                            .withOpacity(0.9),
                      ),
                    ),
                  ],
                ],
              ),
            ),
          ],
        ),
      );
    }

    Widget _buildSessionTile(
      BuildContext context,
      NeuraMirrorSessionSummary session,
    ) {
      final theme = Theme.of(context);
      final snap = session.latestSnapshot;
      final label = snap?.primaryLabel ?? 'unknown';
      final conf = snap?.confidence ?? 0.0;
      final date = session.startedAt;

      final dateLabel =
          '${date.year}-${date.month.toString().padLeft(2, '0')}-'
          '${date.day.toString().padLeft(2, '0')} '
          '${date.hour.toString().padLeft(2, '0')}:'
          '${date.minute.toString().padLeft(2, '0')}';

      return Card(
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(14),
        ),
        child: ListTile(
          leading: Icon(
            Icons.face_6_rounded,
            color: theme.colorScheme.primary,
          ),
          title: Text('Mirror: $label'),
          subtitle: Text('Confidence ${conf.toStringAsFixed(2)} · $dateLabel'),
        ),
      );
    }
  }
