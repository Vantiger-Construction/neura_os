import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../neura_brain/neura_emotion_engine.dart';
import 'neura_mirror_models.dart';

/// Engine that stores Mirror Mode sessions and nudges Neura's
/// emotion engine based on snapshots.
///
/// This does NOT perform real camera/face detection – you plug that
/// in later and just call [recordSnapshot] with your results.
class NeuraMirrorEngine extends ChangeNotifier {
  static const _storageKey = 'neura_mirror_sessions_v1';

  final NeuraEmotionEngine emotionEngine;

  NeuraMirrorEngine({required this.emotionEngine});

  final List<NeuraMirrorSessionSummary> _sessions = <NeuraMirrorSessionSummary>[];
  bool _loaded = false;

  bool get isLoaded => _loaded;
  List<NeuraMirrorSessionSummary> get sessions =>
      List.unmodifiable(_sessions);

  Future<void> ensureLoaded() async {
    if (_loaded) return;
    await _loadFromStorage();
  }

  Future<void> _loadFromStorage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_storageKey);
      if (raw == null || raw.isEmpty) {
        _sessions.clear();
        _loaded = true;
        notifyListeners();
        return;
      }
      final decoded = jsonDecode(raw);
      if (decoded is! List) {
        _sessions.clear();
        _loaded = true;
        notifyListeners();
        return;
      }
      _sessions
        ..clear()
        ..addAll(
          decoded
              .whereType<Map<String, dynamic>>()
              .map(NeuraMirrorSessionSummary.fromJson),
        );
      _sessions.sort((a, b) => b.startedAt.compareTo(a.startedAt));
      _loaded = true;
      notifyListeners();
    } catch (e) {
      debugPrint('[NeuraMirrorEngine] Failed to load: $e');
      _sessions.clear();
      _loaded = true;
      notifyListeners();
    }
  }

  Future<void> _saveToStorage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final list = _sessions.map((s) => s.toJson()).toList();
      await prefs.setString(_storageKey, jsonEncode(list));
    } catch (e) {
      debugPrint('[NeuraMirrorEngine] Failed to save: $e');
    }
  }

  /// Records a new Mirror session and forwards the last snapshot to
  /// the emotion engine.
  Future<void> recordSession(NeuraMirrorSessionSummary session) async {
    await ensureLoaded();
    _sessions.add(session);
    _sessions.sort((a, b) => b.startedAt.compareTo(a.startedAt));
    notifyListeners();
    await _saveToStorage();

    final latest = session.latestSnapshot;
    if (latest != null) {
      // Very simple mapping: treat the primary label as a tag, and
      // adjust valence roughly by confidence sign.
      final tag = latest.primaryLabel.toLowerCase();
      double delta = 0.0;
      if (tag.contains('happy') || tag.contains('calm')) {
        delta = latest.confidence.clamp(0.0, 1.0);
      } else if (tag.contains('sad') ||
          tag.contains('angry') ||
          tag.contains('tired') ||
          tag.contains('stressed')) {
        delta = -latest.confidence.clamp(0.0, 1.0);
      }

      try {
        emotionEngine.applyMirrorObservation(
          label: latest.primaryLabel,
          confidence: latest.confidence,
          valenceDelta: delta,
        );
      } catch (e) {
        debugPrint('[NeuraMirrorEngine] Failed to feed emotion engine: $e');
      }
    }
  }

  /// Convenience: returns the most recent session.
  NeuraMirrorSessionSummary? latestSession() {
    if (!_loaded || _sessions.isEmpty) return null;
    return _sessions.first;
  }
}
