import 'package:flutter/foundation.dart';

/// Simple representation of a detected emotion from Mirror Mode.
///
/// This is intentionally generic so you can plug in any face/voice
/// detection backend later without rewriting the UI layer.
class NeuraMirrorEmotionSnapshot {
  NeuraMirrorEmotionSnapshot({
    required this.timestamp,
    required this.primaryLabel,
    required this.confidence,
    required this.notes,
  });

  /// When the snapshot was recorded.
  final DateTime timestamp;

  /// Primary label, e.g. "happy", "sad", "tired", "stressed".
  final String primaryLabel;

  /// Confidence score 0.0–1.0 (1.0 = very confident).
  final double confidence;

  /// Optional notes or debug info from the detector.
  final String notes;

  Map<String, dynamic> toJson() {
    return {
      'timestamp': timestamp.toIso8601String(),
      'primaryLabel': primaryLabel,
      'confidence': confidence,
      'notes': notes,
    };
  }

  static NeuraMirrorEmotionSnapshot fromJson(Map<String, dynamic> json) {
    return NeuraMirrorEmotionSnapshot(
      timestamp: DateTime.parse(json['timestamp'] as String),
      primaryLabel: json['primaryLabel'] as String? ?? 'unknown',
      confidence: (json['confidence'] as num?)?.toDouble() ?? 0.0,
      notes: json['notes'] as String? ?? '',
    );
  }
}

/// A single Mirror Mode session (e.g. one sitting where Neura "watches"
/// and reflects your mood).
class NeuraMirrorSessionSummary {
  NeuraMirrorSessionSummary({
    required this.id,
    required this.startedAt,
    required this.endedAt,
    required this.snapshots,
  });

  final String id;
  final DateTime startedAt;
  final DateTime endedAt;
  final List<NeuraMirrorEmotionSnapshot> snapshots;

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'startedAt': startedAt.toIso8601String(),
      'endedAt': endedAt.toIso8601String(),
      'snapshots': snapshots.map((s) => s.toJson()).toList(),
    };
  }

  static NeuraMirrorSessionSummary fromJson(Map<String, dynamic> json) {
    return NeuraMirrorSessionSummary(
      id: json['id'] as String,
      startedAt: DateTime.parse(json['startedAt'] as String),
      endedAt: DateTime.parse(json['endedAt'] as String),
      snapshots: (json['snapshots'] as List<dynamic>? ?? const [])
          .whereType<Map<String, dynamic>>()
          .map(NeuraMirrorEmotionSnapshot.fromJson)
          .toList(),
    );
  }

  /// Returns the last snapshot, if any.
  NeuraMirrorEmotionSnapshot? get latestSnapshot {
    if (snapshots.isEmpty) return null;
    return snapshots.last;
  }
}
