import 'dart:async';

import 'package:flutter/foundation.dart';

/// Facade for Neura's voice system.
///
/// This does NOT hard-wire a specific TTS/STT plugin so you can swap
/// implementations without rewriting the rest of Neura's code.
///
/// Implementations should plug in:
///   - A TTS backend (e.g. flutter_tts or platform-specific APIs).
///   - A STT backend (e.g. speech_to_text).
abstract class NeuraVoiceBackend {
  Future<void> init();

  Future<void> speak(String text, {String? voiceId, double? rate, double? pitch});

  Future<void> stop();

  /// Starts listening and returns a stream of partial/final transcripts.
  ///
  /// Concrete implementations decide how to signal "final". One option is
  /// to prefix final results with '[final]' or expose another callback.
  Stream<String> startListening();

  Future<void> stopListening();
}

/// Simple in-memory transcript record.
class NeuraTranscriptChunk {
  NeuraTranscriptChunk({
    required this.timestamp,
    required this.text,
    required this.isFinal,
  });

  final DateTime timestamp;
  final String text;
  final bool isFinal;
}

/// High-level voice service used by NeuraShellState and UI widgets.
class NeuraVoiceService extends ChangeNotifier {
  NeuraVoiceService({required NeuraVoiceBackend backend}) : _backend = backend;

  final NeuraVoiceBackend _backend;

  bool _initialized = false;
  bool _isSpeaking = false;
  bool _isListening = false;

  final List<NeuraTranscriptChunk> _transcript = <NeuraTranscriptChunk>[];
  StreamSubscription<String>? _listenSub;

  bool get isInitialized => _initialized;
  bool get isSpeaking => _isSpeaking;
  bool get isListening => _isListening;

  List<NeuraTranscriptChunk> get transcript =>
      List.unmodifiable(_transcript);

  Future<void> ensureInitialized() async {
    if (_initialized) return;
    await _backend.init();
    _initialized = true;
    notifyListeners();
  }

  Future<void> speakText(
    String text, {
    String? voiceId,
    double? rate,
    double? pitch,
  }) async {
    await ensureInitialized();
    _isSpeaking = true;
    notifyListeners();
    try {
      await _backend.speak(text, voiceId: voiceId, rate: rate, pitch: pitch);
    } finally {
      _isSpeaking = false;
      notifyListeners();
    }
  }

  Future<void> stopSpeaking() async {
    await _backend.stop();
    _isSpeaking = false;
    notifyListeners();
  }

  Future<void> startListening() async {
    await ensureInitialized();
    if (_isListening) return;
    _isListening = true;
    notifyListeners();

    _listenSub?.cancel();
    final stream = _backend.startListening();
    _listenSub = stream.listen(
      (text) {
        _transcript.add(
          NeuraTranscriptChunk(
            timestamp: DateTime.now(),
            text: text,
            isFinal: false,
          ),
        );
        notifyListeners();
      },
      onError: (e, st) {
        debugPrint('[NeuraVoiceService] listen error: $e');
        _isListening = false;
        notifyListeners();
      },
      onDone: () {
        _isListening = false;
        notifyListeners();
      },
    );
  }

  Future<void> stopListening() async {
    await _backend.stopListening();
    _listenSub?.cancel();
    _listenSub = null;
    _isListening = false;
    notifyListeners();
  }

  @override
  void dispose() {
    _listenSub?.cancel();
    _listenSub = null;
    super.dispose();
  }
}
