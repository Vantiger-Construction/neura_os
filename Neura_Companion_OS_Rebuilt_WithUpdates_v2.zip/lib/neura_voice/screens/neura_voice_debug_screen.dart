import 'package:flutter/material.dart';

import '../neura_voice_service.dart';

/// Simple debug UI for any NeuraVoiceBackend implementation.
///
/// You must provide an already-constructed NeuraVoiceService via
/// a parameter or other DI. This screen focuses on proving that
/// the backend works end-to-end.
class NeuraVoiceDebugScreen extends StatefulWidget {
  const NeuraVoiceDebugScreen({
    super.key,
    required this.voiceService,
  });

  final NeuraVoiceService voiceService;

  @override
  State<NeuraVoiceDebugScreen> createState() =>
      _NeuraVoiceDebugScreenState();
}

class _NeuraVoiceDebugScreenState extends State<NeuraVoiceDebugScreen> {
  final TextEditingController _controller = TextEditingController();

  @override
  void initState() {
    super.initState();
    widget.voiceService.ensureInitialized();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Neura Voice Debug'),
      ),
      body: AnimatedBuilder(
        animation: widget.voiceService,
        builder: (context, _) {
          final vs = widget.voiceService;
          final transcript = vs.transcript;

          return Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'TTS / STT backend test harness',
                  style: theme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'Type something and tap "Speak" to test TTS, or use '
                  '"Start listening" to test STT.',
                  style: theme.textTheme.bodyMedium,
                ),
                const SizedBox(height: 12),
                TextField(
                  controller: _controller,
                  decoration: const InputDecoration(
                    labelText: 'Text to speak',
                    border: OutlineInputBorder(),
                  ),
                  minLines: 1,
                  maxLines: 3,
                ),
                const SizedBox(height: 8),
                Row(
                  children: [
                    FilledButton.icon(
                      icon: const Icon(Icons.volume_up_rounded),
                      label: const Text('Speak'),
                      onPressed: vs.isSpeaking
                          ? null
                          : () async {
                              final text = _controller.text.trim();
                              if (text.isEmpty) return;
                              await vs.speakText(text);
                            },
                    ),
                    const SizedBox(width: 8),
                    OutlinedButton.icon(
                      icon: const Icon(Icons.stop_rounded),
                      label: const Text('Stop'),
                      onPressed: vs.isSpeaking
                          ? () => vs.stopSpeaking()
                          : null,
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                Row(
                  children: [
                    FilledButton.icon(
                      icon: const Icon(Icons.mic_rounded),
                      label: Text(
                        vs.isListening ? 'Listening…' : 'Start listening',
                      ),
                      onPressed: vs.isListening
                          ? null
                          : () async {
                              await vs.startListening();
                            },
                    ),
                    const SizedBox(width: 8),
                    OutlinedButton.icon(
                      icon: const Icon(Icons.mic_off_rounded),
                      label: const Text('Stop listening'),
                      onPressed: vs.isListening
                          ? () => vs.stopListening()
                          : null,
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                Text(
                  'Transcript',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 8),
                Expanded(
                  child: transcript.isEmpty
                      ? Text(
                          'No transcript yet. Start listening to see results.',
                          style: theme.textTheme.bodyMedium,
                        )
                      : ListView.separated(
                          itemCount: transcript.length,
                          separatorBuilder: (_, __) =>
                              const SizedBox(height: 4),
                          itemBuilder: (context, index) {
                            final chunk = transcript[index];
                            return Card(
                              child: ListTile(
                                dense: true,
                                title: Text(chunk.text),
                                subtitle: Text(
                                  chunk.timestamp.toIso8601String(),
                                ),
                              ),
                            );
                          },
                        ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }
}
