import 'package:flutter/material.dart';
import 'neura_shell/neura_shell_app.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const NeuraShellApp());
}
