import 'package:flutter/material.dart';

import '../neura_dream_engine.dart';
import '../neura_dream_models.dart';

/// Simple Dream Journal screen.
class NeuraDreamJournalScreen extends StatefulWidget {
  const NeuraDreamJournalScreen({
    super.key,
    required this.engine,
  });

  final NeuraDreamEngine engine;

  @override
  State<NeuraDreamJournalScreen> createState() =>
      _NeuraDreamJournalScreenState();
}

class _NeuraDreamJournalScreenState
    extends State<NeuraDreamJournalScreen> {
  bool _initialized = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_initialized) return;
    _initialized = true;
    widget.engine.ensureLoaded();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Dream Journal'),
      ),
      body: AnimatedBuilder(
        animation: widget.engine,
        builder: (context, _) {
          final entries = widget.engine.entries;
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16),
                child: Text(
                  'Capture your dreams when you wake up. '
                  'Neura can later turn these into monthly "dream shows".',
                  style: theme.textTheme.bodyMedium,
                ),
              ),
              Expanded(
                child: entries.isEmpty
                    ? Center(
                        child: Text(
                          'No dreams recorded yet. Tap + to add one.',
                          style: theme.textTheme.bodyMedium,
                        ),
                      )
                    : ListView.separated(
                        itemCount: entries.length,
                        separatorBuilder: (_, __) =>
                            const SizedBox(height: 6),
                        itemBuilder: (context, index) {
                          final e = entries[index];
                          final d = e.date;
                          final dateLabel =
                              '${d.year}-${d.month.toString().padLeft(2, '0')}-'
                              '${d.day.toString().padLeft(2, '0')}';
                          return Card(
                            shape: RoundedRectangleBorder(
                              borderRadius: BorderRadius.circular(14),
                            ),
                            child: ListTile(
                              title: Text(e.title.isEmpty
                                  ? '(Untitled dream)'
                                  : e.title),
                              subtitle: Text(
                                '$dateLabel · mood: ${e.moodTag.isEmpty ? 'unknown' : e.moodTag}',
                              ),
                              onTap: () => _editDream(context, e),
                            ),
                          );
                        },
                      ),
              ),
            ],
          );
        },
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _editDream(context, null),
        child: const Icon(Icons.add_rounded),
      ),
    );
  }

  Future<void> _editDream(BuildContext context, NeuraDreamEntry? entry) async {
    final theme = Theme.of(context);
    final titleController =
        TextEditingController(text: entry?.title ?? '');
    final textController =
        TextEditingController(text: entry?.rawText ?? '');
    final moodController =
        TextEditingController(text: entry?.moodTag ?? '');
    final symbolsController =
        TextEditingController(text: entry?.keySymbols ?? '');

    final result = await showDialog<bool>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(entry == null ? 'New dream' : 'Edit dream'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                TextField(
                  controller: titleController,
                  decoration: const InputDecoration(
                    labelText: 'Title',
                  ),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: textController,
                  decoration: const InputDecoration(
                    labelText: 'Dream text',
                  ),
                  maxLines: 5,
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: moodController,
                  decoration: const InputDecoration(
                    labelText: 'Mood tag (optional)',
                  ),
                ),
                const SizedBox(height: 8),
                TextField(
                  controller: symbolsController,
                  decoration: const InputDecoration(
                    labelText: 'Key symbols (comma separated)',
                  ),
                ),
              ],
            ),
          ),
          actions: [
            if (entry != null)
              TextButton(
                onPressed: () => Navigator.of(context).pop(null),
                style: TextButton.styleFrom(
                  foregroundColor: theme.colorScheme.error,
                ),
                child: const Text('Delete'),
              ),
            TextButton(
              onPressed: () => Navigator.of(context).pop(false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () => Navigator.of(context).pop(true),
              child: const Text('Save'),
            ),
          ],
        );
      },
    );

    if (result == null) {
      // Delete
      if (entry != null) {
        await widget.engine.delete(entry.id);
      }
      return;
    }
    if (result == false) return;

    final now = DateTime.now();
    final newEntry = NeuraDreamEntry(
      id: entry?.id ?? 'dream_${now.millisecondsSinceEpoch}',
      date: entry?.date ?? now,
      title: titleController.text.trim(),
      rawText: textController.text.trim(),
      moodTag: moodController.text.trim(),
      keySymbols: symbolsController.text.trim(),
    );

    await widget.engine.addOrUpdate(newEntry);
  }
}
