import 'package:flutter/material.dart';

import '../neura_dream_engine.dart';
import '../neura_dream_models.dart';

/// Dream "show" screen – groups dreams by month.
///
/// This is a textual stand-in for your later AI-visual dream show.
class NeuraDreamShowScreen extends StatefulWidget {
  const NeuraDreamShowScreen({
    super.key,
    required this.engine,
  });

  final NeuraDreamEngine engine;

  @override
  State<NeuraDreamShowScreen> createState() =>
      _NeuraDreamShowScreenState();
}

class _NeuraDreamShowScreenState extends State<NeuraDreamShowScreen> {
  bool _initialized = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_initialized) return;
    _initialized = true;
    widget.engine.ensureLoaded();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Dream Show'),
      ),
      body: AnimatedBuilder(
        animation: widget.engine,
        builder: (context, _) {
          final byMonth = widget.engine.dreamsByMonth();
          if (byMonth.isEmpty) {
            return Center(
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Text(
                  'No dreams yet. Once you have a few, Neura can group '
                  'them into monthly shows here.',
                  style: theme.textTheme.bodyMedium,
                  textAlign: TextAlign.center,
                ),
              ),
            );
          }

          final keys = byMonth.keys.toList()..sort((a, b) => b.compareTo(a));

          return ListView.builder(
            padding: const EdgeInsets.all(16),
            itemCount: keys.length,
            itemBuilder: (context, index) {
              final key = keys[index];
              final dreams = byMonth[key] ?? const <NeuraDreamEntry>[];
              return _buildMonthCard(context, key, dreams);
            },
          );
        },
      ),
    );
  }

  Widget _buildMonthCard(
    BuildContext context,
    String monthKey,
    List<NeuraDreamEntry> dreams,
  ) {
    final theme = Theme.of(context);

    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
      ),
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              monthKey,
              style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 6),
            Text(
              'Dreams: ${dreams.length}',
              style: theme.textTheme.bodySmall,
            ),
            const SizedBox(height: 8),
            for (final d in dreams.take(3))
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Text(
                  '• ${d.title.isEmpty ? '(Untitled)' : d.title}',
                  style: theme.textTheme.bodyMedium,
                ),
              ),
            if (dreams.length > 3)
              Text(
                '…and ${dreams.length - 3} more',
                style: theme.textTheme.bodySmall,
              ),
            const SizedBox(height: 4),
            Text(
              'Future upgrade: AI-generated image show & narration for '
              'this month.',
              style: theme.textTheme.bodySmall?.copyWith(
                color: theme.colorScheme.primary,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
