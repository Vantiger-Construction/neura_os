/// Single dream entry as written or dictated by the user.
class NeuraDreamEntry {
  NeuraDreamEntry({
    required this.id,
    required this.date,
    required this.title,
    required this.rawText,
    required this.moodTag,
    required this.keySymbols,
  });

  final String id;
  final DateTime date;
  final String title;
  final String rawText;

  /// Simple mood label (e.g. "calm", "anxious", "epic").
  final String moodTag;

  /// Comma-separated notable symbols / themes (e.g. "water, flying").
  final String keySymbols;

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'date': date.toIso8601String(),
      'title': title,
      'rawText': rawText,
      'moodTag': moodTag,
      'keySymbols': keySymbols,
    };
  }

  static NeuraDreamEntry fromJson(Map<String, dynamic> json) {
    return NeuraDreamEntry(
      id: json['id'] as String,
      date: DateTime.parse(json['date'] as String),
      title: json['title'] as String? ?? '',
      rawText: json['rawText'] as String? ?? '',
      moodTag: json['moodTag'] as String? ?? '',
      keySymbols: json['keySymbols'] as String? ?? '',
    );
  }
}
