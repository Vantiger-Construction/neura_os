import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'neura_dream_models.dart';

/// Local dream storage + basic "show" assembly.
///
/// This is intentionally simple and local-only; you can later sync
/// it to Firestore or your backend.
class NeuraDreamEngine extends ChangeNotifier {
  static const _storageKey = 'neura_dream_entries_v1';

  final List<NeuraDreamEntry> _entries = <NeuraDreamEntry>[];
  bool _loaded = false;

  bool get isLoaded => _loaded;
  List<NeuraDreamEntry> get entries =>
      List.unmodifiable(_entries);

  Future<void> ensureLoaded() async {
    if (_loaded) return;
    await _loadFromStorage();
  }

  Future<void> _loadFromStorage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_storageKey);
      if (raw == null || raw.isEmpty) {
        _entries.clear();
        _loaded = true;
        notifyListeners();
        return;
      }
      final decoded = jsonDecode(raw);
      if (decoded is! List) {
        _entries.clear();
        _loaded = true;
        notifyListeners();
        return;
      }
      _entries
        ..clear()
        ..addAll(
          decoded
              .whereType<Map<String, dynamic>>()
              .map(NeuraDreamEntry.fromJson),
        );
      _entries.sort((a, b) => b.date.compareTo(a.date));
      _loaded = true;
      notifyListeners();
    } catch (e) {
      debugPrint('[NeuraDreamEngine] Failed to load: $e');
      _entries.clear();
      _loaded = true;
      notifyListeners();
    }
  }

  Future<void> _saveToStorage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final list = _entries.map((e) => e.toJson()).toList();
      await prefs.setString(_storageKey, jsonEncode(list));
    } catch (e) {
      debugPrint('[NeuraDreamEngine] Failed to save: $e');
    }
  }

  Future<void> addOrUpdate(NeuraDreamEntry entry) async {
    await ensureLoaded();
    final idx = _entries.indexWhere((e) => e.id == entry.id);
    if (idx == -1) {
      _entries.add(entry);
    } else {
      _entries[idx] = entry;
    }
    _entries.sort((a, b) => b.date.compareTo(a.date));
    await _saveToStorage();
    notifyListeners();
  }

  Future<void> delete(String id) async {
    await ensureLoaded();
    _entries.removeWhere((e) => e.id == id);
    await _saveToStorage();
    notifyListeners();
  }

  /// Very simple "show" structure: group dreams by month.
  Map<String, List<NeuraDreamEntry>> dreamsByMonth() {
    final map = <String, List<NeuraDreamEntry>>{};
    for (final e in _entries) {
      final key = '${e.date.year}-${e.date.month.toString().padLeft(2, '0')}';
      map.putIfAbsent(key, () => <NeuraDreamEntry>[]).add(e);
    }
    return map;
  }
}
