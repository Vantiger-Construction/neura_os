
import 'package:flutter/material.dart';

import '../neura_os_core/neura_weekly_snapshot.dart';
import '../neura_os_core/neura_focus_modes.dart';

class NeuraWeeklySnapshotHistoryPage extends StatelessWidget {
  final int weeks; // how many weeks back to show

  const NeuraWeeklySnapshotHistoryPage({
    super.key,
    this.weeks = 8,
  });

  @override
  Widget build(BuildContext context) {
    final service = NeuraWeeklySnapshotService.instance;
    final snaps = service.computeRecentWeeks(weeks: weeks);
    if (snaps.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('Weekly Snapshot History')),
        body: const Center(
          child: Text('Not enough data yet for weekly snapshots.'),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('Weekly Snapshot History')),
      body: ListView.builder(
        itemCount: snaps.length,
        itemBuilder: (context, index) {
          final snap = snaps[index];
          final label =
              '${snap.weekStart.month}/${snap.weekStart.day} - ${snap.weekEnd.month}/${snap.weekEnd.day}';
          return Card(
            margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      const Icon(Icons.calendar_today, size: 18),
                      const SizedBox(width: 8),
                      Text(
                        label,
                        style: Theme.of(context).textTheme.titleSmall,
                      ),
                      const Spacer(),
                      Text(
                        'Mood: ${snap.averageMood.toStringAsFixed(1)}/5',
                        style: Theme.of(context)
                            .textTheme
                            .bodySmall
                            ?.copyWith(color: Colors.grey),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Wrap(
                    spacing: 8,
                    runSpacing: 4,
                    children: [
                      _pill(Icons.spa, 'Rituals', snap.ritualsCompleted),
                      _pill(Icons.play_circle, 'Sessions',
                          snap.sessionsCompleted),
                      _pill(Icons.favorite, 'Good Deeds',
                          snap.goodDeedsLogged),
                      if (snap.dominantFocusMode != null)
                        _pill(
                          _iconForMode(snap.dominantFocusMode!),
                          'Most in',
                          null,
                          extra: snap.dominantFocusMode!.label,
                        ),
                    ],
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _pill(IconData icon, String label, int? value, {String? extra}) {
    final text = value != null ? '$value $label' : '$label: $extra';
    return Chip(
      avatar: Icon(icon, size: 16),
      label: Text(text),
    );
  }

  IconData _iconForMode(NeuraFocusMode mode) {
    switch (mode) {
      case NeuraFocusMode.normal:
        return Icons.balance;
      case NeuraFocusMode.deepWork:
        return Icons.center_focus_strong;
      case NeuraFocusMode.reflection:
        return Icons.self_improvement;
      case NeuraFocusMode.social:
        return Icons.people;
      case NeuraFocusMode.windDown:
        return Icons.nightlight_round;
    }
  }
}
