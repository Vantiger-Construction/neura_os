import 'package:flutter/material.dart';

import '../neura_smart_home_bridge.dart';
import '../neura_smart_home_models.dart';

/// A simple debug screen to prove that Neura's smart home bridge
/// is working, even before hooking up any real devices.
class NeuraSmartHomeDebugScreen extends StatefulWidget {
  const NeuraSmartHomeDebugScreen({super.key});

  @override
  State<NeuraSmartHomeDebugScreen> createState() =>
      _NeuraSmartHomeDebugScreenState();
}

class _NeuraSmartHomeDebugScreenState
    extends State<NeuraSmartHomeDebugScreen> {
  late final NeuraSmartHomeBridge _bridge;
  bool _initialized = false;

  bool _livingRoomOn = false;
  bool _bedroomOn = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_initialized) return;
    _initialized = true;
    _bridge = NeuraSmartHomeBridge();
    _bridge.ensureLoaded();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Neura Smart Home (stub)'),
      ),
      body: AnimatedBuilder(
        animation: _bridge,
        builder: (context, _) {
          final history = _bridge.history;

          return Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'This is a stub.',
                  style: theme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'These controls do not talk to real lights yet. '
                  'They simulate smart home actions, record them in '
                  'history, and mark them as success/failed. Later you '
                  'can swap the bridge internals to call a real API.',
                  style: theme.textTheme.bodyMedium,
                ),
                const SizedBox(height: 16),
                Card(
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16),
                  ),
                  elevation: 2,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      children: [
                        SwitchListTile(
                          value: _livingRoomOn,
                          onChanged: (v) async {
                            setState(() {
                              _livingRoomOn = v;
                            });
                            final action =
                                await _bridge.setRoomLights(
                              room: 'living_room',
                              on: v,
                              brightness: v ? 0.8 : 0.0,
                            );
                            _showSnackForAction(action);
                          },
                          title: const Text('Living room lights'),
                          subtitle: const Text(
                            'Simulated toggle for a living room light group.',
                          ),
                        ),
                        SwitchListTile(
                          value: _bedroomOn,
                          onChanged: (v) async {
                            setState(() {
                              _bedroomOn = v;
                            });
                            final action =
                                await _bridge.setRoomLights(
                              room: 'bedroom',
                              on: v,
                              brightness: v ? 0.4 : 0.0,
                            );
                            _showSnackForAction(action);
                          },
                          title: const Text('Bedroom lights'),
                          subtitle: const Text(
                            'Simulated toggle for a bedroom light group.',
                          ),
                        ),
                        const SizedBox(height: 8),
                        Row(
                          children: [
                            Expanded(
                              child: FilledButton.icon(
                                icon: const Icon(
                                    Icons.spa_rounded),
                                label: const Text(
                                  'Play "Calm ritual" scene',
                                ),
                                onPressed: () async {
                                  final action = await _bridge
                                      .playAtmosphereScene(
                                    sceneId: 'calm_ritual',
                                    params: {
                                      'lights': 'warm_dim',
                                      'music': 'soft_ambient',
                                    },
                                  );
                                  _showSnackForAction(action);
                                },
                              ),
                            ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                Text(
                  'Recent actions',
                  style: theme.textTheme.titleMedium?.copyWith(
                    fontWeight: FontWeight.w600,
                  ),
                ),
                const SizedBox(height: 8),
                Expanded(
                  child: history.isEmpty
                      ? Text(
                          'No simulated smart home actions yet. '
                          'Use the switches and buttons above to create some.',
                          style: theme.textTheme.bodyMedium,
                        )
                      : ListView.separated(
                          itemCount: history.length,
                          separatorBuilder: (_, __) =>
                              const SizedBox(height: 6),
                          itemBuilder: (context, index) {
                            final h = history[index];
                            return _buildHistoryTile(context, h);
                          },
                        ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  void _showSnackForAction(NeuraSmartHomeAction action) {
    if (!mounted) return;
    final success =
        action.status == NeuraSmartHomeActionStatus.success;
    final text = success
        ? 'Simulated smart home action succeeded.'
        : 'Simulated smart home action failed: ${action.errorMessage ?? 'unknown error'}';
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(text)),
    );
  }

  Widget _buildHistoryTile(
    BuildContext context,
    NeuraSmartHomeAction action,
  ) {
    final theme = Theme.of(context);
    final type = action.type;
    IconData icon;
    switch (type) {
      case NeuraSmartHomeCapabilityType.light:
        icon = Icons.lightbulb_rounded;
        break;
      case NeuraSmartHomeCapabilityType.music:
        icon = Icons.music_note_rounded;
        break;
      case NeuraSmartHomeCapabilityType.scene:
      default:
        icon = Icons.auto_awesome_rounded;
        break;
    }

    final date = action.createdAt;
    final dateLabel =
        '${date.year}-${date.month.toString().padLeft(2, '0')}-'
        '${date.day.toString().padLeft(2, '0')} '
        '${date.hour.toString().padLeft(2, '0')}:'
        '${date.minute.toString().padLeft(2, '0')}';

    final statusText =
        action.status == NeuraSmartHomeActionStatus.success
            ? 'Success'
            : action.status == NeuraSmartHomeActionStatus.failed
                ? 'Failed'
                : 'Pending';

    final statusColor =
        action.status == NeuraSmartHomeActionStatus.success
            ? Colors.green
            : action.status == NeuraSmartHomeActionStatus.failed
                ? Colors.red
                : theme.colorScheme.primary;

    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
      ),
      child: ListTile(
        leading: Icon(icon, color: statusColor),
        title: Text('${describeEnum(type)} · ${action.target}'),
        subtitle: Text('$statusText · $dateLabel'),
      ),
    );
  }
}
