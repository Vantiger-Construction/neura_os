import 'dart:convert';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'neura_smart_home_models.dart';

/// Stub smart home bridge.
///
/// This does NOT talk to any real devices yet. Instead it:
///   - records actions into local history (SharedPreferences)
///   - simulates success/failure
///   - notifies listeners so the UI can react
///
/// Later you can swap out the internals to call real APIs while
/// keeping the Neura-facing API intact.
class NeuraSmartHomeBridge extends ChangeNotifier {
  static const _historyKey = 'neura_smart_home_history_v1';

  final List<NeuraSmartHomeAction> _history =
      <NeuraSmartHomeAction>[];
  bool _loaded = false;
  final Random _rng = Random();

  bool get isLoaded => _loaded;

  List<NeuraSmartHomeAction> get history =>
      List.unmodifiable(_history);

  Future<void> ensureLoaded() async {
    if (_loaded) return;
    await _loadFromStorage();
  }

  Future<void> _loadFromStorage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_historyKey);
      if (raw == null || raw.isEmpty) {
        _history.clear();
        _loaded = true;
        notifyListeners();
        return;
      }
      final decoded = jsonDecode(raw);
      if (decoded is! List) {
        _history.clear();
        _loaded = true;
        notifyListeners();
        return;
      }
      _history
        ..clear()
        ..addAll(
          decoded
              .whereType<Map<String, dynamic>>()
              .map(NeuraSmartHomeAction.fromJson),
        );
      _history.sort((a, b) => b.createdAt.compareTo(a.createdAt));
      _loaded = true;
      notifyListeners();
    } catch (e) {
      debugPrint('[NeuraSmartHomeBridge] Failed to load: $e');
      _history.clear();
      _loaded = true;
      notifyListeners();
    }
  }

  Future<void> _saveToStorage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final list = _history.map((h) => h.toJson()).toList();
      await prefs.setString(_historyKey, jsonEncode(list));
    } catch (e) {
      debugPrint('[NeuraSmartHomeBridge] Failed to save: $e');
    }
  }

  Future<NeuraSmartHomeAction> _recordAndSimulate(
    NeuraSmartHomeAction action,
  ) async {
    await ensureLoaded();
    _history.add(action);
    _history.sort((a, b) => b.createdAt.compareTo(a.createdAt));
    notifyListeners();

    // Simulate async vendor call.
    await Future<void>.delayed(const Duration(milliseconds: 300));

    final success = _rng.nextDouble() > 0.05; // 95% success rate
    final updated = action.copyWith(
      status:
          success ? NeuraSmartHomeActionStatus.success : NeuraSmartHomeActionStatus.failed,
      errorMessage: success ? null : 'Simulated vendor error.',
    );

    final index =
        _history.indexWhere((h) => h.id == updated.id);
    if (index != -1) {
      _history[index] = updated;
    }
    notifyListeners();
    await _saveToStorage();
    return updated;
  }

  /// High-level API Neura can call from rituals, mood flows, etc.
  Future<NeuraSmartHomeAction> setRoomLights({
    required String room,
    required bool on,
    double? brightness,
  }) async {
    final id = 'light_${DateTime.now().millisecondsSinceEpoch}';
    final action = NeuraSmartHomeAction(
      id: id,
      createdAt: DateTime.now(),
      type: NeuraSmartHomeCapabilityType.light,
      target: room,
      parameters: {
        'on': on,
        if (brightness != null) 'brightness': brightness,
      },
      status: NeuraSmartHomeActionStatus.pending,
      errorMessage: null,
    );

    return _recordAndSimulate(action);
  }

  Future<NeuraSmartHomeAction> playMusicScene({
    required String sceneId,
    double? volume,
  }) async {
    final id = 'music_${DateTime.now().millisecondsSinceEpoch}';
    final action = NeuraSmartHomeAction(
      id: id,
      createdAt: DateTime.now(),
      type: NeuraSmartHomeCapabilityType.music,
      target: sceneId,
      parameters: {
        if (volume != null) 'volume': volume,
      },
      status: NeuraSmartHomeActionStatus.pending,
      errorMessage: null,
    );

    return _recordAndSimulate(action);
  }

  Future<NeuraSmartHomeAction> playAtmosphereScene({
    required String sceneId,
    Map<String, dynamic>? params,
  }) async {
    final id = 'scene_${DateTime.now().millisecondsSinceEpoch}';
    final action = NeuraSmartHomeAction(
      id: id,
      createdAt: DateTime.now(),
      type: NeuraSmartHomeCapabilityType.scene,
      target: sceneId,
      parameters: params ?? const {},
      status: NeuraSmartHomeActionStatus.pending,
      errorMessage: null,
    );

    return _recordAndSimulate(action);
  }
}
