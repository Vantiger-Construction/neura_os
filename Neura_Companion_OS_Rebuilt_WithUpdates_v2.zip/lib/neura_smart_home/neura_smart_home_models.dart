import 'package:flutter/foundation.dart';

/// Basic type of smart home capability.
///
/// This is intentionally generic so you can map it to any vendor
/// platform later (Hue, Home Assistant, Google, etc).
enum NeuraSmartHomeCapabilityType {
  light,
  music,
  scene,
}

/// A single action Neura requested for the smart home layer.
class NeuraSmartHomeAction {
  NeuraSmartHomeAction({
    required this.id,
    required this.createdAt,
    required this.type,
    required this.target,
    required this.parameters,
    required this.status,
    this.errorMessage,
  });

  final String id;
  final DateTime createdAt;
  final NeuraSmartHomeCapabilityType type;

  /// Target name or id (e.g. "living_room", "bedroom", "calm_scene").
  final String target;

  /// Vendor-agnostic key/value params (e.g. brightness, color, volume).
  final Map<String, dynamic> parameters;

  /// Simple status for our side of the world (not vendor-side telemetry).
  final NeuraSmartHomeActionStatus status;

  /// Error message (if any) from last attempt.
  final String? errorMessage;

  NeuraSmartHomeAction copyWith({
    NeuraSmartHomeActionStatus? status,
    String? errorMessage,
  }) {
    return NeuraSmartHomeAction(
      id: id,
      createdAt: createdAt,
      type: type,
      target: target,
      parameters: Map<String, dynamic>.from(parameters),
      status: status ?? this.status,
      errorMessage: errorMessage ?? this.errorMessage,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'createdAt': createdAt.toIso8601String(),
      'type': describeEnum(type),
      'target': target,
      'parameters': parameters,
      'status': describeEnum(status),
      'errorMessage': errorMessage,
    };
  }

  static NeuraSmartHomeAction fromJson(Map<String, dynamic> json) {
    return NeuraSmartHomeAction(
      id: json['id'] as String,
      createdAt: DateTime.parse(json['createdAt'] as String),
      type: _parseCapabilityType(json['type'] as String?),
      target: json['target'] as String? ?? 'unknown',
      parameters:
          (json['parameters'] as Map<String, dynamic>? ?? const {}),
      status: _parseStatus(json['status'] as String?),
      errorMessage: json['errorMessage'] as String?,
    );
  }

  static NeuraSmartHomeCapabilityType _parseCapabilityType(
    String? raw,
  ) {
    switch (raw) {
      case 'light':
        return NeuraSmartHomeCapabilityType.light;
      case 'music':
        return NeuraSmartHomeCapabilityType.music;
      case 'scene':
      default:
        return NeuraSmartHomeCapabilityType.scene;
    }
  }

  static NeuraSmartHomeActionStatus _parseStatus(String? raw) {
    switch (raw) {
      case 'pending':
        return NeuraSmartHomeActionStatus.pending;
      case 'success':
        return NeuraSmartHomeActionStatus.success;
      case 'failed':
        return NeuraSmartHomeActionStatus.failed;
      default:
        return NeuraSmartHomeActionStatus.pending;
    }
  }
}

/// Local status for an action (from Neura's side, not the vendor).
enum NeuraSmartHomeActionStatus {
  pending,
  success,
  failed,
}
