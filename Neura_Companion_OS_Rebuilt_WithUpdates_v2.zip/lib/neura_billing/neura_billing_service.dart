import 'package:flutter/foundation.dart';

/// Very small billing facade so your UI & logic do not depend on the
/// actual in-app purchase plugin directly.
///
/// Implement this with in_app_purchase or a server-verified flow.
abstract class NeuraBillingBackend {
  Future<void> init();

  Future<bool> isPremiumActive();

  Future<bool> purchaseProduct(String productId);

  Stream<bool> get premiumChanges;
}

class NeuraBillingService extends ChangeNotifier {
  NeuraBillingService({required NeuraBillingBackend backend})
      : _backend = backend;

  final NeuraBillingBackend _backend;

  bool _initialized = false;
  bool _premium = false;

  bool get isInitialized => _initialized;
  bool get isPremium => _premium;

  Future<void> ensureInitialized() async {
    if (_initialized) return;
    await _backend.init();
    _premium = await _backend.isPremiumActive();
    _backend.premiumChanges.listen((value) {
      _premium = value;
      notifyListeners();
    });
    _initialized = true;
    notifyListeners();
  }

  Future<bool> ensurePremium({String? productId}) async {
    await ensureInitialized();
    if (_premium) return true;
    if (productId == null) return false;
    final ok = await _backend.purchaseProduct(productId);
    if (ok) {
      _premium = true;
      notifyListeners();
    }
    return ok;
  }
}
