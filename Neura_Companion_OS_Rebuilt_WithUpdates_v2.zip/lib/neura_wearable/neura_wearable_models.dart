/// Basic wearable HR/HRV sample parsed from RR-intervals or vendor data.
class NeuraHrvSample {
  NeuraHrvSample({
    required this.timestamp,
    required this.heartRateBpm,
    required this.rmssdMs,
    required this.sdnnMs,
  });

  /// When this sample was computed.
  final DateTime timestamp;

  /// Instant heart rate in beats per minute.
  final double heartRateBpm;

  /// Root Mean Square of Successive Differences (ms).
  final double rmssdMs;

  /// Standard deviation of NN intervals (ms).
  final double sdnnMs;

  Map<String, dynamic> toJson() {
    return {
      'timestamp': timestamp.toIso8601String(),
      'heartRateBpm': heartRateBpm,
      'rmssdMs': rmssdMs,
      'sdnnMs': sdnnMs,
    };
  }

  static NeuraHrvSample fromJson(Map<String, dynamic> json) {
    return NeuraHrvSample(
      timestamp: DateTime.parse(json['timestamp'] as String),
      heartRateBpm: (json['heartRateBpm'] as num).toDouble(),
      rmssdMs: (json['rmssdMs'] as num).toDouble(),
      sdnnMs: (json['sdnnMs'] as num).toDouble(),
    );
  }
}

/// Connection status for the wearable bridge.
enum NeuraWearableStatus {
  disconnected,
  connecting,
  connected,
  simulation,
}
