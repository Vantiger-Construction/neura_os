import 'package:flutter/material.dart';

import '../neura_wearable_hrv_bridge.dart';
import '../neura_wearable_models.dart';

/// Simple debug screen to prove the HRV bridge works before real BLE.
class NeuraWearableHrvDebugScreen extends StatefulWidget {
  const NeuraWearableHrvDebugScreen({super.key});

  @override
  State<NeuraWearableHrvDebugScreen> createState() =>
      _NeuraWearableHrvDebugScreenState();
}

class _NeuraWearableHrvDebugScreenState
    extends State<NeuraWearableHrvDebugScreen> {
  late final NeuraWearableHrvBridge _bridge;
  bool _initialized = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (_initialized) return;
    _initialized = true;
    _bridge = NeuraWearableHrvBridge();
    _bridge.ensureLoaded();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Neura Wearable HRV (stub)'),
      ),
      body: AnimatedBuilder(
        animation: _bridge,
        builder: (context, _) {
          final status = _bridge.status;
          final deviceName = _bridge.deviceName ?? 'None';
          final samples = _bridge.samples;

          final latest = samples.isNotEmpty ? samples.first : null;

          return Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'BLE HRV adapter stub',
                  style: theme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  'This does not connect to any real device yet. It parses '
                  'RR-interval series into HR/HRV metrics and stores them. '
                  'The simulation can generate fake HRV data every few '
                  'seconds so you can wire charts and emotion logic.',
                  style: theme.textTheme.bodyMedium,
                ),
                const SizedBox(height: 16),
                _buildStatusRow(theme, status, deviceName),
                const SizedBox(height: 12),
                Row(
                  children: [
                    FilledButton.icon(
                      icon: const Icon(Icons.play_arrow_rounded),
                      label: const Text('Start simulation'),
                      onPressed: () {
                        _bridge.startDebugSimulation();
                      },
                    ),
                    const SizedBox(width: 8),
                    OutlinedButton.icon(
                      icon: const Icon(Icons.stop_rounded),
                      label: const Text('Stop simulation'),
                      onPressed: () {
                        _bridge.stopDebugSimulation();
                      },
                    ),
                  ],
                ),
                const SizedBox(height: 16),
                if (latest != null)
                  _buildLatestCard(context, latest)
                else
                  Text(
                    'No HRV samples yet. Start simulation to see data.',
                    style: theme.textTheme.bodyMedium,
                  ),
                const SizedBox(height: 12),
                Expanded(
                  child: samples.isEmpty
                      ? const SizedBox.shrink()
                      : ListView.separated(
                          itemCount: samples.length,
                          separatorBuilder: (_, __) =>
                              const SizedBox(height: 6),
                          itemBuilder: (context, index) {
                            final s = samples[index];
                            return _buildSampleTile(context, s);
                          },
                        ),
                ),
              ],
            ),
          );
        },
      ),
    );
  }

  Widget _buildStatusRow(
    ThemeData theme,
    NeuraWearableStatus status,
    String deviceName,
  ) {
    String label;
    Color color;
    switch (status) {
      case NeuraWearableStatus.disconnected:
        label = 'Disconnected';
        color = Colors.red;
        break;
      case NeuraWearableStatus.connecting:
        label = 'Connecting...';
        color = Colors.orange;
        break;
      case NeuraWearableStatus.connected:
        label = 'Connected';
        color = Colors.green;
        break;
      case NeuraWearableStatus.simulation:
        label = 'Simulation mode';
        color = Colors.blue;
        break;
    }

    return Row(
      children: [
        Icon(Icons.watch_rounded, color: color),
        const SizedBox(width: 8),
        Text(
          label,
          style: theme.textTheme.bodyMedium?.copyWith(
            color: color,
            fontWeight: FontWeight.w600,
          ),
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Text(
            'Device: $deviceName',
            style: theme.textTheme.bodyMedium,
            overflow: TextOverflow.ellipsis,
          ),
        ),
      ],
    );
  }

  Widget _buildLatestCard(BuildContext context, NeuraHrvSample sample) {
    final theme = Theme.of(context);

    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: theme.colorScheme.primaryContainer.withOpacity(0.9),
        borderRadius: BorderRadius.circular(16),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            'Latest HRV sample',
            style: theme.textTheme.titleMedium?.copyWith(
              fontWeight: FontWeight.w600,
              color: theme.colorScheme.onPrimaryContainer,
            ),
          ),
          const SizedBox(height: 4),
          Text(
            'HR: ${sample.heartRateBpm.toStringAsFixed(1)} bpm',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onPrimaryContainer,
            ),
          ),
          Text(
            'RMSSD: ${sample.rmssdMs.toStringAsFixed(1)} ms',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onPrimaryContainer,
            ),
          ),
          Text(
            'SDNN: ${sample.sdnnMs.toStringAsFixed(1)} ms',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: theme.colorScheme.onPrimaryContainer,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildSampleTile(BuildContext context, NeuraHrvSample sample) {
    final theme = Theme.of(context);
    final t = sample.timestamp;
    final dateLabel =
        '${t.year}-${t.month.toString().padLeft(2, '0')}-'
        '${t.day.toString().padLeft(2, '0')} '
        '${t.hour.toString().padLeft(2, '0')}:'
        '${t.minute.toString().padLeft(2, '0')}';

    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(14),
      ),
      child: ListTile(
        leading: Icon(Icons.monitor_heart_rounded,
            color: theme.colorScheme.primary),
        title: Text(
          '${sample.heartRateBpm.toStringAsFixed(1)} bpm',
        ),
        subtitle: Text(
          'RMSSD ${sample.rmssdMs.toStringAsFixed(1)} ms · '
          'SDNN ${sample.sdnnMs.toStringAsFixed(1)} ms · '
          dateLabel,
        ),
      ),
    );
  }
}
