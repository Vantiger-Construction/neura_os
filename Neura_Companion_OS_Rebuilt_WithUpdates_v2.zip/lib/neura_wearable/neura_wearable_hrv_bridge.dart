import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'neura_wearable_models.dart';

/// BLE / HealthKit / Health Connect HRV bridge (stub).
///
/// This does NOT actually talk to a device yet. Instead it:
///   - Accepts RR-interval arrays (ms) via [onRawRrIntervals].
///   - Calculates HR, RMSSD, SDNN.
///   - Stores recent samples locally.
///   - Can run a debug "simulation" mode that generates fake samples.
///
/// Later you plug in real platform-specific code to feed RR-intervals
/// into this bridge.
class NeuraWearableHrvBridge extends ChangeNotifier {
  static const _storageKey = 'neura_wearable_hrv_samples_v1';
  static const _maxStoredSamples = 256;

  final List<NeuraHrvSample> _samples = <NeuraHrvSample>[];
  bool _loaded = false;

  NeuraWearableStatus _status = NeuraWearableStatus.disconnected;
  String? _deviceName;

  Timer? _simulationTimer;
  final Random _rng = Random();

  bool get isLoaded => _loaded;
  NeuraWearableStatus get status => _status;
  String? get deviceName => _deviceName;

  List<NeuraHrvSample> get samples =>
      List.unmodifiable(_samples);

  Future<void> ensureLoaded() async {
    if (_loaded) return;
    await _loadFromStorage();
  }

  Future<void> _loadFromStorage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_storageKey);
      if (raw == null || raw.isEmpty) {
        _samples.clear();
        _loaded = true;
        notifyListeners();
        return;
      }
      final decoded = jsonDecode(raw);
      if (decoded is! List) {
        _samples.clear();
        _loaded = true;
        notifyListeners();
        return;
      }
      _samples
        ..clear()
        ..addAll(
          decoded
              .whereType<Map<String, dynamic>>()
              .map(NeuraHrvSample.fromJson),
        );
      _samples.sort((a, b) => b.timestamp.compareTo(a.timestamp));
      _loaded = true;
      notifyListeners();
    } catch (e) {
      debugPrint('[NeuraWearableHrvBridge] Failed to load: $e');
      _samples.clear();
      _loaded = true;
      notifyListeners();
    }
  }

  Future<void> _saveToStorage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final list = _samples.map((s) => s.toJson()).toList();
      await prefs.setString(_storageKey, jsonEncode(list));
    } catch (e) {
      debugPrint('[NeuraWearableHrvBridge] Failed to save: $e');
    }
  }

  /// Call this when your platform-specific plugin receives RR-intervals
  /// (in milliseconds) from a wearable.
  Future<void> onRawRrIntervals(List<int> rrMs) async {
    if (rrMs.isEmpty) return;
    await ensureLoaded();

    final sample = _computeFromRr(rrMs);
    _samples.insert(0, sample);
    if (_samples.length > _maxStoredSamples) {
      _samples.removeRange(_maxStoredSamples, _samples.length);
    }
    await _saveToStorage();
    notifyListeners();
  }

  NeuraHrvSample _computeFromRr(List<int> rrMs) {
    final now = DateTime.now();
    final values = rrMs.map((e) => e.toDouble()).toList();
    final mean = values.reduce((a, b) => a + b) / values.length;

    // Heart rate: 60,000 ms per minute / mean RR
    final hr = 60000.0 / mean;

    // RMSSD
    double rmssd;
    if (values.length < 2) {
      rmssd = 0.0;
    } else {
      final diffs = <double>[];
      for (var i = 1; i < values.length; i++) {
        final diff = values[i] - values[i - 1];
        diffs.add(diff * diff);
      }
      rmssd = sqrt(
        diffs.reduce((a, b) => a + b) / diffs.length,
      );
    }

    // SDNN
    double sdnn;
    if (values.length < 2) {
      sdnn = 0.0;
    } else {
      final meanVal = mean;
      final sumSq = values
          .map((v) => (v - meanVal) * (v - meanVal))
          .reduce((a, b) => a + b);
      sdnn = sqrt(sumSq / (values.length - 1));
    }

    return NeuraHrvSample(
      timestamp: now,
      heartRateBpm: hr,
      rmssdMs: rmssd,
      sdnnMs: sdnn,
    );
  }

  /// Starts a debug simulation mode.
  ///
  /// This does NOT require any real device. It just creates a fake
  /// RR-interval series every few seconds and uses [onRawRrIntervals].
  void startDebugSimulation() {
    _simulationTimer?.cancel();
    _status = NeuraWearableStatus.simulation;
    _deviceName = 'Simulated HRV device';
    notifyListeners();

    _simulationTimer = Timer.periodic(
      const Duration(seconds: 5),
      (_) {
        final rr = _generateFakeRrSeries();
        onRawRrIntervals(rr);
      },
    );
  }

  void stopDebugSimulation() {
    _simulationTimer?.cancel();
    _simulationTimer = null;
    _status = NeuraWearableStatus.disconnected;
    _deviceName = null;
    notifyListeners();
  }

  List<int> _generateFakeRrSeries() {
    // Base around 800 ms (75 bpm) with some jitter.
    final base = 800.0 + _rng.nextDouble() * 200.0 - 100.0;
    final list = <int>[];
    for (var i = 0; i < 20; i++) {
      final jitter = _rng.nextDouble() * 60.0 - 30.0;
      list.add((base + jitter).clamp(500.0, 1200.0).round());
    }
    return list;
  }

  @override
  void dispose() {
    _simulationTimer?.cancel();
    _simulationTimer = null;
    super.dispose();
  }
}
