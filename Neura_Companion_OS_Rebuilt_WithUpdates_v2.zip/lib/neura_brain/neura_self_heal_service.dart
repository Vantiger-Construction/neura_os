import 'package:flutter/foundation.dart';

/// A single error or warning Neura noticed while running.
class NeuraErrorRecord {
  NeuraErrorRecord({
    required this.timestamp,
    required this.source,
    required this.message,
    this.stack,
    this.severity = NeuraErrorSeverity.warning,
  });

  final DateTime timestamp;
  final String source;
  final String message;
  final String? stack;
  final NeuraErrorSeverity severity;
}

enum NeuraErrorSeverity { info, warning, error }

/// Result of a self-heal attempt or diagnostic check.
class NeuraSelfHealResult {
  NeuraSelfHealResult({
    required this.success,
    required this.headline,
    required this.detail,
    this.usedDimensionalSync = false,
  });

  final bool success;
  final String headline;
  final String detail;
  final bool usedDimensionalSync;
}

/// Central self-heal / diagnostic brain.
///
/// This is intentionally app-focused (network, configuration, state) –
/// it is *not* a health/medical system. It simply tracks technical issues
/// and exposes a playful "Dimensional Sync" gag for error recovery UX.
class NeuraSelfHealService extends ChangeNotifier {
  final List<NeuraErrorRecord> _recentErrors = <NeuraErrorRecord>[];
  bool _safeMode = false;
  DateTime? _lastDimensionalSyncAt;
  NeuraSelfHealResult? _lastResult;

  static const int _maxErrors = 50;

  List<NeuraErrorRecord> get recentErrors =>
      List.unmodifiable(_recentErrors);
  bool get safeMode => _safeMode;
  DateTime? get lastDimensionalSyncAt => _lastDimensionalSyncAt;
  NeuraSelfHealResult? get lastResult => _lastResult;

  /// Report an error from anywhere in the app.
  ///
  /// You can call this from try/catch blocks or error handlers.
  void reportError({
    required String source,
    required String message,
    NeuraErrorSeverity severity = NeuraErrorSeverity.warning,
    StackTrace? stack,
  }) {
    final record = NeuraErrorRecord(
      timestamp: DateTime.now(),
      source: source,
      message: message,
      stack: stack?.toString(),
      severity: severity,
    );

    _recentErrors.add(record);
    if (_recentErrors.length > _maxErrors) {
      _recentErrors.removeRange(0, _recentErrors.length - _maxErrors);
    }

    debugPrint(
      '[NeuraSelfHeal] ($severity) $source: $message'
      '${stack != null ? '\n$stack' : ''}',
    );

    notifyListeners();
  }

  /// Clear all recorded errors.
  void clearErrors() {
    _recentErrors.clear();
    notifyListeners();
  }

  /// Toggle safe mode manually.
  void setSafeMode(bool value) {
    if (_safeMode == value) return;
    _safeMode = value;
    notifyListeners();
  }

  /// Quick health check – currently just inspects error count and safe mode.
  Future<NeuraSelfHealResult> runHealthCheck() async {
    await Future<void>.delayed(const Duration(milliseconds: 250));

    final errorCount = _recentErrors.length;

    String headline;
    String detail;

    if (errorCount == 0) {
      headline = 'All clear for now';
      detail =
          'No recent internal errors recorded. Neura is purring along nicely.';
    } else if (errorCount < 5) {
      headline = 'A few bumps in the log';
      detail =
          'There are $errorCount recent warnings or errors. Safe mode is '
          '${_safeMode ? 'ON' : 'OFF'}.';
    } else {
      headline = 'Spicy log detected';
      detail =
          'There are $errorCount recent issues. If things feel unstable, '
          'you can enable Safe Mode while you debug.';
    }

    final result = NeuraSelfHealResult(
      success: true,
      headline: headline,
      detail: detail,
      usedDimensionalSync: false,
    );

    _lastResult = result;
    notifyListeners();
    return result;
  }

  /// Attempts a playful "Dimensional Sync" fix.
  ///
  /// This does not magically solve real bugs, but it provides:
  ///   * A single place to toggle safe mode and reset certain caches.
  ///   * A fun UX wrapper message so users feel cared for, not blamed.
  Future<NeuraSelfHealResult> runDimensionalSync() async {
    // Fake a short "sync" delay for animation timing.
    await Future<void>.delayed(const Duration(milliseconds: 600));

    _safeMode = true;
    _lastDimensionalSyncAt = DateTime.now();

    final lines = <String>[
      'Your multiversal twin already debugged this. You’re welcome.',
      'Borrowed a stable timeline where this bug never existed.',
      'Re-aligning quantum ducks into a neat little row...',
      'Imported a patch from Universe v2.7. Stability should feel smoother.',
    ];

    final tagline = lines[DateTime.now().millisecond % lines.length];

    final result = NeuraSelfHealResult(
      success: true,
      headline: 'Dimensional Sync complete',
      detail: tagline,
      usedDimensionalSync: true,
    );

    _lastResult = result;
    notifyListeners();
    return result;
  }
}
