import 'package:flutter/material.dart';

/// High-level analytics dashboard stub.
///
/// Intentionally left widget-only (no package imports like fl_chart)
/// so you can drop in your existing chart widgets. This gives you
/// a central place to surface mood, Mirror, HRV, and ritual data.
class NeuraAnalyticsDashboardScreen extends StatelessWidget {
  const NeuraAnalyticsDashboardScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Neura Analytics'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: ListView(
          children: [
            Text(
              'Emotional & ritual analytics',
              style: theme.textTheme.titleLarge?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              'This screen is a hub for your mood charts, Mirror sessions, '
              'HRV trends, and ritual usage. Hook in your existing chart '
              'widgets here (fl_chart, etc.).',
              style: theme.textTheme.bodyMedium,
            ),
            const SizedBox(height: 16),
            _placeholderCard(
              context,
              title: 'Mood over time',
              description:
                  'Line or area chart of mood vs day. Feed from your '
                  'mood history store.',
            ),
            _placeholderCard(
              context,
              title: 'Mirror Mode sessions',
              description:
                  'Bar chart or timeline of Mirror emotion labels. Use '
                  'NeuraMirrorEngine.sessions as input.',
            ),
            _placeholderCard(
              context,
              title: 'HRV & heart rate',
              description:
                  'Overlay HR and HRV (RMSSD/SDNN) over time. Use '
                  'NeuraWearableHrvBridge.samples.',
            ),
            _placeholderCard(
              context,
              title: 'Ritual usage heatmap',
              description:
                  'Heatmap of rituals per day/time. Connect to your '
                  'ritual history store.',
            ),
          ],
        ),
      ),
    );
  }

  Widget _placeholderCard(
    BuildContext context, {
    required String title,
    required String description,
  }) {
    final theme = Theme.of(context);
    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
      ),
      margin: const EdgeInsets.only(bottom: 12),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              title,
              style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              description,
              style: theme.textTheme.bodyMedium,
            ),
            const SizedBox(height: 6),
            Container(
              height: 140,
              width: double.infinity,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(14),
                border: Border.all(
                  color: theme.dividerColor,
                ),
              ),
              alignment: Alignment.center,
              child: Text(
                'Drop your chart widget here',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.hintColor,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
