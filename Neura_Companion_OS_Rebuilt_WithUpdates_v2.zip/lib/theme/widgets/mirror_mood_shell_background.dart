import 'dart:ui';
import 'package:flutter/material.dart';
import '../services/mirror_mood_theme_service.dart';

class MirrorMoodShellBackground extends StatelessWidget {
  final Widget child;

  const MirrorMoodShellBackground({
    Key? key,
    required this.child,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    final cfg = MirrorMoodThemeService.instance.current;
    return Container(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: [cfg.backgroundTop, cfg.backgroundBottom],
        ),
      ),
      child: BackdropFilter(
        filter: ImageFilter.blur(
          sigmaX: cfg.blurStrength,
          sigmaY: cfg.blurStrength,
        ),
        child: Container(
          color: Colors.black.withOpacity(0.25),
          child: child,
        ),
      ),
    );
  }
}
