import 'dart:math';
import 'package:flutter/material.dart';
import '../models/mirror_mood_theme_config.dart';

class MirrorMoodThemeService {
  MirrorMoodThemeService._();
  static final MirrorMoodThemeService instance = MirrorMoodThemeService._();

  MirrorMoodThemeConfig _current = MirrorMoodThemeConfig.neutral();
  MirrorMoodThemeConfig get current => _current;

  void updateFromSignals({
    required double moodScore,
    required double arousal,
    required String mirrorEmotionLabel,
  }) {
    moodScore = moodScore.clamp(0.0, 1.0);
    arousal = arousal.clamp(-1.0, 1.0);
    final emo = mirrorEmotionLabel.toLowerCase();

    final moodLabel = _moodLabel(moodScore);
    final intensityLabel = _intensityLabel(arousal, emo);

    final bg = _pickBackground(moodScore, arousal, emo);
    final accent = _pickAccent(moodScore, emo);
    final blur = _pickBlur(moodScore, arousal);
    final difficulty = _pickDifficulty(moodScore, arousal, emo);

    _current = MirrorMoodThemeConfig(
      backgroundTop: bg.item1,
      backgroundBottom: bg.item2,
      accent: accent,
      blurStrength: blur,
      difficultyFactor: difficulty,
      moodLabel: moodLabel,
      intensityLabel: intensityLabel,
    );
  }

  String _moodLabel(double mood) {
    if (mood <= 0.3) return 'low';
    if (mood >= 0.7) return 'high';
    return 'balanced';
  }

  String _intensityLabel(double arousal, String emo) {
    final stressedWords = ['angry', 'fear', 'panic', 'anxious', 'overwhelmed'];
    final isStressed = stressedWords.any(emo.contains);
    if (arousal <= -0.4) return 'drained';
    if (arousal >= 0.6 && isStressed) return 'stressed';
    if (arousal >= 0.6) return 'amped';
    return 'steady';
  }

  (Color, Color) _pickBackground(double mood, double arousal, String emo) {
    if (mood <= 0.3 && arousal <= -0.2) {
      return (const Color(0xFF080C16), const Color(0xFF020307));
    }
    if (mood <= 0.4 && arousal >= 0.4) {
      return (const Color(0xFF2B0F2F), const Color(0xFF110214));
    }
    if (mood > 0.3 && mood < 0.7 && arousal <= -0.3) {
      return (const Color(0xFF0B1A26), const Color(0xFF040A10));
    }
    if (mood > 0.3 && mood < 0.7) {
      return (const Color(0xFF141925), const Color(0xFF05070B));
    }
    if (mood >= 0.7 && arousal <= 0.3) {
      return (const Color(0xFF14352E), const Color(0xFF06130F));
    }
    return (const Color(0xFF2D3C72), const Color(0xFF17182E));
  }

  Color _pickAccent(double mood, String emo) {
    if (emo.contains('sad') || emo.contains('cry') || mood <= 0.3) {
      return const Color(0xFF64B5F6);
    }
    if (emo.contains('angry') || emo.contains('fear')) {
      return const Color(0xFFFF7043);
    }
    if (mood >= 0.7) {
      return const Color(0xFF81C784);
    }
    return const Color(0xFF80CBC4);
  }

  double _pickBlur(double mood, double arousal) {
    if (mood <= 0.3 && arousal >= 0.4) return 14.0;
    if (mood <= 0.4) return 10.0;
    if (arousal <= -0.5) return 12.0;
    return 6.0;
  }

  double _pickDifficulty(double mood, double arousal, String emo) {
    double diff = 1.0;
    if (mood <= 0.3 || arousal <= -0.5) {
      diff = 0.7;
    }
    if (mood >= 0.7 && arousal >= 0.3) {
      diff = 1.2;
    }
    final stressedWords = ['angry', 'fear', 'panic', 'anxious', 'overwhelmed'];
    if (stressedWords.any(emo.contains)) {
      diff = min(diff, 0.9);
    }
    return diff.clamp(0.5, 1.5);
  }
}
