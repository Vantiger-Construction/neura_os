import 'package:flutter/material.dart';

class MirrorMoodThemeConfig {
  final Color backgroundTop;
  final Color backgroundBottom;
  final Color accent;
  final double blurStrength;
  final double difficultyFactor;
  final String moodLabel;
  final String intensityLabel;

  const MirrorMoodThemeConfig({
    required this.backgroundTop,
    required this.backgroundBottom,
    required this.accent,
    required this.blurStrength,
    required this.difficultyFactor,
    required this.moodLabel,
    required this.intensityLabel,
  });

  MirrorMoodThemeConfig copyWith({
    Color? backgroundTop,
    Color? backgroundBottom,
    Color? accent,
    double? blurStrength,
    double? difficultyFactor,
    String? moodLabel,
    String? intensityLabel,
  }) {
    return MirrorMoodThemeConfig(
      backgroundTop: backgroundTop ?? this.backgroundTop,
      backgroundBottom: backgroundBottom ?? this.backgroundBottom,
      accent: accent ?? this.accent,
      blurStrength: blurStrength ?? this.blurStrength,
      difficultyFactor: difficultyFactor ?? this.difficultyFactor,
      moodLabel: moodLabel ?? this.moodLabel,
      intensityLabel: intensityLabel ?? this.intensityLabel,
    );
  }

  static MirrorMoodThemeConfig neutral() {
    return const MirrorMoodThemeConfig(
      backgroundTop: Color(0xFF141925),
      backgroundBottom: Color(0xFF05070B),
      accent: Color(0xFF80CBC4),
      blurStrength: 6.0,
      difficultyFactor: 1.0,
      moodLabel: 'balanced',
      intensityLabel: 'steady',
    );
  }
}
