
import 'package:flutter/material.dart';

import '../neura_os_core/neura_weekly_snapshot.dart';
import '../neura_os_core/neura_focus_modes.dart';

/// Compact weekly snapshot card for the dashboard.
class NeuraWeeklySnapshotCard extends StatelessWidget {
  final int weeksBack; // 0 = current week, 1 = last week, etc.

  const NeuraWeeklySnapshotCard({
    super.key,
    this.weeksBack = 0,
  });

  @override
  Widget build(BuildContext context) {
    final service = NeuraWeeklySnapshotService.instance;
    final snaps = service.computeRecentWeeks(weeks: weeksBack + 1);
    if (snaps.isEmpty) {
      return const SizedBox.shrink();
    }
    final snap = snaps[weeksBack];

    final dateLabel =
        '${snap.weekStart.month}/${snap.weekStart.day} - ${snap.weekEnd.month}/${snap.weekEnd.day}';

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.insights),
                const SizedBox(width: 8),
                Text(
                  'Weekly Snapshot',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const Spacer(),
                Text(
                  dateLabel,
                  style: Theme.of(context)
                      .textTheme
                      .bodySmall
                      ?.copyWith(color: Colors.grey),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                _metricChip(
                  context,
                  icon: Icons.spa,
                  label: 'Rituals',
                  value: snap.ritualsCompleted.toString(),
                ),
                const SizedBox(width: 8),
                _metricChip(
                  context,
                  icon: Icons.play_circle,
                  label: 'Sessions',
                  value: snap.sessionsCompleted.toString(),
                ),
                const SizedBox(width: 8),
                _metricChip(
                  context,
                  icon: Icons.favorite,
                  label: 'Good Deeds',
                  value: snap.goodDeedsLogged.toString(),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: _moodBar(context, snap.averageMood),
                ),
                const SizedBox(width: 12),
                if (snap.dominantFocusMode != null)
                  Column(
                    crossAxisAlignment: CrossAxisAlignment.end,
                    children: [
                      Text(
                        'Most time in:',
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                      const SizedBox(height: 2),
                      Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Icon(
                            _iconForMode(snap.dominantFocusMode!),
                            size: 16,
                          ),
                          const SizedBox(width: 4),
                          Text(
                            snap.dominantFocusMode!.label,
                            style: Theme.of(context).textTheme.bodySmall,
                          ),
                        ],
                      ),
                    ],
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _metricChip(
    BuildContext context, {
    required IconData icon,
    required String label,
    required String value,
  }) {
    return Chip(
      avatar: Icon(icon, size: 16),
      label: Text('$value $label'),
    );
  }

  Widget _moodBar(BuildContext context, double avgMood) {
    final clamped = avgMood.clamp(0.0, 5.0);
    final fraction = clamped / 5.0;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'Avg Mood',
          style: Theme.of(context).textTheme.bodySmall,
        ),
        const SizedBox(height: 4),
        Stack(
          children: [
            Container(
              height: 8,
              decoration: BoxDecoration(
                color: Colors.grey.shade300,
                borderRadius: BorderRadius.circular(999),
              ),
            ),
            FractionallySizedBox(
              widthFactor: fraction.isNaN ? 0.0 : fraction,
              child: Container(
                height: 8,
                decoration: BoxDecoration(
                  color: _moodColor(avgMood),
                  borderRadius: BorderRadius.circular(999),
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }

  Color _moodColor(double value) {
    if (value <= 2.0) return Colors.redAccent;
    if (value <= 3.0) return Colors.orangeAccent;
    if (value <= 4.0) return Colors.amberAccent;
    return Colors.greenAccent;
  }

  IconData _iconForMode(NeuraFocusMode mode) {
    switch (mode) {
      case NeuraFocusMode.normal:
        return Icons.balance;
      case NeuraFocusMode.deepWork:
        return Icons.center_focus_strong;
      case NeuraFocusMode.reflection:
        return Icons.self_improvement;
      case NeuraFocusMode.social:
        return Icons.people;
      case NeuraFocusMode.windDown:
        return Icons.nightlight_round;
    }
  }
}
