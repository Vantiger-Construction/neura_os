
import 'dart:math';

import 'package:flutter/material.dart';

import '../neura_os_core/neura_values_profile.dart';
import '../neura_os_core/neura_weekly_snapshot.dart';
import '../neura_os_core/neura_values_journal_prompts.dart';
import '../neura_os_core/neura_weekly_snapshot.dart' as weekly;

class NeuraValuesJournalPromptBanner extends StatelessWidget {
  final VoidCallback? onOpenJournal;

  const NeuraValuesJournalPromptBanner({
    super.key,
    this.onOpenJournal,
  });

  @override
  Widget build(BuildContext context) {
    final profile = NeuraValuesService.instance.profile;
    if (profile.isEmpty) return const SizedBox.shrink();

    final snaps = NeuraWeeklySnapshotService.instance
        .computeRecentWeeks(weeks: 1);
    final snap = snaps.isNotEmpty ? snaps.first : null;

    final prompts = NeuraValuesJournalPrompts.buildPrompts(
      profile: profile,
      snapshot: snap,
    );
    if (prompts.isEmpty) return const SizedBox.shrink();

    final rand = Random();
    final prompt = prompts[rand.nextInt(prompts.length)];

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      color: Theme.of(context).colorScheme.secondaryContainer,
      child: ListTile(
        leading: const Icon(Icons.menu_book),
        title: const Text('Values-Based Reflection'),
        subtitle: Text(prompt),
        trailing: IconButton(
          icon: const Icon(Icons.edit),
          onPressed: onOpenJournal,
        ),
      ),
    );
  }
}
