
import 'package:flutter/material.dart';

import '../neura_os_core/neura_values_action_engine.dart';
import '../neura_os_core/neura_session_engine.dart';
import '../neura_os_core/neura_module_registry.dart';

/// Panel that lists today's values-aligned suggestions and lets the
/// user act on them.
class NeuraValuesSuggestionPanel extends StatefulWidget {
  /// Called when a journal suggestion is chosen.
  final VoidCallback? onOpenJournal;

  /// Called when a good-deed suggestion is chosen (for your Good Deeds UI).
  final void Function(String category)? onOpenGoodDeeds;

  const NeuraValuesSuggestionPanel({
    super.key,
    this.onOpenJournal,
    this.onOpenGoodDeeds,
  });

  @override
  State<NeuraValuesSuggestionPanel> createState() =>
      _NeuraValuesSuggestionPanelState();
}

class _NeuraValuesSuggestionPanelState
    extends State<NeuraValuesSuggestionPanel> {
  late final suggestions =
      NeuraValuesActionEngine.instance.generateTodaySuggestions(
    maxSuggestions: 4,
  );

  @override
  Widget build(BuildContext context) {
    if (suggestions.isEmpty) return const SizedBox.shrink();

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.lightbulb),
                const SizedBox(width: 8),
                Text(
                  'Today's Value-Linked Suggestions',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
              ],
            ),
            const SizedBox(height: 8),
            ...suggestions.map((s) => _buildSuggestionTile(context, s)),
          ],
        ),
      ),
    );
  }

  Widget _buildSuggestionTile(
    BuildContext context,
    NeuraValueAlignedSuggestion s,
  ) {
    final valueLabel =
        NeuraDefaultValuesLibrary.byId(s.primaryValueId)?.label ?? '';

    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: ListTile(
        contentPadding: EdgeInsets.zero,
        leading: Icon(_iconForType(s.type)),
        title: Text(s.title),
        subtitle: Text(
          s.description + (valueLabel.isNotEmpty ? '\nValue: $valueLabel' : ''),
        ),
        trailing: TextButton(
          child: const Text('Do this'),
          onPressed: () => _handleSuggestionTap(context, s),
        ),
      ),
    );
  }

  IconData _iconForType(NeuraValueAlignedSuggestionType type) {
    switch (type) {
      case NeuraValueAlignedSuggestionType.journal:
        return Icons.edit_note;
      case NeuraValueAlignedSuggestionType.ritual:
        return Icons.spa;
      case NeuraValueAlignedSuggestionType.session:
        return Icons.play_circle;
      case NeuraValueAlignedSuggestionType.goodDeed:
        return Icons.favorite;
      case NeuraValueAlignedSuggestionType.microAction:
        return Icons.flash_on;
    }
  }

  Future<void> _handleSuggestionTap(
    BuildContext context,
    NeuraValueAlignedSuggestion s,
  ) async {
    switch (s.type) {
      case NeuraValueAlignedSuggestionType.journal:
        if (widget.onOpenJournal != null) {
          widget.onOpenJournal!();
        }
        break;
      case NeuraValueAlignedSuggestionType.session:
        if (s.payload != null) {
          await NeuraSessionEngine.instance.startSession(s.payload!);
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Started session: ${s.title}')),
          );
        }
        break;
      case NeuraValueAlignedSuggestionType.ritual:
        if (s.payload != null) {
          await NeuraModuleRegistry.instance.startRitual(s.payload!);
          if (!mounted) return;
          ScaffoldMessenger.of(context).showSnackBar(
            SnackBar(content: Text('Started ritual: ${s.title}')),
          );
        }
        break;
      case NeuraValueAlignedSuggestionType.goodDeed:
        if (widget.onOpenGoodDeeds != null) {
          widget.onOpenGoodDeeds!(s.payload ?? 'general');
        }
        break;
      case NeuraValueAlignedSuggestionType.microAction:
        // For micro-actions we just show a friendly nudge.
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text(
              'Neura can't click this for you, but she's cheering you on.',
            ),
          ),
        );
        break;
    }
  }
}
