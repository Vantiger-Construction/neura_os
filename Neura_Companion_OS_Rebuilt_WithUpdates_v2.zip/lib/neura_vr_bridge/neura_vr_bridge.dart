import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

/// Bridge between Flutter Neura OS and a Unity / VR client.
///
/// This is a lightweight MethodChannel wrapper so you can:
///   - Send timeline events / emotion states into Unity.
///   - Receive simple callbacks from the VR side.
class NeuraVrBridge extends ChangeNotifier {
  static const MethodChannel _channel =
      MethodChannel('neura_vr_bridge');

  bool _connected = false;
  String? _lastMessage;

  bool get isConnected => _connected;
  String? get lastMessage => _lastMessage;

  Future<void> sendEmotionState({
    required String state,
    double intensity = 1.0,
  }) async {
    try {
      await _channel.invokeMethod<void>(
        'sendEmotionState',
        {
          'state': state,
          'intensity': intensity,
        },
      );
    } catch (e) {
      debugPrint('[NeuraVrBridge] sendEmotionState failed: $e');
    }
  }

  Future<void> sendTimelineEvent({
    required String type,
    required Map<String, dynamic> payload,
  }) async {
    try {
      await _channel.invokeMethod<void>(
        'sendTimelineEvent',
        {
          'type': type,
          'payload': payload,
        },
      );
    } catch (e) {
      debugPrint('[NeuraVrBridge] sendTimelineEvent failed: $e');
    }
  }

  /// Call from platform side when VR client connects.
  @pragma('vm:entry-point')
  void markConnected() {
    _connected = true;
    notifyListeners();
  }

  /// Call from platform side when a message arrives from VR.
  @pragma('vm:entry-point')
  void onVrMessage(String message) {
    _lastMessage = message;
    notifyListeners();
  }
}
