# Neura Companion – OS Full-Stack Kit

This kit merges all the Neura OS Shell modules we built plus new
facades for voice, dreams, analytics, VR bridge, billing, and
simple build scripts.

------------------------------------------------------------------
What's included
------------------------------------------------------------------

Under `lib/`:

  - `neura_shell/`             – OS state, rooms, screens.
  - `neura_clinical/`          – Clinical Bay engine + UI.
  - `neura_legacy/`            – Legacy Hall engine + UI.
  - `neura_brain/neura_self_heal_service.dart`
                               – Self-heal + Dimensional Sync.
  - `neura_diagnostics/`       – Diagnostics screen.
  - `neura_mirror/`            – Mirror Mode engine + screen (stub).
  - `neura_smart_home/`        – Smart Home bridge + debug screen (stub).
  - `neura_wearable/`          – Wearable HRV bridge + debug screen (stub).
  - `neura_voice/`             – Voice facade (TTS/STT) + debug screen.
  - `neura_dreams/`            – Dream engine + journal + "show" screens.
  - `neura_analytics/`         – Analytics dashboard stub screen.
  - `neura_vr_bridge/`         – MethodChannel bridge for Unity/VR.
  - `neura_billing/`           – Billing facade service.

Under `scripts/`:

  - `build_android.bat`
  - `build_web.bat`
  - `build_windows.bat`
  - `build_linux.sh`
  - `build_macos.sh`

At root:

  - `pubspec_neura_os_additions.yaml` – copy/paste dependency hints.

------------------------------------------------------------------
How to merge into your main repo
------------------------------------------------------------------

1. **Copy `lib/` contents into your Flutter project's `lib/`**

     - If you already have some of these folders, merge carefully
       and prefer the newer `neura_shell_state.dart` /
       `neura_self_heal_service.dart` from this kit.

2. **Update `pubspec.yaml`**

     - Add dependencies from `pubspec_neura_os_additions.yaml`
       as needed: shared_preferences, fl_chart, flutter_tts,
       speech_to_text, in_app_purchase, etc.

     - Run:

         flutter pub get

3. **Wire routes (example)**

     ```dart
     routes: {
       '/neura/os': (context) => const NeuraOsShellScreen(),
       '/neura/settings': (context) => const NeuraOsSettingsScreen(),
       '/neura/diagnostics': (context) => const NeuraDiagnosticsScreen(),
       '/neura/mirror': (context) => const NeuraMirrorModeScreen(),
       '/neura/smart-home-debug': (context) =>
           const NeuraSmartHomeDebugScreen(),
       '/neura/wearable-hrv-debug': (context) =>
           const NeuraWearableHrvDebugScreen(),
       '/neura/analytics': (context) =>
           const NeuraAnalyticsDashboardScreen(),
       // Dream screens expect you to pass an engine instance:
       // e.g. via a builder or DI.
     }
     ```

4. **Hook into `main.dart`**

     Simplest test mode:

     ```dart
     import 'neura_shell/neura_os_entry.dart';

     void main() {
       runApp(const NeuraOsEntry());
     }
     ```

     Or embed `NeuraOsShellScreen` as one tab inside your existing
     app shell and initialise the extra engines (dreams, voice,
     billing) in your own DI layer.

5. **Platform integrations ("replace stubs")**

     - Mirror Mode:
       * Replace the camera placeholder in
         `NeuraMirrorModeScreen` with a real camera widget.
       * Wire detection results into `NeuraMirrorEngine.recordSession(...)`.

     - Smart Home:
       * Implement calls inside `NeuraSmartHomeBridge` to a real
         vendor (Hue, Home Assistant, etc.) instead of the random
         success/fail simulation.

     - Wearables:
       * On your platform layer, whenever you receive RR-interval
         data (ms) from a device, call:
             `wearableBridge.onRawRrIntervals(rrMs);`

     - Voice:
       * Implement `NeuraVoiceBackend` using flutter_tts + speech_to_text,
         then inject into `NeuraVoiceService`.

     - Billing:
       * Implement `NeuraBillingBackend` using in_app_purchase or
         your preferred billing solution.

     - VR:
       * On Android/iOS/desktop, hook the `MethodChannel('neura_vr_bridge')`
         to your Unity/VR player and respond to the methods defined
         in `NeuraVrBridge`.

6. **Build & Installers**

     - Use the scripts under `scripts/` as a starting point:
         - Windows: `scripts\build_windows.bat`
         - Android: `scripts\build_android.bat`
         - Web: `scripts\build_web.bat`
         - Linux/macOS: shell scripts.

------------------------------------------------------------------
QA / bug pass checklist
------------------------------------------------------------------

  - [ ] All routes load without exceptions.
  - [ ] Neura OS Shell switches rooms without crash.
  - [ ] OS Settings toggles Safe Mode + startup room correctly.
  - [ ] Diagnostics screen shows errors and Dimensional Sync gag.
  - [ ] Mirror Mode can record simulated sessions and feed emotion engine.
  - [ ] Smart Home debug page records actions in history.
  - [ ] Wearable HRV debug page shows simulated HR/HRV samples.
  - [ ] Dream Journal can add/edit/delete entries.
  - [ ] Dream Show groups dreams by month.
  - [ ] Voice debug screen can speak and listen using your backend.
  - [ ] Billing service correctly flips premium flags on purchase.
  - [ ] Desktop/mobile/web builds all compile and run.

Once those pass, you have a clean, merged Neura OS + major systems
wired and ready for deeper production hardening.
