# Neura OS Shell Screen Module
(World view + room navigation)

This bundle adds a **single main screen** that acts as the primary
"world view" for your Neura OS:

  - It reads the current room from `NeuraShellState`
  - It shows the correct room widget (Penthouse, Mood Den, etc.)
  - It provides a bottom navigation bar to switch rooms
  - It exposes a settings button that opens the Neura OS Settings screen

It assumes you already have:

  - `NeuraShellState`
  - `NeuraShellScope`
  - Room widgets such as:
      * `PenthouseRoom`
      * `MoodDenRoom`
      * `DreamBayRoom`
      * `ReflectionBayRoom`
      * `ClinicalBayRoom`
      * `LegacyHallRoom`
  - `NeuraRoomId` enum with matching values:
      * `penthouse`
      * `mood_den`
      * `dream_bay`
      * `reflection_bay`
      * `clinical_bay`
      * `legacy_hall`

----------------------------------------------------------------------
Files
----------------------------------------------------------------------

- `lib/neura_shell/screens/neura_os_shell_screen.dart`

    * `NeuraOsShellScreen` (StatelessWidget)

      Behaviour:

      - Reads the shell:

          ```dart
          final shell = NeuraShellScope.of(context);
          ```

      - Listens to changes using `AnimatedBuilder`:

          ```dart
          AnimatedBuilder(
            animation: shell,
            builder: (context, _) { ... },
          )
          ```

      - While `shell.isLoading`:
          * Shows a `CircularProgressIndicator`.

      - Once ready:
          * `room = shell.currentRoom`
          * `rooms = NeuraRoomId.values`
          * `currentIndex = rooms.indexOf(room)`

      - `Scaffold`:

          * `AppBar`:
              - Title: "Neura OS"
              - Settings icon:
                  ```dart
                  Navigator.of(context).pushNamed('/neura/settings');
                  ```

          * `body`:
              - `_buildRoomBody(room)` chooses the correct room widget:

                  ```dart
                  switch (room) {
                    case NeuraRoomId.penthouse:
                      return const PenthouseRoom();
                    case NeuraRoomId.mood_den:
                      return const MoodDenRoom();
                    case NeuraRoomId.dream_bay:
                      return const DreamBayRoom();
                    case NeuraRoomId.reflection_bay:
                      return const ReflectionBayRoom();
                    case NeuraRoomId.clinical_bay:
                      return const ClinicalBayRoom();
                    case NeuraRoomId.legacy_hall:
                      return const LegacyHallRoom();
                  }
                  ```

          * `bottomNavigationBar`:
              - Items built from `NeuraRoomId.values`
              - Label: derived from `room.name` (underscores → spaces, capitalised)
              - Icon: derived from the room name:
                  * "penthouse"  → `Icons.home_rounded`
                  * "mood"       → `Icons.auto_awesome_rounded`
                  * "dream"      → `Icons.bedtime_rounded`
                  * "reflection" → `Icons.self_improvement_rounded`
                  * "clinical"   → `Icons.health_and_safety_rounded`
                  * "legacy/hall"→ `Icons.museum_rounded`
                  * fallback     → `Icons.circle_rounded`

              - On tap:
                  ```dart
                  final target = rooms[index];
                  shell.switchRoom(target);
                  ```

----------------------------------------------------------------------
How to merge this bundle
----------------------------------------------------------------------

1. Copy into your Flutter repo:

     - `lib/neura_shell/screens/neura_os_shell_screen.dart` → into `lib/`

2. Make sure the referenced rooms & enum exist:

     - Check you have:
         * `lib/neura_shell/rooms/penthouse_room.dart`
         * `lib/neura_shell/rooms/mood_den_room.dart`
         * `lib/neura_shell/rooms/dream_bay_room.dart`
         * `lib/neura_shell/rooms/reflection_bay_room.dart`
         * `lib/neura_shell/rooms/clinical_bay_room.dart`
         * `lib/neura_shell/rooms/legacy_hall_room.dart`
         * `lib/neura_shell/models/neura_room.dart` defining:
             - `enum NeuraRoomId { penthouse, mood_den, dream_bay, reflection_bay, clinical_bay, legacy_hall }`

     - If your naming is different, adjust the imports and switch-case accordingly.

3. Use this as your main OS view:

     For example, inside your existing app's navigation:

     ```dart
     // Somewhere in your routing:
     routes: {
       '/neura/os': (context) => const NeuraOsShellScreen(),
       '/neura/settings': (context) => const NeuraOsSettingsScreen(),
       '/neura/diagnostics': (context) => const NeuraDiagnosticsScreen(),
     }
     ```

     Or as a tab in a wider app:

     ```dart
     class MainApp extends StatelessWidget {
       @override
       Widget build(BuildContext context) {
         return NeuraShellScope(
           state: NeuraShellState(),
           child: MaterialApp(
             home: const NeuraOsShellScreen(),
           ),
         );
       }
     }
     ```

     (The exact `NeuraShellScope` constructor may vary – use the one you
     already have in your repo.)

4. Build & run:

     ```bash
     flutter pub get
     flutter run
     ```

     You should now see:
       - A top app bar with a settings button
       - The current room content
       - A bottom navigation bar to move between your rooms

----------------------------------------------------------------------
What this adds to your OS

Before this, you had powerful individual rooms and engines:

  - Mood / Rituals
  - Dream Visualiser
  - Reflection Bay
  - Clinical Bay
  - Legacy Hall
  - Diagnostics & Self-Heal
  - Neura OS Settings

This module glues them into a **single navigable shell**:

  - One screen that *feels* like the Neura world.
  - A consistent bottom bar for moving between major rooms.
  - A predictable entry point (`/neura/os`) you can route to from your app.

From here, you can theme it, add side rails on desktop, tuck Neura's avatar
into a corner, or wire in gesture navigation – but the world is now one piece.
