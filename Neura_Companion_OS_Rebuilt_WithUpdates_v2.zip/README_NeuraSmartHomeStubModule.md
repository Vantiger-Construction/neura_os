# Neura Smart Home Stub Module
(Lights / music / scene actions – no real devices yet)

This bundle gives your Neura OS a **smart home bridge stub** that:
  - Stores a history of requested actions (lights, music, scenes)
  - Simulates success/failure locally
  - Exposes a simple, vendor-agnostic API Neura can call from rituals
  - Provides a debug screen to poke it by hand

It does **not** talk to real devices yet. The idea is:
  - Neura code uses this clean, stable API.
  - Later, you swap the internals of `NeuraSmartHomeBridge` to talk
    to Hue, Home Assistant, Google, etc., without touching Neura OS.

----------------------------------------------------------------------
Files
----------------------------------------------------------------------

- `lib/neura_smart_home/neura_smart_home_models.dart`
    * `NeuraSmartHomeCapabilityType` enum:
        - `light`, `music`, `scene`
    * `NeuraSmartHomeAction`
        - `id`
        - `createdAt`
        - `type` (capability type)
        - `target` (e.g. "living_room", "bedroom", "calm_ritual")
        - `parameters` (Map<String, dynamic> – brightness, color, etc.)
        - `status` (pending/success/failed)
        - `errorMessage`

- `lib/neura_smart_home/neura_smart_home_bridge.dart`
    * `NeuraSmartHomeBridge extends ChangeNotifier`:
        - Persists history in SharedPreferences key:
              - `neura_smart_home_history_v1`
        - API:
              ```dart
              Future<void> ensureLoaded();
              List<NeuraSmartHomeAction> get history;

              Future<NeuraSmartHomeAction> setRoomLights({
                required String room,
                required bool on,
                double? brightness,
              });

              Future<NeuraSmartHomeAction> playMusicScene({
                required String sceneId,
                double? volume,
              });

              Future<NeuraSmartHomeAction> playAtmosphereScene({
                required String sceneId,
                Map<String, dynamic>? params,
              });
              ```
        - Currently simulates a 95% success rate and marks the action
          as success/failed after a small delay.

- `lib/neura_smart_home/screens/neura_smart_home_debug_screen.dart`
    * `NeuraSmartHomeDebugScreen` (StatefulWidget)
        - Creates its own `NeuraSmartHomeBridge` and calls `ensureLoaded()`.
        - UI:
            - Text explaining this is a stub, no real devices.
            - Two switches:
                  * "Living room lights"
                  * "Bedroom lights"
              -> call `setRoomLights(...)` with brightness.
            - Button "Play 'Calm ritual' scene" → calls `playAtmosphereScene(...)`.
            - Snackbars show simulated success/failure.
            - "Recent actions" list showing:
                  * type, target, status, timestamp.

----------------------------------------------------------------------
How to merge this bundle
----------------------------------------------------------------------

1. Copy into your Flutter repo:

     - `lib/neura_smart_home/` → into `lib/`

2. Ensure `shared_preferences` is in `pubspec.yaml`:

     ```yaml
     dependencies:
       flutter:
         sdk: flutter
       shared_preferences: ^2.2.0
     ```

3. Wire a route to the debug screen:

     ```dart
     import 'package:your_app/neura_smart_home/screens/neura_smart_home_debug_screen.dart';

     MaterialApp(
       routes: {
         '/neura/smart-home-debug': (context) =>
             const NeuraSmartHomeDebugScreen(),
       },
     );
     ```

4. Build & run:

     ```bash
     flutter pub get
     flutter run
     ```

     - Navigate to `/neura/smart-home-debug` via a button or dev menu.
     - Toggle lights, trigger the "Calm ritual" scene.
     - Confirm actions show up in the history list.

----------------------------------------------------------------------
How Neura OS can use this

From any ritual / mood / scene code, you can now do something like:

```dart
final bridge = NeuraSmartHomeBridge(); // or better: injected singleton
await bridge.setRoomLights(room: 'living_room', on: true, brightness: 0.7);
await bridge.playMusicScene(sceneId: 'focus_ambient', volume: 0.4);
```

For a more integrated setup, you may later:

  - Add a `smartHomeBridge` field to `NeuraShellState` and construct
    it there so every module can grab it via:
        `NeuraShellScope.of(context).smartHomeBridge`
  - Or wire it via your own dependency injection container.

The point: Neura now has a clean way to *ask* for lights/music/atmosphere
changes, and you can decide how deep the real-world integration goes. 
