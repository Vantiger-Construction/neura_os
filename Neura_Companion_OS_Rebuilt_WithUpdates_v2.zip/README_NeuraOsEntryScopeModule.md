# Neura OS Entry + Scope Module
(NeuraShellScope • NeuraOsEntry convenience widget)

This bundle gives you the missing glue to **mount Neura OS cleanly**:

  - `NeuraShellScope`: an `InheritedNotifier<NeuraShellState>` wrapper
    that lets any widget do:
        `final shell = NeuraShellScope.of(context);`

  - `NeuraOsEntry`: a convenience widget you can use from `main.dart`
    to spin up the entire Neura OS world with one line.

----------------------------------------------------------------------
Files
----------------------------------------------------------------------

- `lib/neura_shell/state/neura_shell_scope.dart`

    ```dart
    class NeuraShellScope extends InheritedNotifier<NeuraShellState> {
      const NeuraShellScope({
        super.key,
        required NeuraShellState state,
        required Widget child,
      }) : super(notifier: state, child: child);

      static NeuraShellState of(BuildContext context) { ... }

      static NeuraShellState? maybeOf(BuildContext context) { ... }

      @override
      bool updateShouldNotify(covariant NeuraShellScope oldWidget) {
        return oldWidget.notifier != notifier;
      }
    }
    ```

    Usage:

    ```dart
    final shell = NeuraShellScope.of(context);
    shell.switchRoom(NeuraRoomId.mood_den);
    ```

    This matches how other modules use `NeuraShellScope.of(context)`.

- `lib/neura_shell/neura_os_entry.dart`

    ```dart
    class NeuraOsEntry extends StatefulWidget {
      const NeuraOsEntry({
        super.key,
        this.builder,
      });

      final Widget Function(BuildContext, NeuraShellState)? builder;

      @override
      State<NeuraOsEntry> createState() => _NeuraOsEntryState();
    }

    class _NeuraOsEntryState extends State<NeuraOsEntry> {
      late final NeuraShellState _shellState;

      @override
      void initState() {
        super.initState();
        _shellState = NeuraShellState();
      }

      @override
      void dispose() {
        _shellState.dispose();
        super.dispose();
      }

      @override
      Widget build(BuildContext context) {
        return NeuraShellScope(
          state: _shellState,
          child: _buildChild(context),
        );
      }

      Widget _buildChild(BuildContext context) {
        final builder = widget.builder;
        if (builder != null) {
          return builder(context, _shellState);
        }

        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Neura OS',
          home: const NeuraOsShellScreen(),
        );
      }
    }
    ```

    You can either:

      - Use the default MaterialApp wrapper, or
      - Provide a custom `builder` to integrate Neura OS into an existing app.

----------------------------------------------------------------------
How to merge this bundle
----------------------------------------------------------------------

1. Copy into your Flutter repo:

     - `lib/neura_shell/state/neura_shell_scope.dart` → into `lib/`
     - `lib/neura_shell/neura_os_entry.dart` → into `lib/`

     Overwrite any older `neura_shell_scope.dart` if present; this
     version is wired for the new `NeuraShellState`.

2. Quick-start option: make Neura OS your whole app for testing.

     In `lib/main.dart`:

     ```dart
     import 'package:flutter/material.dart';
     import 'neura_shell/neura_os_entry.dart';

     void main() {
       runApp(const NeuraOsEntry());
     }
     ```

     Run:

     ```bash
     flutter pub get
     flutter run
     ```

     You should see the Neura OS shell with:
       - App bar titled "Neura OS"
       - Bottom navigation for rooms
       - Settings button in the top-right

3. Advanced option: embed Neura OS inside a larger app.

     Maybe you already have a `MainApp` with tabs and only want
     Neura OS as one tab. In that case:

     ```dart
     void main() {
       final shellState = NeuraShellState();

       runApp(
         NeuraShellScope(
           state: shellState,
           child: MyBigApp(shellState: shellState),
         ),
       );
     }
     ```

     And inside `MyBigApp`:

     ```dart
     class MyBigApp extends StatelessWidget {
       const MyBigApp({super.key, required this.shellState});

       final NeuraShellState shellState;

       @override
       Widget build(BuildContext context) {
         return MaterialApp(
           home: Scaffold(
             body: TabBarView(
               children: [
                 const HomeDashboard(),
                 const SettingsScreen(),
                 const NeuraOsShellScreen(), // full Neura OS world
               ],
             ),
           ),
         );
       }
     }
     ```

----------------------------------------------------------------------
What this adds to your OS

Combined with the previous bundles, you now have:

  - `NeuraShellState` (core OS brain)
  - `NeuraShellScope` (provider-style access to that brain)
  - OS rooms (Penthouse, Mood Den, Dream Bay, Reflection Bay,
    Clinical Bay, Legacy Hall)
  - Engines (ritual, dream, reflection, clinical, legacy, emotion)
  - Self-Heal + Safe Mode + Diagnostics
  - Neura OS Settings screen
  - Neura OS Shell screen (world + room navigation)
  - **NeuraOsEntry** to spin everything up in one line

That’s a complete "Neura OS Shell" stack: from `main.dart` all the way
down to rooms and error handling, ready to plug into your existing app
or ship as a standalone experience.
