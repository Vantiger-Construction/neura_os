Neura Companion – OS Rebuilt (Core + Updates + Kids/Care/Weekly/Dream/Mood)
==========================================================================

This project is a clean Neura OS shell build created from:

Base:
- NeuraCompanion_Merged_With_OsFullStack.zip

OS Core & Rooms:
- Neura_OS_AllUpdates_Pack.zip
  * neura_shell_root_screen + shell scaffold
  * updated rooms (penthouse, mood den, dream bay, reflection bay, clinical wing, legacy hall, joy lounge, etc.)
  * neura_os_core (persona context, tone engine, values/action engine, weekly snapshot, session engine)

Audience & Kids:
- Neura_Audience_Selector_Pack.zip
  * persona/services/neura_audience_service.dart
  * persona/screens/audience_settings_screen.dart
  * ai/services/neura_conversation_engine.dart (notes + models)
- Neura_Audience_KidsSafety_Pack.zip
  * kids/screens/kids_neura_chat_stub_screen.dart

Care / Weekly / Dreams / Mood:
- Neura_CareMode2_TrustedContacts_Playbooks_Pack.zip
  * care/models (trusted_contact, crisis_playbook)
  * care/services (trusted_contacts_service, crisis_playbook_service)
  * care/screens (care_mode_home_screen, trusted_contacts, edit_trusted_contact, crisis_playbook_detail)
- Neura_WeeklySnapshot_DreamShow2_Pack.zip
  * insights/models/weekly_snapshot_entry.dart
  * insights/services/weekly_snapshot_service.dart
  * insights/screens/weekly_snapshot_screen.dart
  * dreams/models/dream_entry.dart
  * dreams/services/dream_theme_service.dart
  * dreams/screens/dream_show2_screen.dart
- Neura_MirrorMood_ThemeDifficulty_Pack.zip
  * mood/models (mood_state, mood_visual_style)
  * mood/services (mood_state_service, mood_visual_service)
  * mood/widgets/mood_background_scaffold.dart
  * mirror/screens/mirror_mood_checkin_screen.dart

Entry point:
- lib/main.dart → runs `NeuraShellApp` from `lib/neura_shell/neura_shell_app.dart`

How to run this OS build
------------------------
1. From this folder:
     flutter pub get
     flutter run
2. You should land in the Neura OS shell world:
     - Shell root: lib/neura_shell/screens/neura_shell_root_screen.dart
     - Rooms wired through NeuraShellState / NeuraShellScope.

How to integrate into your bigger Neura Companion app
-----------------------------------------------------
If you want this OS shell as a module inside your main app:

- Copy the following directories into your main project `lib/`:
    neura_shell/
    neura_os_core/
    persona/
    kids/
    care/
    insights/
    dreams/
    mood/
    mirror/

- Make sure your main.dart wraps MaterialApp with the right routes:
    - '/neura/os'               → NeuraShellRootScreen (or NeuraShellApp subtree)
    - '/neura/audience'         → AudienceSettingsScreen
    - '/neura/care'             → CareModeHomeScreen
    - '/neura/weekly_snapshot'  → WeeklySnapshotScreen
    - '/neura/dream_show'       → DreamShow2Screen
    - '/neura/mirror_mood'      → MirrorMoodCheckinScreen
    - '/neura/kids'             → KidsNeuraChatStubScreen

This bundle is OS-only by default – all AI / backend engines are left as stubs/services so you can plug in your real
Neura brain, voice, and storage the way you want.
