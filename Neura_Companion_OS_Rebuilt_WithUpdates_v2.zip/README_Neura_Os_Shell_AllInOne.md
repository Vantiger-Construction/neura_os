# Neura OS Shell – All-In-One Pack

This bundle merges all Neura OS Shell modules into a single drop-in pack:

Included modules:
  - Clinical Bay Module
  - Legacy Hall Module
  - Neura OS Settings Module
  - Neura OS Shell Screen Module
  - Neura OS Entry & Scope Module

Directory layout (relative to your Flutter `lib/` folder):
  - `neura_clinical/`         – Clinical check-ins engine + UI
  - `neura_legacy/`           – Legacy Hall engine + UI
  - `neura_shell/state/`
      * `neura_shell_state.dart`  – Core NeuraShellState with:
          - avatarController, voiceService, persona, emotionEngine
          - ritualEngine, dreamEngine, reflectionEngine
          - clinicalEngine, legacyEngine
          - selfHeal (Safe Mode + Dimensional Sync)
      * `neura_shell_scope.dart`  – Inherited wrapper (NeuraShellScope)
  - `neura_shell/rooms/`
      * `clinical_bay_room.dart`  – Clinical Bay room
      * `legacy_hall_room.dart`   – Legacy Hall room
      * (Assumes you already have penthouse/mood/dream/reflection rooms)
  - `neura_shell/screens/`
      * `neura_os_settings_screen.dart` – Neura OS Settings
      * `neura_os_shell_screen.dart`    – World view + room navigation
  - `neura_shell/neura_os_entry.dart`   – NeuraOsEntry boot widget

How to use:
  1. Copy the contents of `lib/` from this pack into your Flutter project's `lib/` folder.
     - Allow it to overwrite existing `neura_shell_state.dart` and `neura_shell_scope.dart`
       with these updated versions.
  2. Make sure `shared_preferences` is in your `pubspec.yaml`.
  3. Point `main.dart` at Neura OS for testing, e.g.:
       import 'neura_shell/neura_os_entry.dart';
       void main() {
         runApp(const NeuraOsEntry());
       }
  4. Run:
       flutter pub get
       flutter run

This gives you a complete Neura OS Shell, ready to merge into your main app.
