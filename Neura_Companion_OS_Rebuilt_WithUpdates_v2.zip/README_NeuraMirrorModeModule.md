# Neura Mirror Mode Module
(Emotion overlay stub wired into the emotion engine)

This bundle adds a **Mirror Mode** system to your Neura OS that:

  - Defines simple models for detected emotions and sessions.
  - Adds a `NeuraMirrorEngine` that:
      * stores sessions locally in SharedPreferences
      * nudges `NeuraEmotionEngine` based on the latest snapshot
  - Provides a placeholder **Mirror Mode screen** that:
      * Shows a "camera preview" placeholder panel
      * Lets you simulate emotion reads with chips + slider
      * Writes sessions to the engine and forwards into emotion engine
      * Lists past Mirror sessions

It does **not** include real camera / face detection – you plug that
in later and simply call `recordSession(...)` with your results.

----------------------------------------------------------------------
Files
----------------------------------------------------------------------

- `lib/neura_mirror/neura_mirror_models.dart`
    * `NeuraMirrorEmotionSnapshot`:
        - `timestamp`
        - `primaryLabel` (e.g. "happy", "sad", etc.)
        - `confidence` (double 0.0–1.0)
        - `notes` (string)
    * `NeuraMirrorSessionSummary`:
        - `id`
        - `startedAt`
        - `endedAt`
        - `snapshots` (list of `NeuraMirrorEmotionSnapshot`)
        - `latestSnapshot` getter

- `lib/neura_mirror/neura_mirror_engine.dart`
    * `NeuraMirrorEngine extends ChangeNotifier`:
        - Depends on `NeuraEmotionEngine` (imported from
          `../neura_brain/neura_emotion_engine.dart`)
        - Persists sessions in SharedPreferences key:
              - `neura_mirror_sessions_v1`
        - API:
            - `Future<void> ensureLoaded()`
            - `Future<void> recordSession(NeuraMirrorSessionSummary)`
            - `NeuraMirrorSessionSummary? latestSession()`
            - `List<NeuraMirrorSessionSummary> get sessions`
    * After saving a session, it calls:
          `emotionEngine.applyMirrorObservation(...)`
      with a crude valence delta based on the primary label & confidence.

      You can refine this mapping inside `NeuraEmotionEngine` later.

- `lib/neura_mirror/screens/neura_mirror_mode_screen.dart`
    * `NeuraMirrorModeScreen` (StatefulWidget)
        - On first build:
            * Grabs `NeuraShellScope.of(context)`
            * Creates `NeuraMirrorEngine(emotionEngine: shell.emotionEngine)`
            * Calls `ensureLoaded()`
        - UI:
            * Big gradient panel with camera icon and text:
                  "Camera placeholder – plug real camera here later."
            * Card with debug controls:
                  - emotion chips: happy / calm / neutral / tired / sad / stressed
                  - slider for confidence 0.1–1.0
                  - button "Record snapshot → session":
                      * Creates a new session with one snapshot
                      * Calls `_mirrorEngine.recordSession(session)`
                      * Shows SnackBar confirming
            * Summary bar for latest session
            * List of all sessions

----------------------------------------------------------------------
How to merge this bundle
----------------------------------------------------------------------

1. Copy into your Flutter repo:

     - `lib/neura_mirror/` → into `lib/`

2. Ensure `shared_preferences` is already in `pubspec.yaml`
   (required by other modules too).

3. Wire a route or button to open Mirror Mode, for example:

     ```dart
     // In your routes:
     routes: {
       '/neura/mirror': (context) => const NeuraMirrorModeScreen(),
     };
     ```

     From Mood Den (or anywhere):

     ```dart
     TextButton.icon(
       icon: const Icon(Icons.face_retouching_natural_rounded),
       label: const Text('Open Mirror Mode'),
       onPressed: () {
         Navigator.of(context).pushNamed('/neura/mirror');
       },
     );
     ```

4. Build & run:

     ```bash
     flutter pub get
     flutter run
     ```

     - Go to your trigger (e.g. from Mood Den) → open Mirror Mode.
     - Use the chips + slider to simulate different emotions.
     - Confirm:
         * Sessions appear in the list.
         * Emotion engine receives `applyMirrorObservation(...)` calls.

----------------------------------------------------------------------
How to plug in a real detector later (outline)

When you're ready to integrate real camera / face / voice analysis:

  - Replace the camera placeholder container with a real camera widget
    from a plugin (e.g. camera, MLKit, etc.).
  - On each detection:
      * Build a `NeuraMirrorEmotionSnapshot` with the label + confidence.
      * Either accumulate snapshots for a session, or stream them into
        short sessions depending on design.
      * Call `NeuraMirrorEngine.recordSession(...)` when you want to
        commit a session and feed the emotion engine.

This module keeps the wiring and storage clean so you can focus on
the actual ML later.
