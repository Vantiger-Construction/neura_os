@echo off
REM Build web version for Neura Companion
echo Building Flutter web release...
flutter pub get
flutter build web --release
echo.
echo Output should be under build\web
pause
