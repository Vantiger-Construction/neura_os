@echo off
REM Build Android APK for Neura Companion
echo Building Android release APK...
flutter pub get
flutter build apk --release
echo.
echo Output should be under build\app\outputs\flutter-apk\app-release.apk
pause
