@echo off
REM Build Windows desktop version for Neura Companion
echo Building Windows desktop release...
flutter pub get
flutter build windows --release
echo.
echo Output should be under build\windows\runner\Release
pause
