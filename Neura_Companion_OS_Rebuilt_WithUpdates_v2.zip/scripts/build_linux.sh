#!/usr/bin/env bash
set -e
echo "Building Linux desktop release..."
flutter pub get
flutter build linux --release
echo
echo "Output should be under build/linux/x64/release/bundle"
