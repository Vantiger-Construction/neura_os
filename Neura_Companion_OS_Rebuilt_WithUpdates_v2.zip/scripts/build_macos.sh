#!/usr/bin/env bash
set -e
echo "Building macOS desktop release..."
flutter pub get
flutter build macos --release
echo
echo "Output should be under build/macos/Build/Products/Release"
