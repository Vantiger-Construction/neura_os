# Neura Diagnostics & Self-Heal Starter
(Safe Mode • Error Logs • Dimensional Sync gag)

This bundle adds a **Diagnostics & Self-Heal** system to your Neura OS:
  - Central self-heal service (already referenced by NeuraShellState)
  - A diagnostics screen that:
      * Shows Safe Mode + last Dimensional Sync time
      * Runs a quick health check
      * Runs the "Dimensional Sync" multiverse auto-fix gag
      * Lists recent internal errors with severity icons

It is focused on **technical health of the app**, *not* user medical/health
data. It just helps you debug and gives Neura a playful way to react when
things break.

----------------------------------------------------------------------
Files
----------------------------------------------------------------------

- `lib/neura_brain/neura_self_heal_service.dart`
    * `NeuraErrorRecord`
        - timestamp
        - source
        - message
        - stack (optional)
        - severity (`info | warning | error`)
    * `NeuraSelfHealResult`
        - success
        - headline
        - detail
        - usedDimensionalSync
    * `NeuraSelfHealService` (ChangeNotifier)
        - Holds:
            - `_recentErrors` (max 50)
            - `_safeMode` bool
            - `_lastDimensionalSyncAt`
            - `_lastResult`
        - API:
            - `void reportError({ source, message, severity, stack })`
            - `void clearErrors()`
            - `void setSafeMode(bool value)`
            - `Future<NeuraSelfHealResult> runHealthCheck()`
            - `Future<NeuraSelfHealResult> runDimensionalSync()`

        - `runDimensionalSync()`:
            - Enables Safe Mode
            - Updates `_lastDimensionalSyncAt`
            - Returns a playful line like:
                - "Your multiversal twin already debugged this. You’re welcome."

- `lib/neura_diagnostics/neura_diagnostics_screen.dart`
    * `NeuraDiagnosticsScreen` (Scaffold)
        - Uses `NeuraShellScope.of(context).selfHeal`
        - Shows:
            - Safe Mode card:
                * Toggle switch for Safe Mode
                * Explanation text
                * Last Dimensional Sync time
            - Buttons:
                * "Run quick health check" → `selfHeal.runHealthCheck()`
                * "Dimensional Sync" → `selfHeal.runDimensionalSync()`
            - Optional banner for last result
            - Recent internal logs:
                * severity icon + color
                * source
                * truncated message
                * timestamp
                * "Clear" button to wipe logs

----------------------------------------------------------------------
How to merge this bundle
----------------------------------------------------------------------

1. Copy into your Flutter repo:

     - `lib/neura_brain/neura_self_heal_service.dart`
         (this upgrades the existing stub used by `NeuraShellState`)

     - `lib/neura_diagnostics/` → into `lib/`

2. No new dependencies are required; it uses only Flutter + your existing
   `NeuraShellScope` / `NeuraShellState`.

3. To show the diagnostics UI, wire it anywhere in your app, for example:

     ```dart
     // From a Settings icon, or from Penthouse room:
     IconButton(
       icon: const Icon(Icons.developer_board_rounded),
       onPressed: () {
         Navigator.of(context).push(
           MaterialPageRoute(
             builder: (_) => const NeuraDiagnosticsScreen(),
           ),
         );
       },
     );
     ```

4. To start recording errors, call:

     ```dart
     final shell = NeuraShellScope.of(context);
     try {
       // risky code
     } catch (e, st) {
       shell.selfHeal.reportError(
         source: 'MyFeature.doThing',
         message: e.toString(),
         severity: NeuraErrorSeverity.error,
         stack: st,
       );
     }
     ```

----------------------------------------------------------------------
What this gives your OS

With this bundle merged, your Neura OS now has:

  - A **centralized error brain** (`NeuraSelfHealService`)
  - A dedicated **Diagnostics & Self-Heal screen**
  - Playful **Dimensional Sync** UX for when things break
  - **Safe Mode** toggle so you can conditionally skip heavier features
    when something is wrong.

This is the "OS health" layer that sits underneath all rooms (Dream Bay,
Mood Den, Reflection Bay, etc.) so when you hit weird bugs in the future,
Neura can:
  - Log them for you
  - Offer a gag + Safe Mode instead of just crashing
  - Give you a quick snapshot of what's been going wrong lately.
