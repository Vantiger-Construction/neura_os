# Neura Wearable HRV Stub Module
(BLE HRV adapter with RR-interval parsing – no real device yet)

This bundle adds a **wearable HRV bridge** to Neura OS that:

  - Defines a simple HR/HRV sample model.
  - Parses RR-interval arrays into HR, RMSSD, SDNN.
  - Stores recent samples locally in SharedPreferences.
  - Exposes a debug "simulation mode" that generates fake RR data.
  - Provides a debug screen to inspect HRV and test integration.

It does **not** talk to any physical device yet. The idea:

  - Your platform code (Android/iOS/desktop) receives RR-intervals
    from BLE / HealthKit / Health Connect.
  - It calls `onRawRrIntervals(rrMs)` on this bridge.
  - Everything else (storage, metrics, UI) stays the same.

----------------------------------------------------------------------
Files
----------------------------------------------------------------------

- `lib/neura_wearable/neura_wearable_models.dart`
    * `NeuraHrvSample`:
        - `timestamp`
        - `heartRateBpm`
        - `rmssdMs`
        - `sdnnMs`
    * `NeuraWearableStatus` enum:
        - `disconnected`, `connecting`, `connected`, `simulation`

- `lib/neura_wearable/neura_wearable_hrv_bridge.dart`
    * `NeuraWearableHrvBridge extends ChangeNotifier`:
        - Stores samples in SharedPreferences under:
              - `neura_wearable_hrv_samples_v1`
        - Keeps at most 256 recent samples in memory.
        - API:
              ```dart
              Future<void> ensureLoaded();

              List<NeuraHrvSample> get samples;

              NeuraWearableStatus get status;
              String? get deviceName;

              Future<void> onRawRrIntervals(List<int> rrMs);

              void startDebugSimulation();
              void stopDebugSimulation();
              ```
        - `onRawRrIntervals`:
            - Computes HR, RMSSD, SDNN, creates `NeuraHrvSample`.
            - Inserts at the front of `_samples`.
            - Trims list to `_maxStoredSamples`.
            - Saves to SharedPreferences and notifies listeners.
        - `startDebugSimulation`:
            - Sets status to `simulation`, device name to
              `"Simulated HRV device"`.
            - Starts a `Timer.periodic` every 5 seconds.
            - Each tick:
                * Generates a series of fake RR-intervals around 800 ms.
                * Calls `onRawRrIntervals(rr)`.
        - `stopDebugSimulation` cancels the timer and resets status.

- `lib/neura_wearable/screens/neura_wearable_hrv_debug_screen.dart`
    * `NeuraWearableHrvDebugScreen` (StatefulWidget):
        - Creates its own `NeuraWearableHrvBridge` and calls
          `ensureLoaded()`.
        - UI:
            - Explains that this is a stub, not real BLE yet.
            - Shows connection/status row:
                  * label + color per `NeuraWearableStatus`
                  * device name (or "None").
            - Buttons:
                  * "Start simulation" → `startDebugSimulation()`
                  * "Stop simulation" → `stopDebugSimulation()`
            - Latest sample card:
                  * HR (bpm)
                  * RMSSD (ms)
                  * SDNN (ms)
            - List of all samples with timestamp.

----------------------------------------------------------------------
How to merge this bundle
----------------------------------------------------------------------

1. Copy into your Flutter repo:

     - `lib/neura_wearable/` → into `lib/`

2. Make sure `shared_preferences` is in your `pubspec.yaml`:

     ```yaml
     dependencies:
       flutter:
         sdk: flutter
       shared_preferences: ^2.2.0
     ```

3. Wire a route to the debug screen:

     ```dart
     import 'package:your_app/neura_wearable/screens/neura_wearable_hrv_debug_screen.dart';

     MaterialApp(
       routes: {
         '/neura/wearable-hrv-debug': (context) =>
             const NeuraWearableHrvDebugScreen(),
       },
     );
     ```

4. Build & run:

     ```bash
     flutter pub get
     flutter run
     ```

     - Navigate to `/neura/wearable-hrv-debug`.
     - Tap "Start simulation".
     - Watch HR/HRV samples appear.

----------------------------------------------------------------------
How to hook up a real wearable later (outline)

When you integrate a real BLE / HealthKit / Health Connect source:

  - In your platform-aware layer, whenever you receive a window
    of RR-intervals (ms), just call:

        ```dart
        await wearableBridge.onRawRrIntervals(rrMs);
        ```

  - Optionally, add a `wearableBridge` field to `NeuraShellState`
    and construct the bridge there, so any room can reach it via:

        ```dart
        final shell = NeuraShellScope.of(context);
        final wearable = shell.wearableBridge;
        ```

  - From there, you can:
      * Draw HR/HRV charts in Mood Den / Health room.
      * Feed HRV into your emotion engine for "body-aware" reactions.

For now, this stub makes sure all the parsing, storage, and UI glue
are already done and ready for when the real sensors arrive.
