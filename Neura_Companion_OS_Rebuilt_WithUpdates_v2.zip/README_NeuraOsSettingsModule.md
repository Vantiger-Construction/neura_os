# Neura OS Settings Module
(Startup room • Voice greeting • Avatar overlay • Safe Mode)

This bundle adds a central **Neura OS Settings** screen that lets you tweak:

  - Which **room Neura starts in** when the OS loads
  - Whether Neura does a **voice greeting on launch**
  - Whether to **show Neura's avatar everywhere** in your app
  - Whether **Safe Mode** is on (via the self-heal brain)
  - Quick link to the **Diagnostics & Self-Heal** screen

It does **not** change any platform/system settings, everything stays app-local.

----------------------------------------------------------------------
Files
----------------------------------------------------------------------

- `lib/neura_shell/screens/neura_os_settings_screen.dart`
    * `NeuraOsSettingsScreen` (StatefulWidget)
        - Uses `NeuraShellScope.of(context)` to reach:
            * `startupRoom`
            * `currentRoom`
            * `setStartupRoom(NeuraRoomId)`
            * `selfHeal.safeMode`
            * `selfHeal.setSafeMode(bool)`
        - Uses `SharedPreferences` to persist:
            * `neura_pref_voice_greeting_enabled_v1`
            * `neura_pref_avatar_overlay_enabled_v1`

    * UI sections:

        1. Shell & startup
            - Text description
            - "Start Neura in" tile:
                * Shows current startup room label
                * Tapping opens a bottom sheet listing `NeuraRoomId.values`
                * On selection → calls `shell.setStartupRoom(room)`
            - "Voice greeting on launch" switch:
                * Saves to SharedPreferences only
                * You can hook this into your app's startup logic to tell
                  `NeuraVoiceService` whether to greet verbally.
            - "Show Neura on every screen" switch:
                * Saves to SharedPreferences only
                * You can read this flag where you build your global app
                  scaffold, and decide whether to show the Neura avatar
                  overlay on other screens.

        2. Stability & recovery
            - Text description about Safe Mode & error behaviour.
            - Safe Mode switch:
                * Reads `shell.selfHeal.safeMode`
                * Calls `shell.selfHeal.setSafeMode(value)` when toggled.
            - "Open Diagnostics & Self-Heal" list tile:
                * `onTap` → `Navigator.of(context).pushNamed('/neura/diagnostics');`
                * Assumes you register that named route to your
                  `NeuraDiagnosticsScreen`.

----------------------------------------------------------------------
How to merge this bundle
----------------------------------------------------------------------

1. Copy into your Flutter repo:

     - `lib/neura_shell/screens/neura_os_settings_screen.dart` → into `lib/`

2. Ensure `shared_preferences` exists in your `pubspec.yaml`.

3. Wire a route to this screen somewhere central, e.g.:

     ```dart
     // In your MaterialApp routes:
     routes: {
       '/neura/settings': (context) => const NeuraOsSettingsScreen(),
       '/neura/diagnostics': (context) => const NeuraDiagnosticsScreen(),
     }
     ```

     Or push it directly:

     ```dart
     IconButton(
       icon: const Icon(Icons.settings_suggest_rounded),
       onPressed: () {
         Navigator.of(context).push(
           MaterialPageRoute(
             builder: (_) => const NeuraOsSettingsScreen(),
           ),
         );
       },
     );
     ```

4. (Optional) Hook the prefs into your app logic:

     - Voice greeting on launch:

         ```dart
         final prefs = await SharedPreferences.getInstance();
         final greet = prefs.getBool('neura_pref_voice_greeting_enabled_v1') ?? true;

         if (greet) {
           final shell = NeuraShellScope.of(context);
           shell.voice.playGreeting();
         }
         ```

     - Avatar overlay flag:

         ```dart
         final prefs = await SharedPreferences.getInstance();
         final showOverlay = prefs.getBool('neura_pref_avatar_overlay_enabled_v1') ?? true;

         return Scaffold(
           body: Stack(
             children: [
               const MainContent(),
               if (showOverlay)
                 const Positioned(
                   right: 16,
                   bottom: 16,
                   child: NeuraAvatarOverlayWidget(),
                 ),
             ],
           ),
         );
         ```

----------------------------------------------------------------------
What this adds to your OS

Before, your OS had:
  - Rooms (Penthouse, Mood Den, Dream Bay, Reflection Bay, Clinical Bay, Legacy Hall)
  - Engines (ritual, dreams, reflections, clinical, legacy, emotion)
  - Self-heal brain with Safe Mode & Dimensional Sync
  - Companion avatar & voice

With this module, the OS becomes **user-tunable**:

  - Users pick where Neura "wakes up."
  - You have a single central place for future Neura OS toggles.
  - Error-handling (Safe Mode) is visible and controllable.
  - Hooks exist for "Neura everywhere" and "voice greeting" features
    across the rest of the app.

It’s the control panel your Neura OS was missing.
