# Neura Legacy Hall Module
(Stories • Values • Messages to Future You)

This bundle wires up the **Legacy Hall** of your Neura OS.

Purpose:
  - Give users a calm place to write:
      * Stories and memories
      * Life lessons
      * Messages to future self or loved ones
      * Core values
      * Bucket list intentions
  - Keep the framing honest:
      * Not a legal will
      * Not encrypted cloud backup
      * Not a substitute for real conversations

----------------------------------------------------------------------
Files
----------------------------------------------------------------------

- `lib/neura_legacy/neura_legacy_models.dart`
    * `NeuraLegacyCategory`:
        - memory
        - lesson
        - message
        - value
        - bucketList
    * `NeuraLegacyEntry`:
        - id
        - createdAt
        - updatedAt
        - category
        - title
        - body
        - tags (List<String>)

- `lib/neura_legacy/neura_legacy_engine.dart`
    * `NeuraLegacyEngine` (ChangeNotifier)
        - Persists entries in SharedPreferences:
              - key: `neura_legacy_entries_v1`
        - API:
            - `Future<void> ensureLoaded()`
            - `Future<void> upsertEntry(NeuraLegacyEntry entry)`
            - `Future<void> deleteEntry(String id)`
            - `List<NeuraLegacyEntry> entriesByCategory(category)`
            - `NeuraLegacyEntry? latestEntry()`
            - `int get totalCount`
            - `DateTime? get lastUpdatedAt`

- `lib/neura_legacy/widgets/neura_legacy_entry_card.dart`
    * Compact card showing:
        - Category chip
        - Title
        - Updated date
        - 3-line preview
        - Optional tags as chips

- `lib/neura_shell/rooms/legacy_hall_room.dart`
    * Legacy Hall room:
        - Intro: explains purpose & limitations
        - Info notice:
            * Not legal advice, not will, not guaranteed archive.
        - Stats:
            * `N pieces in your Legacy Hall`
            * `Last updated: YYYY-MM-DD` (or "Nothing saved yet")
        - Actions:
            * "New memory / story" (category: memory)
            * "Message to future self" (category: message)
        - List of all entries:
            * Tap → full details dialog with:
                - category
                - created/updated dates
                - body
                - tags
                - buttons: Close / Edit / Delete
            * Long-press → small bottom sheet menu (Edit/Delete)

        - Editor sheet:
            * Choose type (chips for all `NeuraLegacyCategory` values)
            * Title
            * Body
            * Tags as comma-separated string
            * Save / Cancel

- `lib/neura_shell/state/neura_shell_state.dart`
    * UPDATED root shell state adding:
        - `final NeuraLegacyEngine legacyEngine;`
        - `_loadStartupRoomAndEngines()` extended to:
              - `legacyEngine.ensureLoaded()`
      while preserving:
        - ritualEngine
        - dreamEngine
        - reflectionEngine
        - clinicalEngine
        - selfHeal
        - persona
        - avatarController
        - voiceService
        - emotionEngine

----------------------------------------------------------------------
How to merge this bundle
----------------------------------------------------------------------

1. Copy into your Flutter repo:

     - `lib/neura_legacy/` → into `lib/`
     - Overwrite:
         * `lib/neura_shell/rooms/legacy_hall_room.dart`
         * `lib/neura_shell/state/neura_shell_state.dart`

2. Ensure `shared_preferences` is in your `pubspec.yaml`.

3. Build and run:

     ```bash
     flutter pub get
     flutter run
     ```

4. Navigate to **Legacy Hall** in Neura OS:
     - Use the buttons to add:
         * A memory/story
         * A message to future self
     - Check:
         * Stats card updates
         * New entry appears in the list
         * Editing and deleting work as expected

----------------------------------------------------------------------
What this adds to your OS

Together with:
  - Dream Bay
  - Mood Den / Rituals
  - Reflection Bay
  - Clinical Bay
  - Diagnostics & Self-Heal

…Legacy Hall completes the "life story" axis of Neura OS:
  - What happened (Dreams / History)
  - How you felt (Emotion / Clinical / Reflections)
  - What you did (Rituals / Goals)
  - What it means to you long-term (Legacy Hall)

It gives Neura a grounded way to talk about *who you are becoming* without
overstepping into legal/clinical promises.
