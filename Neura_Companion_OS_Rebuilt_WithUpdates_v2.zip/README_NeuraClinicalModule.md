# Neura Clinical Bay Module
(Structured emotional check-ins • Safety notice)

This bundle wires up the **Clinical / Therapist Bay** of your Neura OS.

It is *not* a diagnosis engine and *not* an emergency service. It simply:
  - Lets users record structured emotional check-ins (0–10 intensity, mood)
  - Stores "I might want extra support" flags
  - Helps visualize that history inside the Clinical Bay room

----------------------------------------------------------------------
Files
----------------------------------------------------------------------

- `lib/neura_clinical/neura_clinical_models.dart`
    * `NeuraCheckInType` – `quick` or `guided`
    * `NeuraCheckInEntry`:
        - id
        - timestamp
        - type
        - mood (`NeuraAvatarMood`)
        - intensity (0–10)
        - note (optional)
        - flaggedForSupport (bool)

- `lib/neura_clinical/neura_clinical_engine.dart`
    * `NeuraClinicalEngine` (ChangeNotifier)
        - Persists entries in SharedPreferences: `neura_clinical_checkins_v1`
        - API:
            - `Future<void> ensureLoaded()`
            - `Future<void> addEntry(NeuraCheckInEntry entry)`
            - `List<NeuraCheckInEntry> entriesForDay(DateTime day)`
            - `List<NeuraCheckInEntry> recentEntries([int limit = 50])`
            - `int flaggedSupportCount()`
            - `NeuraCheckInEntry? latestFlaggedSupport()`
            - `Map<NeuraAvatarMood, int> moodHistogram()`

- `lib/neura_clinical/widgets/neura_checkin_card.dart`
    * UI card for a single check-in:
        - Mood icon + label
        - Short preview of note
        - Intensity
        - "Needs support" pill if flagged
        - Time label

- `lib/neura_shell/rooms/clinical_bay_room.dart`
    * REPLACES / CREATES the Clinical Bay room.
    * Behavior:
        - Loads `clinicalEngine.ensureLoaded()` on first build.
        - Shows:
            - Title + intro text
            - **SAFETY NOTICE** card clearly stating:
                * Neura is not an emergency service
                * For immediate danger / suicidal thoughts, call local
                  emergency or crisis hotline instead.
            - Buttons:
                * Quick check-in
                * Guided check-in
            - "Today" summary:
                * How many check-ins today
                * How many recent entries were flagged "might need extra support"
            - List of recent check-ins with `NeuraCheckInCard`.

        - Quick/Guided check-in sheet:
            - Choose mood (chips: Lighter, Calmer, Stressed, Low, Tired, Mixed)
            - Intensity slider (0–10)
            - Optional note
            - Checkbox: "I might want extra support with this later"
            - On save:
                * Creates `NeuraCheckInEntry`
                * Calls `clinicalEngine.addEntry(entry)`
                * Updates:
                    - `persona.registerCheckIn(positive: ...)`
                    - `emotionEngine.recordSnapshot(...)`

- `lib/neura_shell/state/neura_shell_state.dart`
    * UPDATED master shell state adding:
        - `final NeuraClinicalEngine clinicalEngine;`
        - `_loadStartupRoomAndEngines()` extended to:
              - `clinicalEngine.ensureLoaded()`
      alongside existing engines (ritual, dream, reflection, etc.)

----------------------------------------------------------------------
How to merge this bundle
----------------------------------------------------------------------

1. Copy this bundle into your Flutter repo:
     - `lib/neura_clinical/` → into `lib/`
     - Overwrite:
         * `lib/neura_shell/rooms/clinical_bay_room.dart`
         * `lib/neura_shell/state/neura_shell_state.dart`

2. Ensure `shared_preferences` is present in `pubspec.yaml` (it is already
   required by other bundles like Dream / Ritual / Reflection).

3. Build and run:

     ```bash
     flutter pub get
     flutter run
     ```

4. Navigate to **Clinical Bay** in your Neura OS:
     - Read the safety notice.
     - Try a **Quick check-in**:
         * Choose mood, set intensity, (optionally) add a note and flag for support.
         * Save.
     - Observe:
         * Today's summary updates.
         * New entry appears in the list.

----------------------------------------------------------------------
What this adds to your OS

With this merged, your OS now has a dedicated **structured check-in wing**
that:
  - Treats emotional data respectfully and clearly
  - Emphasizes safety and limits of the app
  - Feeds into:
      * Persona growth
      * Emotion engine
      * Future clinical/therapist views you may build

This keeps you on the right side of "supportive mental health app" instead
of pretending to be professional care.
