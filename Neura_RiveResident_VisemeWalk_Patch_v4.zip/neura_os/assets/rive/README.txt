Place your Neura Rive file here:

  assets/rive/Neura.riv

Recommended:
- State machine name: NeuraBrain
- Inputs:
    bool  isWalking
    double talkLevel
    double rest, aa, ee, oo, ff, mm

If your file uses different names, update lib/neura_shell/widgets/neura_rive_resident.dart (input map section).
