import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../models/mood_state.dart';

class MoodStateService {
  MoodStateService._internal();
  static final MoodStateService instance = MoodStateService._internal();

  static const _keyMoodState = 'neura_mood_state_current_v1';

  MoodState _current = MoodState.neutral();
  bool _loaded = false;

  MoodState get current => _current;

  double get score => _current.score;

  MoodLabel get label => _current.label;

  Future<void> load() async {
    if (_loaded) return;
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_keyMoodState);
    if (raw == null) {
      _current = MoodState.neutral();
      _loaded = true;
      return;
    }
    try {
      final map = json.decode(raw);
      if (map is Map<String, dynamic>) {
        _current = MoodState.fromMap(map);
      } else {
        _current = MoodState.neutral();
      }
    } catch (e) {
      // Self-heal if JSON is corrupted.
      _current = MoodState.neutral();
      final prefs = await SharedPreferences.getInstance();
      await prefs.remove(_keyMoodState);
    }
    _loaded = true;
  }

  Future<void> setMoodState(MoodState state) async {
    _current = state;
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_keyMoodState, json.encode(state.toMap()));
  }

  /// Convenience helper for simple "set mood score" use cases.
  Future<void> setScore(double score, {String note = ''}) async {
    await load();
    final MoodLabel label;
    if (score <= 2.5) {
      label = MoodLabel.veryLow;
    } else if (score <= 4.0) {
      label = MoodLabel.low;
    } else if (score <= 6.0) {
      label = MoodLabel.neutral;
    } else if (score <= 8.0) {
      label = MoodLabel.lifted;
    } else {
      label = MoodLabel.high;
    }
    final updated = MoodState(
      date: DateTime.now(),
      score: score,
      label: label,
      note: note,
    );
    await setMoodState(updated);
  }
}
