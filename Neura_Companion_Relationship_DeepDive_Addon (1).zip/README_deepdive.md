
# Neura Companion – Relationship Deep Dive Add-On

This add-on **extends** the Relationship Upgrade Pack with:

1. A full **RelationshipDetailScreen** that shows:
   - Basic profile info
   - Latest interaction
   - Open promises for that person
   - Quick actions

2. A **RelationshipQuickNoteButton** widget:
   - Lets you log a simple interaction/note for a person in a couple of taps.

It assumes you already installed:

- `Neura_Companion_Relationship_UpgradePack.zip`

## Files in this add-on

- `lib/screens/relationship_detail_screen.dart`
- `lib/widgets/relationship_quick_note_button.dart`

## How to install

1. Copy the `lib/` folder from this ZIP into your Flutter app root,
   so paths line up like:

   - `lib/screens/relationship_detail_screen.dart`
   - `lib/widgets/relationship_quick_note_button.dart`

2. In `relationship_list_screen.dart` (from the previous pack),
   update the `onTap` handler to navigate into the detail screen:

```dart
import 'relationship_detail_screen.dart'; // at top

// inside itemBuilder:
onTap: () {
  Navigator.push(
    context,
    MaterialPageRoute(
      builder: (_) => RelationshipDetailScreen(profile: p),
    ),
  );
},
```

3. (Optional) On any screen where you want a "log note" FAB for a person:

```dart
import '../widgets/relationship_quick_note_button.dart';

// in your Scaffold:
floatingActionButton: RelationshipQuickNoteButton(profileId: profile.id),
```

That will pop a dialog to capture a quick note and store it as an InteractionRecord
(`InteractionChannel.note`) using `InteractionService`.
