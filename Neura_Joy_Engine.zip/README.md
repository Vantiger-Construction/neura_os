# Neura Joy Engine (Fun that Heals)
This module adds playful, mood-aware micro-activities that support wellness without becoming addictive.

## What’s inside
- core/lib/joy_engine/joy_engine.dart — pick a Joy Moment based on mood/intent
- core/lib/joy_engine/joy_moments.dart — curated safe micro-activities
- core/lib/joy_engine/joy_screen.dart — basic UI screen
- core/lib/joy_engine/joy_metrics.dart — local-only telemetry hook (wire to Memory Graph)

## Integration (Flutter)
1) Copy `core/lib/joy_engine/**` into your Flutter app under `core/lib/`.
2) Add route:
```dart
routes['/joy'] = (_) => const NeuraJoyScreen();
```
3) Trigger:
```dart
final moment = JoyEngine().pickMoment(currentMood, intent: currentIntent);
Navigator.pushNamed(context, '/joy', arguments: moment);
```

## Design rules
- Always include a “No thanks” option.
- Never use variable-ratio rewards.
- No infinite scroll loops.
