
# Neura Companion OS – Values Compass Pack

This pack gives Neura a **Values & Purpose layer** so she isn’t just
optimizing productivity or mood, but alignment with what matters most
to the user.

Included:

1. `NeuraCoreValue` model and `NeuraValuesProfile`.
2. `NeuraValuesService` (in-memory, ready to wire to storage).
3. `NeuraValuesQuickCheck` widget to let users pick & rank values.
4. `NeuraValuesAlignmentCard` that combines values with the
   `NeuraWeeklySnapshotService` to estimate how aligned the last week
   was with the user's top values.

This is intentionally simple and explainable; you can later plug in
deeper AI analysis or journaling flows on top.
