
import 'package:flutter/material.dart';

import '../neura_os_core/neura_values_profile.dart';

/// Simple quick-check UI for choosing and ordering core values.
class NeuraValuesQuickCheck extends StatefulWidget {
  const NeuraValuesQuickCheck({super.key});

  @override
  State<NeuraValuesQuickCheck> createState() => _NeuraValuesQuickCheckState();
}

class _NeuraValuesQuickCheckState extends State<NeuraValuesQuickCheck> {
  late List<String> _selectedIds;

  @override
  void initState() {
    super.initState();
    final existing = NeuraValuesService.instance.profile.valuePriority;
    _selectedIds = List<String>.from(existing);
  }

  @override
  Widget build(BuildContext context) {
    final allValues = NeuraDefaultValuesLibrary.all;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text(
          'What matters most to you?',
          style: Theme.of(context).textTheme.titleMedium,
        ),
        const SizedBox(height: 4),
        Text(
          'Pick a few values and drag them to rank them. '
          'Neura will use these as your compass.',
          style: Theme.of(context).textTheme.bodySmall,
        ),
        const SizedBox(height: 12),
        Wrap(
          spacing: 8,
          runSpacing: 4,
          children: allValues.map((v) {
            final selected = _selectedIds.contains(v.id);
            return FilterChip(
              label: Text(v.label),
              selected: selected,
              onSelected: (on) {
                setState(() {
                  if (on) {
                    _selectedIds.add(v.id);
                  } else {
                    _selectedIds.remove(v.id);
                  }
                });
              },
            );
          }).toList(),
        ),
        const SizedBox(height: 16),
        if (_selectedIds.isNotEmpty) ...[
          Text(
            'Drag to rank your top values:',
            style: Theme.of(context).textTheme.bodySmall,
          ),
          const SizedBox(height: 8),
          ReorderableListView(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            onReorder: (oldIndex, newIndex) {
              setState(() {
                if (newIndex > oldIndex) newIndex -= 1;
                final item = _selectedIds.removeAt(oldIndex);
                _selectedIds.insert(newIndex, item);
              });
            },
            children: [
              for (final id in _selectedIds)
                ListTile(
                  key: ValueKey(id),
                  leading: const Icon(Icons.drag_handle),
                  title: Text(
                    NeuraDefaultValuesLibrary.byId(id)?.label ?? id,
                  ),
                ),
            ],
          ),
        ],
        const SizedBox(height: 16),
        Align(
          alignment: Alignment.centerRight,
          child: ElevatedButton.icon(
            icon: const Icon(Icons.save),
            label: const Text('Save Values'),
            onPressed: _selectedIds.isEmpty
                ? null
                : () {
                    final profile =
                        NeuraValuesProfile(valuePriority: _selectedIds);
                    NeuraValuesService.instance.updateProfile(profile);
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('Values updated.')),
                    );
                  },
          ),
        ),
      ],
    );
  }
}
