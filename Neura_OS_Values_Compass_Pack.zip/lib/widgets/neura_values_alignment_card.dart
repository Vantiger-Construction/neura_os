
import 'package:flutter/material.dart';

import '../neura_os_core/neura_values_alignment.dart';
import '../neura_os_core/neura_values_profile.dart';
import '../neura_os_core/neura_weekly_snapshot.dart';

/// Dashboard card that shows how the last week aligned with top values.
class NeuraValuesAlignmentCard extends StatelessWidget {
  final NeuraWeeklySnapshot snapshot;

  const NeuraValuesAlignmentCard({
    super.key,
    required this.snapshot,
  });

  @override
  Widget build(BuildContext context) {
    final values = NeuraValuesService.instance.profile;
    if (values.isEmpty) {
      return Card(
        margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.compass_calibration),
                  const SizedBox(width: 8),
                  Text(
                    'Values Compass',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                ],
              ),
              const SizedBox(height: 8),
              Text(
                'Help Neura understand what matters most to you. '
                'Once you pick and rank your values, she will show '
                'how each week lines up with them.',
                style: Theme.of(context).textTheme.bodySmall,
              ),
            ],
          ),
        ),
      );
    }

    final result = NeuraValuesAlignmentCalculator.estimateAlignment(
      profile: values,
      snapshot: snapshot,
    );

    final overallPct = (result.overallScore * 100).clamp(0, 100).round();

    return Card(
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                const Icon(Icons.compass_calibration),
                const SizedBox(width: 8),
                Text(
                  'Values Compass',
                  style: Theme.of(context).textTheme.titleMedium,
                ),
                const Spacer(),
                Text(
                  '$overallPct% aligned',
                  style: Theme.of(context)
                      .textTheme
                      .bodySmall
                      ?.copyWith(color: Colors.grey),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(
              'This is a gentle estimate of how last week lined up '
              'with your top values. It's not a scorecard, just a '
              'starting point for reflection.',
              style: Theme.of(context).textTheme.bodySmall,
            ),
            const SizedBox(height: 12),
            Wrap(
              spacing: 8,
              runSpacing: 4,
              children: result.perValueScore.entries.map((entry) {
                final valueMeta = NeuraDefaultValuesLibrary.byId(entry.key);
                final label = valueMeta?.label ?? entry.key;
                final pct = (entry.value * 100).clamp(0, 100).round();
                return Chip(
                  avatar: const Icon(Icons.star, size: 16),
                  label: Text('$label: $pct%'),
                );
              }).toList(),
            ),
          ],
        ),
      ),
    );
  }
}
