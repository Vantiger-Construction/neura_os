# Neura Ethical Autonomy Guardrails
This module prevents Neura from becoming manipulative, addictive, coercive, or over-reliant.

## What it does
- Prompt throttling / cool-down windows
- "Ask vs Tell" enforcement
- Anti-dependence checks (encourage offline choices, avoid exclusivity)
- Distress routing (support-mode proposal)
- Age gating scaffolds

## Integration
Copy `core/lib/guardrails/**` into your Flutter app and call:

```dart
final decision = Guardrails().evaluate(context: ctx, proposal: proposal);
if (decision.allow) {
  // proceed
} else {
  // use decision.safeAlternative or do nothing
}
```
