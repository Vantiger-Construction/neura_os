
Neura v17.0 — Key Deliverables (Minimal Bundle)
- Android Health Connect bridge (HR + HRV) with permissions and recent window read.
- iOS HealthKit bridge (HR + HRV) with auth + recent window read.
- Flutter Health Live overlay (BPM + HRV RMSSD) and import bottom sheet hooks.
- Installer script placeholders (Win/MSIX, macOS DMG, Linux AppImage) — minimal notes included.

Use this as a verified, clean starting bundle if the larger pack had issues. You can merge into your main repo.
