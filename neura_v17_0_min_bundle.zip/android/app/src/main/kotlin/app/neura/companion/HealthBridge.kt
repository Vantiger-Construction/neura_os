
package app.neura.companion
import android.content.Context
import androidx.health.connect.client.HealthConnectClient
import androidx.health.connect.client.permission.HealthPermission
import androidx.health.connect.client.records.HeartRate
import androidx.health.connect.client.records.HeartRateVariabilityRmssd
import androidx.health.connect.client.request.ReadRecordsRequest
import androidx.health.connect.client.time.TimeRangeFilter
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import kotlinx.coroutines.*
import java.time.Instant

class HealthBridge(private val engine: FlutterEngine){
  private val CH = "neura.health"
  private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
  private fun ctx(): Context = engine.applicationContext
  fun register(){
    MethodChannel(engine.dartExecutor.binaryMessenger, CH).setMethodCallHandler { call, result ->
      when(call.method){
        "hasPerms" -> scope.launch {
          try{
            val hc = HealthConnectClient.getOrCreate(ctx())
            val perms = setOf(
              HealthPermission.getReadPermission(HeartRate::class),
              HealthPermission.getReadPermission(HeartRateVariabilityRmssd::class)
            )
            val granted = hc.permissionController.getGrantedPermissions(perms).containsAll(perms)
            result.success(granted)
          }catch(e:Throwable){ result.success(false) }
        }
        "requestPerms" -> { result.success(false) } // Launch a native Activity flow in your app to request
        "importRecent" -> {
          val minutes = (call.argument<Int>("minutes") ?: 60).toLong()
          scope.launch {
            var count = 0
            try{
              val hc = HealthConnectClient.getOrCreate(ctx())
              val end = Instant.now(); val start = end.minusSeconds(minutes*60)
              val hr = hc.readRecords(ReadRecordsRequest(HeartRate::class, timeRangeFilter = TimeRangeFilter.between(start,end)))
              count += hr.records.size
              val hrv = hc.readRecords(ReadRecordsRequest(HeartRateVariabilityRmssd::class, timeRangeFilter = TimeRangeFilter.between(start,end)))
              count += hrv.records.size
              result.success(count)
            }catch(e:Throwable){ result.success(count) }
          }
        }
        else -> result.notImplemented()
      }
    }
  }
}
