
import 'dart:async'; import 'dart:math'; import 'package:flutter/material.dart'; import 'package:flutter/services.dart';
class HealthLiveScreen extends StatefulWidget{ const HealthLiveScreen({super.key}); @override State<HealthLiveScreen> createState()=>_S(); }
class _S extends State<HealthLiveScreen>{
  static const _hr=EventChannel('neura.ble.hr'); StreamSubscription? _sub; final _vals=<int>[]; final _rr=<int>[];
  String status='Waiting…'; int? bpm; double? hrvRmssd; final int window=60; final double k=3.5;
  @override void initState(){ super.initState();
    _sub=_hr.receiveBroadcastStream().listen((e){ final m=Map<Object?,Object?>.from(e as Map);
      bpm=(m['bpm'] as num?)?.toInt();
      final rrs = (m['rr'] as List?)?.map((x)=> (x as num).toInt()).toList() ?? const [];
      if(rrs.isNotEmpty){ _rr.addAll(rrs); while(_rr.length>120) _rr.removeAt(0); _computeRmssd(); }
      if(bpm!=null){ _push(bpm!); } setState(()=>status='Live');}, onError: (_){ if(mounted) setState(()=>status='Stream error'); });
  }
  @override void dispose(){ _sub?.cancel(); super.dispose(); }
  void _computeRmssd(){ if(_rr.length<3){ hrvRmssd=null; return; } final diffs=<double>[]; for(int i=1;i<_rr.length;i++){ final d=_rr[i]-_rr[i-1]; diffs.add(d.toDouble()); } final sq=diffs.map((d)=>d*d).toList(); final mean=sq.reduce((a,b)=>a+b)/sq.length; hrvRmssd=sqrt(mean); }
  void _push(int v){ _vals.add(v); if(_vals.length>window) _vals.removeAt(0); }
  @override Widget build(BuildContext c)=>Padding(padding:const EdgeInsets.all(16), child:Column(crossAxisAlignment:CrossAxisAlignment.stretch,children:[
    Text('Status: $status  ·  BPM: ${bpm??'—'}  ·  HRV (RMSSD ms): ${hrvRmssd?.toStringAsFixed(1) ?? '—'}'),
    const SizedBox(height:8), Expanded(child:CustomPaint(painter:_Spark(_vals.map((e)=>e.toDouble()).toList()))),
  ]));
}
class _Spark extends CustomPainter{ final List<double> d; _Spark(this.d); @override void paint(Canvas c, Size s){ if(d.isEmpty)return; final p=Paint()..strokeWidth=2..style=PaintingStyle.stroke; final mx=d.reduce(max), mn=d.reduce(min); double norm(double x)=>mx==mn?s.height/2:s.height-((x-mn)/(mx-mn)*s.height); final path=Path(); for(int i=0;i<d.length;i++){ final x=s.width*(i/max(1,d.length-1)); final y=norm(d[i]); if(i==0)path.moveTo(x,y); else path.lineTo(x,y);} c.drawPath(path,p);} @override bool shouldRepaint(covariant CustomPainter oldDelegate)=>true; }
