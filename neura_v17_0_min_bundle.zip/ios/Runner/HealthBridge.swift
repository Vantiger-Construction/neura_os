
import Flutter, HealthKit

class HealthBridge: NSObject {
  let chName="neura.health"
  let store = HKHealthStore()
  var channel: FlutterMethodChannel!
  init(registrar: FlutterPluginRegistrar){
    super.init()
    channel = FlutterMethodChannel(name: chName, binaryMessenger: registrar.messenger())
    channel.setMethodCallHandler(handle)
  }
  func handle(_ call: FlutterMethodCall, result: @escaping FlutterResult){
    switch call.method {
      case "hasPerms":
        let types: Set = [
          HKObjectType.quantityType(forIdentifier: .heartRate)!,
          HKObjectType.quantityType(forIdentifier: .heartRateVariabilitySDNN)!
        ]
        store.getRequestStatusForAuthorization(toShare: [], read: types) { status, _ in
          result(status != .shouldRequest)
        }
      case "requestPerms":
        let types: Set = [
          HKObjectType.quantityType(forIdentifier: .heartRate)!,
          HKObjectType.quantityType(forIdentifier: .heartRateVariabilitySDNN)!
        ]
        store.requestAuthorization(toShare: nil, read: types) { ok, _ in result(ok) }
      case "importRecent":
        guard let args = call.arguments as? [String:Any], let minutes = args["minutes"] as? Int else { result(0); return }
        let end = Date()
        let start = Calendar.current.date(byAdding: .minute, value: -minutes, to: end)!
        let group = DispatchGroup()
        var count = 0
        func query(_ id: HKQuantityTypeIdentifier){
          let type = HKObjectType.quantityType(forIdentifier: id)!
          let pred = HKQuery.predicateForSamples(withStart: start, end: end, options: .strictEndDate)
          let q = HKSampleQuery(sampleType: type, predicate: pred, limit: HKObjectQueryNoLimit, sortDescriptors: nil){ _, samples, _ in
            count += samples?.count ?? 0
            group.leave()
          }
          group.enter()
          self.store.execute(q)
        }
        query(.heartRate)
        query(.heartRateVariabilitySDNN)
        group.notify(queue: .main){ result(count) }
      default: result(FlutterMethodNotImplemented)
    }
  }
}
