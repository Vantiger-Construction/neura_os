Neura Living System — Modules 7–9

OPTION A: Voice + Viseme Readiness
OPTION B: Apartment Objects (Features as Furniture)
OPTION C: World Memory (Rooms Remember)

Drop into:
lib/core/speech
lib/core/world

Wire:
• NeuraSpeechEngine → Presence
• ObjectInteractionEngine → Apartment UI
• WorldMemory → MemoryCore
