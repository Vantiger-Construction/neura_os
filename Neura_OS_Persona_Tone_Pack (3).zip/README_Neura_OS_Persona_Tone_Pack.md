
# Neura Companion OS – Persona & Tone Pack

This pack gives Neura a **Persona Context & Tone Engine**, so she can
adapt *how* she speaks and behaves based on:

- Focus mode (Deep Work, Reflection, Social, Wind Down, Normal)
- Values Compass (top values)
- Weekly Snapshot (how aligned the week has been)
- Mood engine (optional; you can wire in your own)

Included:

1. `neura_persona_context.dart`
   - `NeuraPersonaContext` model.
   - `NeuraPersonaContextService` to keep a live "who Neura is being"
     snapshot.
2. `neura_tone_engine.dart`
   - Maps persona context into tone tags you can pass into your
     chat/TTS layer.
3. `NeuraPersonaStatusCard` widget
   - Dashboard card that shows how Neura is currently orienting herself
     (role, tone, values she is prioritizing).
4. `NeuraToneHintChipRow` widget
   - Small chips that show the tone tags that will be used for chat.

You can use this both for UI flavour and as structured metadata
for your AI calls (e.g. pass tone tags in system prompt / API fields).
