
import 'package:flutter/material.dart';

import '../neura_os_core/neura_persona_context.dart';
import '../neura_os_core/neura_tone_engine.dart';
import '../neura_os_core/neura_values_profile.dart';

class NeuraPersonaStatusCard extends StatelessWidget {
  const NeuraPersonaStatusCard({super.key});

  @override
  Widget build(BuildContext context) {
    final service = NeuraPersonaContextService.instance;

    return AnimatedBuilder(
      animation: service,
      builder: (context, _) {
        final ctx = service.context;
        final hints = NeuraToneEngine.instance.buildToneHints(ctx);

        final valuesLabels = ctx.primaryValueIds
            .map((id) => NeuraDefaultValuesLibrary.byId(id)?.label ?? id)
            .toList();

        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.person_outline),
                    const SizedBox(width: 8),
                    Text(
                      'Neura's Current Persona',
                      style: Theme.of(context).textTheme.titleMedium,
                    ),
                    const Spacer(),
                    Text(
                      hints.styleName,
                      style: Theme.of(context)
                          .textTheme
                          .bodySmall
                          ?.copyWith(color: Colors.grey),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Text(
                  hints.shortDescription,
                  style: Theme.of(context).textTheme.bodySmall,
                ),
                const SizedBox(height: 8),
                Wrap(
                  spacing: 6,
                  runSpacing: 4,
                  children: [
                    Chip(
                      avatar: const Icon(Icons.bolt, size: 16),
                      label: Text('Energy: ${ctx.energy.name}'),
                    ),
                    Chip(
                      avatar: const Icon(Icons.favorite, size: 16),
                      label: Text('Warmth: ${ctx.warmth.name}'),
                    ),
                    Chip(
                      avatar: const Icon(Icons.mood, size: 16),
                      label: Text('Playful: ${ctx.playfulness.name}'),
                    ),
                    Chip(
                      avatar: const Icon(Icons.center_focus_strong, size: 16),
                      label: Text('Focus: ${ctx.focusMode.label}'),
                    ),
                    Chip(
                      avatar: const Icon(Icons.explore, size: 16),
                      label: Text(
                        'Values alignment: '
                        '${(ctx.valuesAlignment * 100).round()}%',
                      ),
                    ),
                    if (valuesLabels.isNotEmpty)
                      Chip(
                        avatar: const Icon(Icons.star, size: 16),
                        label: Text('Values: ${valuesLabels.join(', ')}'),
                      ),
                  ],
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}
