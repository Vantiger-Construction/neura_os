
import 'package:flutter/material.dart';

import '../neura_os_core/neura_persona_context.dart';
import '../neura_os_core/neura_tone_engine.dart';

/// Small row of chips showing active tone tags.
/// You can place this near the chat box or Neura avatar.
class NeuraToneHintChipRow extends StatelessWidget {
  const NeuraToneHintChipRow({super.key});

  @override
  Widget build(BuildContext context) {
    final service = NeuraPersonaContextService.instance;

    return AnimatedBuilder(
      animation: service,
      builder: (context, _) {
        final ctx = service.context;
        final hints = NeuraToneEngine.instance.buildToneHints(ctx);
        if (hints.tags.isEmpty) return const SizedBox.shrink();

        return SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          child: Row(
            children: hints.tags
                .map(
                  (t) => Padding(
                    padding: const EdgeInsets.only(right: 6),
                    child: Chip(
                      label: Text(t.replaceAll('_', ' ')),
                    ),
                  ),
                )
                .toList(),
          ),
        );
      },
    );
  }
}
