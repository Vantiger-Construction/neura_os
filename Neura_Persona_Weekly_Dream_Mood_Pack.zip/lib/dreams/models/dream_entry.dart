import 'package:flutter/foundation.dart';

@immutable
class DreamEntry {
  final String id;
  final DateTime date;
  final String title;
  final String description;
  final List<String> tags;
  final int vividness; // 1-5
  final String mood;   // calm / weird / scary / exciting, etc.

  const DreamEntry({
    required this.id,
    required this.date,
    required this.title,
    required this.description,
    required this.tags,
    required this.vividness,
    required this.mood,
  });

  DreamEntry copyWith({
    String? id,
    DateTime? date,
    String? title,
    String? description,
    List<String>? tags,
    int? vividness,
    String? mood,
  }) {
    return DreamEntry(
      id: id ?? this.id,
      date: date ?? this.date,
      title: title ?? this.title,
      description: description ?? this.description,
      tags: tags ?? this.tags,
      vividness: vividness ?? this.vividness,
      mood: mood ?? this.mood,
    );
  }

  Map<String, dynamic> toMap() => {
        'id': id,
        'date': date.toIso8601String(),
        'title': title,
        'description': description,
        'tags': tags,
        'vividness': vividness,
        'mood': mood,
      };

  factory DreamEntry.fromMap(Map<String, dynamic> map) {
    return DreamEntry(
      id: map['id'] as String,
      date: DateTime.tryParse(map['date'] as String? ?? '') ??
          DateTime.now(),
      title: map['title'] as String? ?? '',
      description: map['description'] as String? ?? '',
      tags: (map['tags'] as List<dynamic>? ?? [])
          .map((e) => e.toString())
          .toList(),
      vividness: map['vividness'] as int? ?? 3,
      mood: map['mood'] as String? ?? 'unknown',
    );
  }
}
