import '../models/dream_entry.dart';
import '../services/dream_service.dart';

class DreamThemeSummary {
  final int dreamCount;
  final List<String> topWords;
  final List<String> topTags;
  final String topMood;

  const DreamThemeSummary({
    required this.dreamCount,
    required this.topWords,
    required this.topTags,
    required this.topMood,
  });

  const DreamThemeSummary.empty()
      : dreamCount = 0,
        topWords = const [],
        topTags = const [],
        topMood = 'unknown';
}

class DreamThemeService {
  DreamThemeService._internal();
  static final DreamThemeService instance = DreamThemeService._internal();

  final _dreams = DreamService.instance;

  Future<DreamThemeSummary> computeSummary({int days = 30}) async {
    final all = await _dreams.loadDreams();
    final cutoff = DateTime.now().subtract(Duration(days: days));
    final recent = all.where((d) => d.date.isAfter(cutoff)).toList();
    if (recent.isEmpty) return const DreamThemeSummary.empty();

    final wordCounts = <String, int>{};
    final tagCounts = <String, int>{};
    final moodCounts = <String, int>{};

    const stopWords = {
      'the',
      'and',
      'a',
      'an',
      'i',
      'to',
      'it',
      'of',
      'in',
      'on',
      'for',
      'with',
      'was',
      'were',
      'had',
      'have',
      'you',
      'me',
      'my',
      'we',
      'they',
      'them',
    };

    for (final d in recent) {
      final text = '${d.title} ${d.description}'.toLowerCase();
      final tokens = text.split(RegExp(r'[^a-z0-9]+'));
      for (final t in tokens) {
        if (t.isEmpty || t.length <= 3 || stopWords.contains(t)) continue;
        wordCounts[t] = (wordCounts[t] ?? 0) + 1;
      }

      for (final tag in d.tags) {
        final key = tag.toLowerCase();
        if (key.isEmpty) continue;
        tagCounts[key] = (tagCounts[key] ?? 0) + 1;
      }

      final mood = d.mood.toLowerCase();
      if (mood.isNotEmpty) {
        moodCounts[mood] = (moodCounts[mood] ?? 0) + 1;
      }
    }

    List<String> topWords = wordCounts.keys.toList();
    topWords.sort((a, b) => (wordCounts[b] ?? 0) - (wordCounts[a] ?? 0));
    topWords = topWords.take(5).toList();

    List<String> topTags = tagCounts.keys.toList();
    topTags.sort((a, b) => (tagCounts[b] ?? 0) - (tagCounts[a] ?? 0));
    topTags = topTags.take(5).toList();

    String topMood = 'unknown';
    int topMoodCount = 0;
    moodCounts.forEach((m, c) {
      if (c > topMoodCount) {
        topMood = m;
        topMoodCount = c;
      }
    });

    return DreamThemeSummary(
      dreamCount: recent.length,
      topWords: topWords,
      topTags: topTags,
      topMood: topMood,
    );
  }
}
