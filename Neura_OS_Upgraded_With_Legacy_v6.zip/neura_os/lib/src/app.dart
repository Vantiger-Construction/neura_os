import 'package:flutter/material.dart';

import '../modules/core/error_handler.dart';
import '../modules/navigation/enhanced_navigation.dart';

class NeuroCompanionApp extends StatelessWidget {
  const NeuroCompanionApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Neura OS',
      theme: ThemeData.dark(),
      scaffoldMessengerKey: ErrorHandler.scaffoldMessengerKey,
      home: const EnhancedNavigation(),
    );
  }
}
