@echo off
setlocal ENABLEDELAYEDEXPANSION
cd /d "%~dp0"

echo [INFO] Make Neura Structure + APK Builder

REM --- Create folders ---
set KIT=Neura_Companion_Pixar_Asset_Kit
mkdir "%KIT%\Figma" 2>nul
mkdir "%KIT%\SVG" 2>nul
mkdir "%KIT%\Rive" 2>nul
mkdir "%KIT%\PNGs" 2>nul
mkdir "%KIT%\Flutter" 2>nul
mkdir ".github\workflows" 2>nul

REM --- Copy examples (safe if missing) ---
if exist "lib\widgets\AnimatedNeuraRive.dart" copy /Y "lib\widgets\AnimatedNeuraRive.dart" "%KIT%\Flutter\" >nul
if exist "pubspec.yaml" copy /Y "pubspec.yaml" "%KIT%\" >nul
if exist "README.md" copy /Y "README.md" "%KIT%\" >nul
for %%f in (*.svg) do copy /Y "%%f" "%KIT%\SVG\" >nul
for %%f in (*.png) do copy /Y "%%f" "%KIT%\PNGs\" >nul
if exist "assets\neura_fullbody.riv" copy /Y "assets\neura_fullbody.riv" "%KIT%\Rive\" >nul

REM --- Drop GitHub Actions if missing (idempotent) ---
if not exist ".github\workflows\main.yml" (
  echo name: Neura Companion CI/CD>.github\workflows\main.yml
  echo on:>>.github\workflows\main.yml
  echo   push:>>.github\workflows\main.yml
  echo     branches: [ "main" ]>>.github\workflows\main.yml
  echo   pull_request:>>.github\workflows\main.yml
  echo     branches: [ "main" ]>>.github\workflows\main.yml
  echo jobs:>>.github\workflows\main.yml
  echo   build:>>.github\workflows\main.yml
  echo     runs-on: ubuntu-latest>>.github\workflows\main.yml
  echo     steps:>>.github\workflows\main.yml
  echo       - name: Checkout repository>>.github\workflows\main.yml
  echo         uses: actions/checkout@v4>>.github\workflows\main.yml
  echo       - name: Set up Flutter>>.github\workflows\main.yml
  echo         uses: subosito/flutter-action@v2>>.github\workflows\main.yml
  echo         with:>>.github\workflows\main.yml
  echo           flutter-version: '3.22.0'>>.github\workflows\main.yml
  echo       - name: Install dependencies>>.github\workflows\main.yml
  echo         run: flutter pub get>>.github\workflows\main.yml
  echo       - name: Analyze>>.github\workflows\main.yml
  echo         run: flutter analyze>>.github\workflows\main.yml
  echo       - name: Run tests>>.github\workflows\main.yml
  echo         run: flutter test --test-randomize-ordering-seed=random>>.github\workflows\main.yml
  echo       - name: Build APK (release)>>.github\workflows\main.yml
  echo         run: flutter build apk --release>>.github\workflows\main.yml
)

REM --- Local release APK build ---
where flutter >nul 2>nul
if errorlevel 1 (
  echo [WARN] Flutter not in PATH; skipping local APK build. CI workflow is ready.
  goto :LIST
)

echo [STEP] flutter pub get
flutter pub get || (echo [ERROR] pub get failed & exit /b 1)

echo [STEP] flutter build apk --release
flutter build apk --release || (echo [ERROR] build failed & exit /b 1)

if exist "build\app\outputs\flutter-apk\app-release.apk" (
  copy /Y "build\app\outputs\flutter-apk\app-release.apk" "%KIT%\" >nul
  echo [INFO] Copied release APK into "%KIT%\"
)

:LIST
echo.
echo [TREE] %KIT% contents:
dir "%KIT%" /s
echo.
echo [DONE] Project structure and optional APK ready.
exit /b 0