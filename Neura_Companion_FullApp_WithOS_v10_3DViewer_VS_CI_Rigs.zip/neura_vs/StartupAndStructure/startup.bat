@echo off
setlocal ENABLEDELAYEDEXPANSION
cd /d "%~dp0"

echo [INFO] Neura Companion VS Startup
echo [STEP] Checking Flutter installation...
where flutter >nul 2>nul
if errorlevel 1 (
  echo [ERROR] Flutter not found in PATH. Install Flutter and ensure "flutter.bat" is in PATH (e.g., C:\src\flutter\bin).
  exit /b 1
)

for /f "tokens=*" %%v in ('flutter --version') do (echo [FLUTTER] %%v)

echo [STEP] flutter pub get
flutter pub get
if errorlevel 1 (
  echo [ERROR] flutter pub get failed.
  exit /b 1
)

echo [STEP] Static analysis (flutter analyze)
flutter analyze
set ANALYZE_EXIT=%ERRORLEVEL%
if not "%ANALYZE_EXIT%"=="0" (
  echo [WARN] Analyzer reported issues. Continuing so you can debug.
)

echo [STEP] Launching app (flutter run)
flutter run
exit /b %ERRORLEVEL%