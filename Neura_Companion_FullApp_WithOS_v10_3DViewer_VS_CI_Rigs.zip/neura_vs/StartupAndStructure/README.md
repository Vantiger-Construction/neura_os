# Neura Companion — Visual Studio Startup + Structure Bundle

This bundle wires **Visual Studio 2022** to run your Flutter app and includes a structure/build script + CI workflow.

## What’s inside
- `NeuraCompanion.sln` and `NeuraCompanion/NeuraCompanion.vcxproj` (Makefile project)
- `startup.bat` — `flutter pub get` → `flutter analyze` → `flutter run`
- `analyze.bat` — analyzer-only
- `MakeNeuraStructure.bat` — asset kit scaffold + GH Actions + local release APK build
- `.github/workflows/main.yml` — CI/CD (analyze, test, build, artifact)

## Quick start (Visual Studio)
1. Extract this ZIP into the **root of your Flutter repo** (where `pubspec.yaml` lives).
2. Open `NeuraCompanion.sln` in **Visual Studio 2022+**.
3. Select **Debug | x64**.
4. Press **F5**.
   - Fetches deps, runs analyzer, launches the app.

## Build structure + APK locally
Run:
```
MakeNeuraStructure.bat
```
This creates the Pixar-style asset kit at `Neura_Companion_Pixar_Asset_Kit/` and, if Flutter is on PATH, builds a **release APK** and drops it inside the kit.

## CI/CD
Push to `main` and GitHub Actions will:
- `flutter pub get`
- `flutter analyze`
- `flutter test`
- `flutter build apk --release`
- Upload the APK as an artifact

---

Tips:
- Ensure `flutter` is on PATH (e.g., `C:\src\flutter\bin`).
- Edit `startup.bat` if you want to block on analyzer errors (switch WARN → ERROR).
- Add your emulators or devices before pressing F5 for fast boot.