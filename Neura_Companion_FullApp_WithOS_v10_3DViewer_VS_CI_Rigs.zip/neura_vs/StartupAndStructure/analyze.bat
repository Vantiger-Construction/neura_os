@echo off
cd /d "%~dp0"
echo [INFO] Static analysis (flutter analyze)...
flutter analyze
exit /b %ERRORLEVEL%