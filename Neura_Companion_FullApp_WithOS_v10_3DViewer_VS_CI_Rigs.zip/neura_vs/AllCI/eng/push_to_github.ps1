param([Parameter(Mandatory=$true)][string]$Repo,[Parameter(Mandatory=$true)][string]$Pat,[string]$Branch="main")
$ErrorActionPreference="Stop"
git init
git remote remove origin 2>$null
git remote add origin "https://$Pat@github.com/$Repo.git"
git checkout -B $Branch
git add .
git commit -m "Neura Companion VS ALL CI: initial commit"
git push -u origin $Branch
