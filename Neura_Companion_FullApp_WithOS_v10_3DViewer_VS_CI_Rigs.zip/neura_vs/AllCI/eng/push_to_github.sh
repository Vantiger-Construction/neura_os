#!/usr/bin/env bash
set -euo pipefail
REPO="${1:-}"; PAT="${2:-}"; BRANCH="${3:-main}"
git init
git remote remove origin || true
git remote add origin "https://${PAT}@github.com/${REPO}.git"
git checkout -B "${BRANCH}"
git add .
git commit -m "Neura Companion VS ALL CI: initial commit"
git push -u origin "${BRANCH}"
