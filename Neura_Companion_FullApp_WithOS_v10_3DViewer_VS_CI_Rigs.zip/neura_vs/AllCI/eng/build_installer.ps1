$ErrorActionPreference="Stop"
dotnet build src/Neura.App.WinUI/Neura.App.WinUI.csproj -c Release
dotnet tool update -g wix --version 4.0.3 | Out-Null
$tool = Join-Path $env:USERPROFILE ".dotnet\tools\wix.exe"
if (!(Test-Path $tool)) { throw "WiX tool not found" }
Set-Location src/Neura.Installer
& $tool harvest component-group AppFiles -directory "..\Neura.App.WinUI\bin\Release" -ext WixToolset.Harvesters > Fragments.wxs
dotnet build Neura.Installer.wixproj -c Release
