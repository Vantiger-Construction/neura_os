Console.WriteLine("Neura CLI");
