using Neura.Core;
using System.Net.Http;
using System.Net.Http.Json;

namespace Neura.AI;
public sealed class HttpAiClient : IAiClient
{
    private readonly HttpClient _http;
    public HttpAiClient(HttpClient http) => _http = http;
    public async Task<string> ChatAsync(string input, CancellationToken ct=default)
    {
        try{
            var res = await _http.PostAsJsonAsync("/chat", new { input }, ct);
            if (res.IsSuccessStatusCode) return await res.Content.ReadAsStringAsync(ct);
        } catch {}
        return $"[offline] {input}";
    }
}
