namespace Neura.Core;
public interface IAiClient { Task<string> ChatAsync(string input, CancellationToken ct=default); }
public enum VoiceStyle { Neutral, Warm, Calm, Excited }
public interface IVoiceSynth { Task SpeakAsync(string text, VoiceStyle style=VoiceStyle.Neutral, CancellationToken ct=default); }
public interface IRepository<T> { Task UpsertAsync(T item); IAsyncEnumerable<T> AllAsync(); }
public interface IPlugin { string Id { get; } string DisplayName { get; } void Register(Microsoft.Extensions.DependencyInjection.IServiceCollection services); }
