namespace Neura.Core;
public readonly record struct Result(bool Ok, string? Error=null);
public readonly record struct Result<T>(bool Ok, T? Value, string? Error);
