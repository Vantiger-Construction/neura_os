using Xunit;
public class SampleTests { [Fact] public void Ping() => Assert.True(true); }
