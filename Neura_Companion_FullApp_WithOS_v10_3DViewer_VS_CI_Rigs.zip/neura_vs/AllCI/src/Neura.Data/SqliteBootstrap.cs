using Microsoft.Data.Sqlite;
using Dapper;
namespace Neura.Data;
public static class SqliteBootstrap
{
    public static async Task InitAsync(string connectionString)
    {
        using var conn = new SqliteConnection(connectionString);
        await conn.OpenAsync();
        await conn.ExecuteAsync(@"CREATE TABLE IF NOT EXISTS Journal(
            Id INTEGER PRIMARY KEY AUTOINCREMENT,
            CreatedUtc TEXT NOT NULL,
            Mood TEXT,
            Content TEXT NOT NULL
        );");
    }
}
