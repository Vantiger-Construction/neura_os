using Microsoft.Data.Sqlite;
using Dapper;
using Neura.Core;
namespace Neura.Data;
public sealed class JournalEntry {
  public long Id {get;set;}
  public DateTime CreatedUtc {get;set;}
  public string? Mood {get;set;}
  public string Content {get;set;} = "";
}
public sealed class JournalRepository : IRepository<JournalEntry>
{
    private readonly string _cs;
    public JournalRepository(string connectionString)=>_cs = connectionString;
    public async Task UpsertAsync(JournalEntry item)
    {
        using var conn = new SqliteConnection(_cs);
        await conn.ExecuteAsync("INSERT INTO Journal (CreatedUtc, Mood, Content) VALUES (@CreatedUtc, @Mood, @Content)", item);
    }
    public async IAsyncEnumerable<JournalEntry> AllAsync()
    {
        using var conn = new SqliteConnection(_cs);
        var rows = await conn.QueryAsync<JournalEntry>("SELECT * FROM Journal ORDER BY CreatedUtc DESC");
        foreach (var r in rows) yield return r;
    }
}
