using Neura.Core;
using System.Media;
namespace Neura.Voice;
public sealed class BasicVoiceSynth : IVoiceSynth
{
    public Task SpeakAsync(string text, VoiceStyle style=VoiceStyle.Neutral, CancellationToken ct=default)
    {
        SystemSounds.Asterisk.Play();
        return Task.CompletedTask;
    }
}
