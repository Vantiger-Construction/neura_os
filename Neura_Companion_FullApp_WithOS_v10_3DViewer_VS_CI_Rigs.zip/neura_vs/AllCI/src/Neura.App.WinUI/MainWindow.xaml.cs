using Microsoft.UI.Xaml;
using Microsoft.UI.Xaml.Controls;
using System.Threading.Tasks;
using Neura.Core;
using Microsoft.Extensions.DependencyInjection;

namespace Neura.App.WinUI;

public sealed partial class MainWindow : Window
{
    private readonly IAiClient _ai;
    private readonly IVoiceSynth _voice;

    public MainWindow()
    {
        this.InitializeComponent();
        Title = "Neura Companion";
        var nav = new NavigationView{ IsBackButtonVisible = NavigationViewBackButtonVisible.Collapsed, PaneDisplayMode = NavigationViewPaneDisplayMode.Left };
        nav.MenuItems.Add(new NavigationViewItem{ Content="Rituals", Tag="rituals" });
        nav.MenuItems.Add(new NavigationViewItem{ Content="Journal", Tag="journal" });
        nav.MenuItems.Add(new NavigationViewItem{ Content="Dreamscape", Tag="dreams" });
        nav.MenuItems.Add(new NavigationViewItem{ Content="VR", Tag="vr" });
        nav.MenuItems.Add(new NavigationViewItem{ Content="Mood", Tag="mood" });
        nav.FooterMenuItems.Add(new NavigationViewItem{ Content="Settings", Tag="settings" });
        var frame = new Frame();
        nav.Content = frame;
        nav.SelectionChanged += (_, e) => {
            var tag = (e.SelectedItem as NavigationViewItem)?.Tag?.ToString();
            frame.Content = new TextBlock{ Text = $"[{tag}] Coming alive..." , HorizontalAlignment = HorizontalAlignment.Center, VerticalAlignment = VerticalAlignment.Center };
        };
        Content = nav;

        _ai = App.HostSvc.Services.GetRequiredService<IAiClient>();
        _voice = App.HostSvc.Services.GetRequiredService<IVoiceSynth>();
        _ = InitAsync();
    }

    private async Task InitAsync(){
        await _voice.SpeakAsync("Neura Companion is ready.", VoiceStyle.Warm);
        var echo = await _ai.ChatAsync("Hello Neura");
    }
}
