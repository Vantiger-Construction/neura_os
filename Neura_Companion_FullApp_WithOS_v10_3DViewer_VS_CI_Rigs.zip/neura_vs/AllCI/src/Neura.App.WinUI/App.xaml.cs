using Microsoft.UI.Xaml;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.DependencyInjection;
using System;
using System.IO;
using System.Text.Json;
using Neura.Core;
using Neura.Voice;
using Neura.AI;
using Neura.Data;

namespace Neura.App.WinUI;

public partial class App : Application
{
    public static IHost HostSvc { get; private set; } = default!;

    public App()
    {
        this.InitializeComponent();
        AppDomain.CurrentDomain.UnhandledException += (_, e) =>
        {
            try {
                var dir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "Neura", "Reports");
                Directory.CreateDirectory(dir);
                File.WriteAllText(Path.Combine(dir, $"crash_{DateTime.UtcNow:yyyyMMdd_HHmmss}.log"), e.ExceptionObject?.ToString() ?? "unknown");
            } catch {}
        };
        HostSvc = CreateHost();
    }

    private static IHost CreateHost()
    {
        var builder = Host.CreateDefaultBuilder();
        var cfgPath = Path.Combine(AppContext.BaseDirectory, "config", "appsettings.json");
        var cfg = JsonSerializer.Deserialize<Config>(File.ReadAllText(cfgPath)) ?? new();
        builder.ConfigureServices(services =>
        {
            services.AddSingleton(cfg);
            services.AddHttpClient<IAiClient, HttpAiClient>(c => c.BaseAddress = new Uri(cfg.Ai.BaseUrl));
            services.AddSingleton<IVoiceSynth, BasicVoiceSynth>();
            services.AddSingleton<IRepository<Neura.Data.JournalEntry>>(sp => new JournalRepository(cfg.Data.ConnectionString));
        });
        var host = builder.Build();
        SqliteBootstrap.InitAsync(cfg.Data.ConnectionString).GetAwaiter().GetResult();
        return host;
    }

    protected override void OnLaunched(LaunchActivatedEventArgs args)
    {
        var window = new MainWindow();
        window.Activate();
    }

    public sealed class Config {
        public AiCfg Ai {get;set;} = new();
        public DataCfg Data {get;set;} = new();
        public FeatureCfg Features {get;set;} = new();
        public sealed class AiCfg { public string BaseUrl {get;set;} = "http://localhost:8000"; public int TimeoutSeconds {get;set;}=30; }
        public sealed class DataCfg { public string Provider {get;set;}="SQLite"; public string ConnectionString {get;set;}="Data Source=neura.db"; }
        public sealed class FeatureCfg { public bool Dreamscape{get;set;}=true; public bool Therapist{get;set;}=true; public bool VR{get;set;}=true; public bool MoodNet{get;set;}=true; }
    }
}
