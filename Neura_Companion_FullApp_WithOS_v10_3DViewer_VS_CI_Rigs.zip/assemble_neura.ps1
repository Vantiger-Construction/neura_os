param(
  [string[]]$SearchRoots = @('I:\', 'I:\Neura_MegaMerge'),
  [string]$OutRoot = 'I:\Neura_Build_Base',
  [string[]]$Families,
  [switch]$DryRun,
  [switch]$VerboseLog
)

$ErrorActionPreference = 'Stop'

function Get-NormalizedPath([string]$p) {
  if ([string]::IsNullOrWhiteSpace($p)) { return $null }
  return ($p.TrimEnd('\/'))
}

# Prepare logging
$timestamp = Get-Date -Format 'yyyyMMdd_HHmmss'
$logDir = Join-Path $OutRoot 'Logs'
$manifestPath = Join-Path $logDir ("assembly_manifest_${timestamp}.csv")
$runLogPath = Join-Path $logDir ("run_${timestamp}.log")

# Ensure output/log directories exist
New-Item -ItemType Directory -Force -Path $OutRoot | Out-Null
New-Item -ItemType Directory -Force -Path $logDir | Out-Null

function Write-RunLog($msg) {
  $line = "[$(Get-Date -Format 'u')] $msg"
  $line | Tee-Object -FilePath $runLogPath -Append | Out-Null
}

Write-RunLog "Starting assembly. DryRun=$($DryRun.IsPresent) OutRoot=$OutRoot"
Write-RunLog "SearchRoots: $([string]::Join('; ', $SearchRoots))"

# Exclusions for discovery and copying
$excludeTopNames = @('Neura_Collected','Neura_Cleanup','Neura_Unzipped','Neura_Build_Base','flutter_stable','System Volume Information','Documents','.git','.github')
$copyExcludeDirNames = @('node_modules','build','dist','.git','.github','.dart_tool','.gradle','.vscode','.idea','.svn','.hg','.pio','.terraform','.next','.cache','tmp','temp','coverage','logs','log','out','output','Generated','Pods','.venv','env','venv','__pycache__','.mypy_cache')
$copyExcludeFiles = @('*.zip','*.7z','*.rar','*.iso','*.dmg','*.msi','.DS_Store')

# Discover candidate families if none provided
if (-not $Families -or $Families.Count -eq 0) {
  $candidates = @()
  foreach ($root in $SearchRoots) {
    $r = Get-NormalizedPath $root
    if (-not (Test-Path $r)) { Write-RunLog "Skip missing root: $r"; continue }
    Write-RunLog "Scanning root: $r"
    try {
      $dirs = Get-ChildItem -Path $r -Directory -ErrorAction SilentlyContinue
      foreach ($d in $dirs) {
        if ($excludeTopNames -contains $d.Name) { continue }
        if ($d.Name -match '^(neura|Neura)') {
          $candidates += $d
        }
      }
      # Special-case: one more level inside Neura_MegaMerge
      if ((Split-Path -Leaf $r) -eq 'Neura_MegaMerge') {
        $subdirs = Get-ChildItem -Path $r -Directory -ErrorAction SilentlyContinue
        foreach ($sd in $subdirs) {
          if ($sd.Name -match '^(neura|Neura)') { $candidates += $sd }
        }
      }
    } catch {
      Write-RunLog "Warn: failed to scan ${r}: $($_.Exception.Message)"
    }
  }
  # Compute family base names by stripping trailing _<digits>
  $Families = $candidates |
    Select-Object -ExpandProperty Name |
    ForEach-Object { $_ -replace '_\d+$','' } |
    Sort-Object -Unique
  Write-RunLog ("Discovered families: " + ($Families -join ', '))
}

# Build index of candidates per family
$familyMap = @{}
foreach ($root in $SearchRoots) {
  $r = Get-NormalizedPath $root
  if (-not (Test-Path $r)) { continue }
  # Consider two levels: root and (if Neura_MegaMerge) its direct children
  $scanDirs = @()
  $scanDirs += (Get-ChildItem -Path $r -Directory -ErrorAction SilentlyContinue)
  if ((Split-Path -Leaf $r) -eq 'Neura_MegaMerge') {
    $scanDirs += (Get-ChildItem -Path $r -Directory -ErrorAction SilentlyContinue)
  }
  foreach ($dir in $scanDirs) {
    $name = $dir.Name
    $base = ($name -replace '_\d+$','')
    if ($Families -notcontains $base) { continue }
    if ($excludeTopNames -contains $name) { continue }
    if (-not $familyMap.ContainsKey($base)) { $familyMap[$base] = @() }
    $familyMap[$base] += $dir
  }
}

# Select newest candidate per family
$selections = @()
foreach ($fam in $Families) {
  if (-not $familyMap.ContainsKey($fam)) { continue }
  $cands = $familyMap[$fam]
  if (-not $cands -or $cands.Count -eq 0) { continue }
  # Rank by LastWriteTime (desc), then by numeric suffix if present
  $ranked = $cands | Sort-Object @{Expression={$_.LastWriteTimeUtc};Descending=$true}, @{Expression={
      $m = [regex]::Match($_.Name, '_(\d+)$'); if ($m.Success) { [int]$m.Groups[1].Value } else { -1 }
    };Descending=$true}
  $chosen = $ranked[0]
  $selections += [pscustomobject]@{
    Family = $fam
    ChosenName = $chosen.Name
    ChosenPath = $chosen.FullName
    LastWriteTimeUtc = $chosen.LastWriteTimeUtc
  }
}

# Write manifest header
"Family,ChosenName,ChosenPath,LastWriteTimeUtc,DestPath,Action" | Out-File -FilePath $manifestPath -Encoding UTF8

# Perform copy or dry-run
$copied = 0
foreach ($sel in $selections) {
  $dest = Join-Path $OutRoot $sel.Family
  $action = if ($DryRun) { 'Selected' } else { 'Copied' }
  $line = "$($sel.Family),$($sel.ChosenName),$([regex]::Escape($sel.ChosenPath).Replace('\\','/')),$($sel.LastWriteTimeUtc.ToString('u')),$([regex]::Escape($dest).Replace('\\','/')),$action"
  Add-Content -Path $manifestPath -Value $line

  Write-RunLog "$action $($sel.Family): $($sel.ChosenPath) -> $dest"
  if ($DryRun) { continue }

  New-Item -ItemType Directory -Force -Path $dest | Out-Null
  # Build robocopy exclude lists as full paths under source
  $xd = @()
  foreach ($n in $copyExcludeDirNames) { $xd += (Join-Path $sel.ChosenPath $n) }

  $rcArgs = @(
    '"' + $sel.ChosenPath + '"',
    '"' + $dest + '"',
    '/E',
    '/R:1','/W:1','/NFL','/NDL','/NP','/XO'
  )
  if ($xd.Count -gt 0) { $rcArgs += @('/XD'); $rcArgs += $xd }
  if ($copyExcludeFiles.Count -gt 0) { $rcArgs += @('/XF'); $rcArgs += $copyExcludeFiles }

  $cmd = 'robocopy ' + ($rcArgs -join ' ')
  Write-RunLog "RUN: $cmd"
  $p = Start-Process -FilePath robocopy.exe -ArgumentList $rcArgs -Wait -PassThru -WindowStyle Hidden
  $code = $p.ExitCode
  # Robocopy codes 0-7 are success/warnings
  if ($code -ge 8) {
    Write-RunLog "ERROR: robocopy exit code $code for $($sel.Family)"
  } else {
    $copied++
  }
}

Write-RunLog "Assembly complete. Selected=$($selections.Count) Copied=$copied Manifest=$manifestPath"
if ($VerboseLog) { Write-Output "Manifest: $manifestPath`nRunLog: $runLogPath" }
