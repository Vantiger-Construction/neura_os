# Neura Companion — Multi‑Room Starter

This starter wires Neura as a full‑body avatar who can walk/talk/move and travel between rooms.
Each room is a module surface (Clinical, Dream, Joy Lounge, Reflection Bay, Mood Den, Goal Arcade, Settings).

> Drop your real Rive full‑body rig at: `assets/rive/neura_fullbody.riv`.
> The starter gracefully shows a placeholder if the rig is missing.

## Rooms included
- ClinicalRoom — hooks for vitals/logs, export/share
- DreamRoom — hooks for Dream Visualizer & replay
- JoyLoungeRoom — calm hub and mini‑games
- ReflectionBayRoom — journaling + mood summaries
- MoodDenRoom — charts + heatmap placeholder
- GoalArcadeRoom — gamified goals
- SettingsRoom — mascot voice/appearance, privacy toggles

## Quickstart

```bash
flutter pub get
flutter run -d chrome   # or android/ios
```

To build Android:
```bash
./scripts/Build_All.bat   # Windows
```

### Asset Notes
- Replace placeholders in `assets/images/backgrounds/` with your real art.
- Place your `neura_fullbody.riv` in `assets/rive/`. The widget will fail‑soft with a friendly UI if not present.
- Optional Lottie overlays live in `assets/lottie/`.

### How Neura moves
- `NeuraEngine` exposes commands (`walkTo(Room)`, `speak(text)`, `setMood(...)`) and broadcasts state via `ChangeNotifier`.
- `NeuraAvatar` listens to engine state, plays Rive animations, and shows a speaking overlay when `isSpeaking` is true.
- Navigation uses a shared route table so walking triggers a short "walk out" anim before route change.

### Where to add your logic
- AI brain / intent routing: `lib/engine/neura_engine.dart`
- Room UIs and actions: `lib/rooms/*.dart`
- Avatar animation inputs/param names: `lib/widgets/neura_avatar.dart` (`Artboard` + state machine inputs)

---
