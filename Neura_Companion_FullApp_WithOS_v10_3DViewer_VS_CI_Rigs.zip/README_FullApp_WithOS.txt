Neura Companion – Full App + OS Shell Integrated
===============================================

This project merges:
- Neura_Companion_ReadyToRun_AllNeuraMerged_FINAL_plusDreamsDebug.zip  (main companion app)
- Neura_Companion_OS_Rebuilt_WithUpdates_v2.zip                       (OS shell + care/weekly/dream/mood/kids)

Key additions from the OS side are now available under lib/:
- neura_shell/      → OS world (rooms, shell scaffold, entry)
- neura_os_core/    → persona, tone, values/action, weekly/session engines
- persona/          → audience + persona context
- kids/             → kids-safe stubs
- care/             → Care Mode 2.0 (trusted contacts + playbooks)
- insights/         → Weekly Snapshot
- dreams/           → Dream Show 2
- mood/ & mirror/   → Mirror Mood + mood-based theme/difficulty

How to run:
-----------
1. From this folder:
     flutter pub get
     flutter run

2. To enter the Neura OS shell from your existing dashboard, add a route in your MaterialApp:
     routes: {
       '/neura/os': (_) => const NeuraShellRootScreen(),
       // other routes...
     }

   And from a button on your dashboard:
     ElevatedButton(
       onPressed: () => Navigator.of(context).pushNamed('/neura/os'),
       child: const Text('Enter Neura OS'),
     );

Nothing in your existing startup flow was overwritten – the OS is added as a module.