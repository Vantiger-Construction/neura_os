@echo off
setlocal
REM Dry-run assembly selection to choose newest module variants and produce a manifest/log
powershell -NoProfile -ExecutionPolicy Bypass -File i:\neura-assembler\assemble_neura.ps1 -OutRoot I:\Neura_Build_Base -DryRun -VerboseLog
endlocal
