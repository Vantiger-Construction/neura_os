Neura Companion - Ready-to-Run Bundle
=====================================

How to run in DEBUG on a device (Windows):

1. Install Flutter and Android SDK if you haven't already.
2. Extract this folder somewhere like: C:\Neura\Neura_Companion\
3. Plug in an Android device with USB debugging enabled, or start an emulator.
4. Double-click:
   scripts\Neura_AutoSetup_And_Run_Debug.bat

That script will:
  - flutter clean
  - flutter pub get
  - flutter run

How to build a RELEASE APK:

1. Make sure your keystore / signing is configured for Flutter.
2. From this folder, double-click:
   scripts\Neura_Build_Release_Android.bat

That script will:
  - flutter clean
  - flutter pub get
  - flutter build apk --release

Output APK:
  build\app\outputs\flutter-apk\app-release.apk
