import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'neura_room_state.dart';

class NeuraRoomBadge extends StatelessWidget {
  const NeuraRoomBadge({super.key});

  @override
  Widget build(BuildContext context) {
    final state = context.watch<NeuraRoomState>();
    final room = state.current;

    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.primaryContainer.withOpacity(0.9),
        borderRadius: BorderRadius.circular(999),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(room.icon, size: 16),
          const SizedBox(width: 6),
          Text(
            room.name,
            style: const TextStyle(
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }
}
