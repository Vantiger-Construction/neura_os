import 'package:flutter/foundation.dart';
import 'neura_rooms.dart';

class NeuraRoomState extends ChangeNotifier {
  NeuraRoomInfo _current = neuraRooms.first;

  NeuraRoomInfo get current => _current;

  void setRoom(NeuraRoomId id) {
    final found = neuraRooms.firstWhere(
      (r) => r.id == id,
      orElse: () => neuraRooms.first,
    );
    _current = found;
    notifyListeners();
  }

  void setByName(String name) {
    final lower = name.toLowerCase();
    final found = neuraRooms.firstWhere(
      (r) => r.name.toLowerCase() == lower,
      orElse: () => neuraRooms.first,
    );
    _current = found;
    notifyListeners();
  }
}
