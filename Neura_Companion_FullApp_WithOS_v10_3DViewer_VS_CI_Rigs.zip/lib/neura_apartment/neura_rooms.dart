import 'package:flutter/material.dart';

/// Enum of all Neura OS rooms used by the shell and apartment modules.
enum NeuraRoomId {
  penthouse,
  mood_den,
  dream_bay,
  reflection_bay,
  clinical_bay,
  legacy_hall,
  values,
}

class NeuraRoomInfo {
  final NeuraRoomId id;
  final String name;
  final IconData icon;
  final String description;

  const NeuraRoomInfo({
    required this.id,
    required this.name,
    required this.icon,
    required this.description,
  });
}

/// Canonical list of rooms shown in room selectors and the OS shell.
const List<NeuraRoomInfo> neuraRooms = [
  NeuraRoomInfo(
    id: NeuraRoomId.penthouse,
    name: 'Penthouse',
    icon: Icons.home,
    description: 'Neura\'s main hub where she greets you.',
  ),
  NeuraRoomInfo(
    id: NeuraRoomId.mood_den,
    name: 'Mood Den',
    icon: Icons.mood,
    description: 'A cosy space for quick mood and grounding rituals.',
  ),
  NeuraRoomInfo(
    id: NeuraRoomId.dream_bay,
    name: 'Dream Bay',
    icon: Icons.nightlight_round,
    description: 'Dream visualiser, sleep journaling, and nightly recaps.',
  ),
  NeuraRoomInfo(
    id: NeuraRoomId.reflection_bay,
    name: 'Reflection Bay',
    icon: Icons.self_improvement,
    description: 'Deep reflections, journaling, and Mirror Mode recaps.',
  ),
  NeuraRoomInfo(
    id: NeuraRoomId.clinical_bay,
    name: 'Clinical Bay',
    icon: Icons.health_and_safety,
    description: 'Structured check-ins you can share with a clinician.',
  ),
  NeuraRoomInfo(
    id: NeuraRoomId.legacy_hall,
    name: 'Legacy Hall',
    icon: Icons.auto_stories,
    description: 'Messages, memories, and legacy notes for loved ones.',
  ),
  NeuraRoomInfo(
    id: NeuraRoomId.values,
    name: 'Values Lab',
    icon: Icons.favorite,
    description: 'Your core values, needs, and comfort strategies.',
  ),
];
