import 'package:flutter/foundation.dart';
import '../neura_avatar/neura_avatar_mood.dart';

/// High-level category of a ritual.
enum NeuraRitualType {
  mind,
  body,
  soul,
  connection,
  custom,
}

/// Definition of a ritual template (what it is, not when it happened).
class NeuraRitualDefinition {
  NeuraRitualDefinition({
    required this.id,
    required this.title,
    required this.description,
    required this.type,
    this.suggestedTimeOfDay,
    this.icon,
    this.featured = false,
  });

  final String id;
  final String title;
  final String description;
  final NeuraRitualType type;

  /// A soft hint: "morning", "afternoon", "evening", or null.
  final String? suggestedTimeOfDay;

  /// Optional Material icon name (you can map this in your UI).
  final String? icon;

  /// Whether this ritual should be highlighted by default.
  final bool featured;
}

/// One completion / attempt of a ritual.
class NeuraRitualLogEntry {
  NeuraRitualLogEntry({
    required this.id,
    required this.ritualId,
    required this.timestamp,
    required this.moodBefore,
    required this.moodAfter,
    this.note,
    this.success = true,
  });

  final String id;
  final String ritualId;
  final DateTime timestamp;
  final NeuraAvatarMood moodBefore;
  final NeuraAvatarMood moodAfter;
  final String? note;
  final bool success;

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'ritualId': ritualId,
      'timestamp': timestamp.toIso8601String(),
      'moodBefore': moodBefore.name,
      'moodAfter': moodAfter.name,
      'note': note,
      'success': success,
    };
  }

  static NeuraRitualLogEntry fromJson(Map<String, dynamic> json) {
    return NeuraRitualLogEntry(
      id: json['id'] as String,
      ritualId: json['ritualId'] as String,
      timestamp: DateTime.parse(json['timestamp'] as String),
      moodBefore: NeuraAvatarMood.values.firstWhere(
        (m) => m.name == json['moodBefore'],
        orElse: () => NeuraAvatarMood.neutral,
      ),
      moodAfter: NeuraAvatarMood.values.firstWhere(
        (m) => m.name == json['moodAfter'],
        orElse: () => NeuraAvatarMood.neutral,
      ),
      note: json['note'] as String?,
      success: json['success'] as bool? ?? true,
    );
  }
}

/// Lightweight summary for a single day: how many rituals were done.
class NeuraRitualDailySummary {
  NeuraRitualDailySummary({
    required this.date,
    required this.completed,
    required this.totalAvailable,
  });

  final DateTime date;
  final int completed;
  final int totalAvailable;
}
