import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../neura_avatar/neura_avatar_mood.dart';
import 'neura_ritual_models.dart';

/// Engine that tracks ritual definitions + completion logs.
///
/// For now, ritual definitions are seeded in code and not user-editable.
/// Logs are persisted via SharedPreferences, so streaks and history survive
/// across app restarts without needing a backend.
class NeuraRitualEngine extends ChangeNotifier {
  static const _logsKey = 'neura_ritual_logs_v1';

  final List<NeuraRitualDefinition> _rituals =
      List<NeuraRitualDefinition>.unmodifiable(_seedRituals);
  final List<NeuraRitualLogEntry> _logs = <NeuraRitualLogEntry>[];

  bool _loaded = false;

  bool get isLoaded => _loaded;
  List<NeuraRitualDefinition> get rituals => _rituals;
  List<NeuraRitualLogEntry> get logs => List.unmodifiable(_logs);

  Future<void> ensureLoaded() async {
    if (_loaded) return;
    await _loadLogs();
  }

  Future<void> _loadLogs() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_logsKey);
      if (raw == null || raw.isEmpty) {
        _logs.clear();
        _loaded = true;
        notifyListeners();
        return;
      }

      final decoded = jsonDecode(raw);
      if (decoded is! List) {
        _logs.clear();
        _loaded = true;
        notifyListeners();
        return;
      }

      _logs
        ..clear()
        ..addAll(
          decoded
              .whereType<Map<String, dynamic>>()
              .map(NeuraRitualLogEntry.fromJson),
        );
      _loaded = true;
      notifyListeners();
    } catch (e) {
      debugPrint('[NeuraRitualEngine] Failed to load logs: $e');
      _logs.clear();
      _loaded = true;
      notifyListeners();
    }
  }

  Future<void> _saveLogs() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final list = _logs.map((e) => e.toJson()).toList();
      await prefs.setString(_logsKey, jsonEncode(list));
    } catch (e) {
      debugPrint('[NeuraRitualEngine] Failed to save logs: $e');
    }
  }

  /// Log a ritual completion.
  Future<void> logCompletion({
    required NeuraRitualDefinition ritual,
    required NeuraAvatarMood moodBefore,
    required NeuraAvatarMood moodAfter,
    String? note,
    DateTime? timestamp,
  }) async {
    await ensureLoaded();
    final now = timestamp ?? DateTime.now();

    final entry = NeuraRitualLogEntry(
      id: now.millisecondsSinceEpoch.toString(),
      ritualId: ritual.id,
      timestamp: now,
      moodBefore: moodBefore,
      moodAfter: moodAfter,
      note: note,
      success: true,
    );

    _logs.add(entry);
    _logs.sort((a, b) => b.timestamp.compareTo(a.timestamp));

    notifyListeners();
    await _saveLogs();
  }

  /// Logs for a specific day.
  List<NeuraRitualLogEntry> logsForDay(DateTime day) {
    if (!_loaded) return const [];
    return _logs.where((e) => _sameDate(e.timestamp, day)).toList();
  }

  /// Logs for a specific ritual id.
  List<NeuraRitualLogEntry> logsForRitual(String ritualId) {
    if (!_loaded) return const [];
    return _logs.where((e) => e.ritualId == ritualId).toList();
  }

  /// Daily summary for the given day.
  NeuraRitualDailySummary dailySummary(DateTime day) {
    final logs = logsForDay(day);
    // For now, "totalAvailable" is just the number of defined rituals.
    return NeuraRitualDailySummary(
      date: DateTime(day.year, day.month, day.day),
      completed: logs.length,
      totalAvailable: _rituals.length,
    );
  }

  /// Crude streak: how many consecutive days (ending today) have >=1 log.
  int currentStreak() {
    if (!_loaded || _logs.isEmpty) return 0;

    final today = DateTime.now();
    var streak = 0;

    DateTime cursor = DateTime(today.year, today.month, today.day);

    while (true) {
      final hasLogs = _logs.any((e) => _sameDate(e.timestamp, cursor));
      if (!hasLogs) break;
      streak++;
      cursor = cursor.subtract(const Duration(days: 1));
    }

    return streak;
  }

  bool _sameDate(DateTime a, DateTime b) {
    return a.year == b.year && a.month == b.month && a.day == b.day;
  }
}

// ---------------------------------------------------------------------------
// Seed rituals
// ---------------------------------------------------------------------------

final List<NeuraRitualDefinition> _seedRituals = <NeuraRitualDefinition>[
  NeuraRitualDefinition(
    id: 'morning_grounding',
    title: 'Morning Grounding',
    description:
        '2–3 minutes to breathe, stretch, and name one thing you care about today.',
    type: NeuraRitualType.mind,
    suggestedTimeOfDay: 'morning',
    icon: 'self_improvement',
    featured: true,
  ),
  NeuraRitualDefinition(
    id: 'body_check',
    title: 'Body Check',
    description:
        'Scan from head to toes, relax tension, and take a sip of water.',
    type: NeuraRitualType.body,
    suggestedTimeOfDay: 'afternoon',
    icon: 'fitness_center',
    featured: false,
  ),
  NeuraRitualDefinition(
    id: 'evening_reset',
    title: 'Evening Reset',
    description:
        'Review one win, one lesson, and one thing to gently let go before sleep.',
    type: NeuraRitualType.soul,
    suggestedTimeOfDay: 'evening',
    icon: 'bedtime',
    featured: true,
  ),
  NeuraRitualDefinition(
    id: 'reach_out',
    title: 'Reach Out',
    description:
        'Send a kind message or check in with someone you care about.',
    type: NeuraRitualType.connection,
    suggestedTimeOfDay: 'any',
    icon: 'chat_bubble',
    featured: false,
  ),
  NeuraRitualDefinition(
    id: 'micro_walk',
    title: 'Micro Walk',
    description:
        'Walk for 3–5 minutes, notice your surroundings, and take one deeper breath.',
    type: NeuraRitualType.body,
    suggestedTimeOfDay: 'afternoon',
    icon: 'directions_walk',
    featured: false,
  ),
];
