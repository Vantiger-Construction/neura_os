import "package:flutter/material.dart";
import "../services/care_mode_service.dart";

class CareModeDashboardCard extends StatefulWidget {
  final VoidCallback onTapOpen;

  const CareModeDashboardCard({
    Key? key,
    required this.onTapOpen,
  }) : super(key: key);

  @override
  State<CareModeDashboardCard> createState() =>
      _CareModeDashboardCardState();
}

class _CareModeDashboardCardState extends State<CareModeDashboardCard> {
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    await CareModeService.instance.load();
    setState(() {
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final state = CareModeService.instance.state;

    return GestureDetector(
      onTap: widget.onTapOpen,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.45),
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withOpacity(0.12)),
        ),
        padding: const EdgeInsets.all(12),
        child: _loading
            ? const Center(
                child: SizedBox(
                  height: 18,
                  width: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
              )
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    "Care Mode",
                    style: TextStyle(
                      fontSize: 13,
                      fontWeight: FontWeight.bold,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    state.enabled ? "ON · watching storms" : "OFF",
                    style: TextStyle(
                      fontSize: 11,
                      color: state.enabled
                          ? Colors.greenAccent
                          : Colors.white70,
                    ),
                  ),
                  const SizedBox(height: 4),
                  Text(
                    "${state.contacts.length} trusted contact(s)",
                    style: const TextStyle(
                      fontSize: 11,
                      color: Colors.white70,
                    ),
                  ),
                  if (state.lastCrisisAt != null) ...[
                    const SizedBox(height: 4),
                    Text(
                      "Last crisis: ${state.lastCrisisAt!.toLocal().toString().split(".").first}",
                      style: const TextStyle(
                        fontSize: 10,
                        color: Colors.white54,
                      ),
                    ),
                  ],
                ],
              ),
      ),
    );
  }
}
