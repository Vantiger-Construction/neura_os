    import "package:flutter/material.dart";
    import "../models/trusted_contact.dart";
    import "../services/care_mode_service.dart";
    import "../../os/widgets/neura_shell_scaffold.dart";
    import "package:uuid/uuid.dart";

    class CareModeScreen extends StatefulWidget {
      const CareModeScreen({Key? key}) : super(key: key);

      @override
      State<CareModeScreen> createState() => _CareModeScreenState();
    }

    class _CareModeScreenState extends State<CareModeScreen> {
      bool _loading = true;
      final _uuid = const Uuid();

      @override
      void initState() {
        super.initState();
        _load();
      }

      Future<void> _load() async {
        await CareModeService.instance.load();
        setState(() {
          _loading = false;
        });
      }

      @override
      Widget build(BuildContext context) {
        if (_loading) {
          return const NeuraShellScaffold(
            appBar: null,
            body: Center(child: CircularProgressIndicator()),
          );
        }

        final state = CareModeService.instance.state;

        return NeuraShellScaffold(
          appBar: AppBar(
            title: const Text("Care Mode"),
          ),
          body: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              SwitchListTile(
                title: const Text("Care Mode enabled"),
                subtitle: const Text(
                    "When on, Neura treats you as "in care" and keeps a closer eye on storms."),
                value: state.enabled,
                onChanged: (value) async {
                  await CareModeService.instance.setEnabled(value);
                  setState(() {});
                },
              ),
              SwitchListTile(
                title: const Text("Auto After-Storm grounding"),
                subtitle: const Text(
                    "After big emotional spikes, gently offer grounding + reflection."),
                value: state.autoAfterStormPrompt,
                onChanged: (value) async {
                  await CareModeService.instance.setAutoAfterStormPrompt(value);
                  setState(() {});
                },
              ),
              const SizedBox(height: 16),
              const Text(
                "Trusted contacts",
                style: TextStyle(
                  fontSize: 14,
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 8),
              if (state.contacts.isEmpty)
                const Text(
                  "No trusted contacts yet.
Add at least one person Neura can highlight in your reflections.",
                  style: TextStyle(fontSize: 12, color: Colors.white70),
                ),
              const SizedBox(height: 8),
              ...state.contacts.map(_buildContactTile),
              const SizedBox(height: 12),
              Align(
                alignment: Alignment.centerLeft,
                child: ElevatedButton.icon(
                  icon: const Icon(Icons.person_add_alt_1),
                  label: const Text("Add trusted contact"),
                  onPressed: () async {
                    final newContact = await _showContactDialog(context);
                    if (newContact != null) {
                      await CareModeService.instance.addOrUpdateContact(
                        newContact.copyWith(id: _uuid.v4()),
                      );
                      setState(() {});
                    }
                  },
                ),
              ),
              const SizedBox(height: 24),
              if (state.lastCrisisAt != null) ...[
                const Text(
                  "Last recorded crisis",
                  style: TextStyle(
                    fontSize: 13,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 4),
                Text(
                  state.lastCrisisAt!.toLocal().toString(),
                  style: const TextStyle(fontSize: 12, color: Colors.white70),
                ),
              ],
            ],
          ),
        );
      }

      Widget _buildContactTile(TrustedContact c) {
        return Card(
          color: Colors.black.withOpacity(0.45),
          margin: const EdgeInsets.only(bottom: 8),
          child: ListTile(
            title: Text(c.name),
            subtitle: Text(
              "${c.relation} • ${c.phone}"
              "${c.email != null && c.email!.isNotEmpty ? " • ${c.email}" : ""}",
              style: const TextStyle(fontSize: 12),
            ),
            trailing: PopupMenuButton<String>(
              onSelected: (value) async {
                if (value == "edit") {
                  final updated = await _showContactDialog(context, existing: c);
                  if (updated != null) {
                    await CareModeService.instance.addOrUpdateContact(updated);
                    setState(() {});
                  }
                } else if (value == "delete") {
                  await CareModeService.instance.removeContact(c.id);
                  setState(() {});
                }
              },
              itemBuilder: (context) => [
                const PopupMenuItem(
                  value: "edit",
                  child: Text("Edit"),
                ),
                const PopupMenuItem(
                  value: "delete",
                  child: Text("Remove"),
                ),
              ],
            ),
          ),
        );
      }

      Future<TrustedContact?> _showContactDialog(BuildContext context,
          {TrustedContact? existing}) async {
        final nameCtrl = TextEditingController(text: existing?.name ?? "");
        final relCtrl = TextEditingController(text: existing?.relation ?? "");
        final phoneCtrl = TextEditingController(text: existing?.phone ?? "");
        final emailCtrl = TextEditingController(text: existing?.email ?? "");
        bool shareWeeklySnapshot = existing?.shareWeeklySnapshot ?? false;
        bool isEmergencyContact = existing?.isEmergencyContact ?? false;

        return showDialog<TrustedContact>(
          context: context,
          builder: (context) {
            return AlertDialog(
              title: Text(existing == null
                  ? "New trusted contact"
                  : "Edit trusted contact"),
              content: SingleChildScrollView(
                child: Column(
                  mainAxisSize: MainAxisSize.min,
                  children: [
                    TextField(
                      controller: nameCtrl,
                      decoration: const InputDecoration(
                        labelText: "Name",
                      ),
                    ),
                    TextField(
                      controller: relCtrl,
                      decoration: const InputDecoration(
                        labelText: "Relation",
                      ),
                    ),
                    TextField(
                      controller: phoneCtrl,
                      decoration: const InputDecoration(
                        labelText: "Phone",
                      ),
                    ),
                    TextField(
                      controller: emailCtrl,
                      decoration: const InputDecoration(
                        labelText: "Email (optional)",
                      ),
                    ),
                    const SizedBox(height: 8),
                    StatefulBuilder(
                      builder: (context, setLocal) {
                        return Column(
                          children: [
                            CheckboxListTile(
                              contentPadding: EdgeInsets.zero,
                              title: const Text(
                                "Include in Weekly Life Snapshot sharing",
                                style: TextStyle(fontSize: 12),
                              ),
                              value: shareWeeklySnapshot,
                              onChanged: (value) {
                                setLocal(() {
                                  shareWeeklySnapshot = value ?? false;
                                });
                              },
                            ),
                            CheckboxListTile(
                              contentPadding: EdgeInsets.zero,
                              title: const Text(
                                "Mark as emergency contact",
                                style: TextStyle(fontSize: 12),
                              ),
                              value: isEmergencyContact,
                              onChanged: (value) {
                                setLocal(() {
                                  isEmergencyContact = value ?? false;
                                });
                              },
                            ),
                          ],
                        );
                      },
                    ),
                  ],
                ),
              ),
              actions: [
                TextButton(
                  onPressed: () => Navigator.pop(context, null),
                  child: const Text("Cancel"),
                ),
                ElevatedButton(
                  onPressed: () {
                    if (nameCtrl.text.trim().isEmpty ||
                        phoneCtrl.text.trim().isEmpty) {
                      return;
                    }
                    final contact = TrustedContact(
                      id: existing?.id ?? "",
                      name: nameCtrl.text.trim(),
                      relation: relCtrl.text.trim(),
                      phone: phoneCtrl.text.trim(),
                      email: emailCtrl.text.trim().isEmpty
                          ? null
                          : emailCtrl.text.trim(),
                      shareWeeklySnapshot: shareWeeklySnapshot,
                      isEmergencyContact: isEmergencyContact,
                    );
                    Navigator.pop(context, contact);
                  },
                  child: const Text("Save"),
                ),
              ],
            );
          },
        );
      }
    }
