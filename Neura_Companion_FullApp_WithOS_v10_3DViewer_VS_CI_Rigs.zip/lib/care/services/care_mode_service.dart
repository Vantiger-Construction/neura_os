import "dart:convert";
import "package:shared_preferences/shared_preferences.dart";
import "../../insights/services/weekly_snapshot_service.dart";
import "../models/trusted_contact.dart";

class CareModeState {
  final bool enabled;
  final bool autoAfterStormPrompt;
  final List<TrustedContact> contacts;
  final List<String> crisisTags;
  final DateTime? lastCrisisAt;

  const CareModeState({
    required this.enabled,
    required this.autoAfterStormPrompt,
    required this.contacts,
    required this.crisisTags,
    required this.lastCrisisAt,
  });

  CareModeState copyWith({
    bool? enabled,
    bool? autoAfterStormPrompt,
    List<TrustedContact>? contacts,
    List<String>? crisisTags,
    DateTime? lastCrisisAt,
  }) {
    return CareModeState(
      enabled: enabled ?? this.enabled,
      autoAfterStormPrompt:
          autoAfterStormPrompt ?? this.autoAfterStormPrompt,
      contacts: contacts ?? this.contacts,
      crisisTags: crisisTags ?? this.crisisTags,
      lastCrisisAt: lastCrisisAt ?? this.lastCrisisAt,
    );
  }

  Map<String, dynamic> toJson() => {
        'enabled': enabled,
        'autoAfterStormPrompt': autoAfterStormPrompt,
        'contacts': contacts.map((c) => c.toJson()).toList(),
        'crisisTags': crisisTags,
        'lastCrisisAt': lastCrisisAt?.toIso8601String(),
      };

  factory CareModeState.fromJson(Map<String, dynamic> json) {
    final contactsJson =
        (json['contacts'] as List<dynamic>?) ?? const <dynamic>[];
    return CareModeState(
      enabled: json['enabled'] as bool? ?? false,
      autoAfterStormPrompt: json['autoAfterStormPrompt'] as bool? ?? true,
      contacts: contactsJson
          .whereType<Map<String, dynamic>>()
          .map(TrustedContact.fromJson)
          .toList(),
      crisisTags: (json['crisisTags'] as List<dynamic>?)
              ?.map((e) => e.toString())
              .toList() ??
          const <String>[],
      lastCrisisAt: json['lastCrisisAt'] != null
          ? DateTime.tryParse(json['lastCrisisAt'] as String)
          : null,
    );
  }

  static CareModeState initial() => const CareModeState(
        enabled: false,
        autoAfterStormPrompt: true,
        contacts: [],
        crisisTags: [],
        lastCrisisAt: null,
      );
}

/// Singleton service for Care Mode 2.0.
///
/// Stores trusted contacts, crisis tags, and integrates with AfterStorm and WeeklySnapshot.
class CareModeService {
  CareModeService._();
  static final CareModeService instance = CareModeService._();

  static const _storageKey = "neura_care_mode_state_v1";

  CareModeState _state = CareModeState.initial();
  CareModeState get state => _state;

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_storageKey);
    if (raw == null || raw.isEmpty) {
      _state = CareModeState.initial();
      return;
    }
    final jsonMap = json.decode(raw) as Map<String, dynamic>;
    _state = CareModeState.fromJson(jsonMap);
  }

  Future<void> _persist() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = json.encode(_state.toJson());
    await prefs.setString(_storageKey, raw);
  }

  Future<void> setEnabled(bool enabled) async {
    _state = _state.copyWith(enabled: enabled);
    await _persist();
  }

  Future<void> setAutoAfterStormPrompt(bool value) async {
    _state = _state.copyWith(autoAfterStormPrompt: value);
    await _persist();
  }

  Future<void> addOrUpdateContact(TrustedContact contact) async {
    final existingIndex =
        _state.contacts.indexWhere((c) => c.id == contact.id);
    final updatedContacts = [..._state.contacts];
    if (existingIndex >= 0) {
      updatedContacts[existingIndex] = contact;
    } else {
      updatedContacts.add(contact);
    }
    _state = _state.copyWith(contacts: updatedContacts);
    await _persist();
  }

  Future<void> removeContact(String id) async {
    final updatedContacts =
        _state.contacts.where((c) => c.id != id).toList();
    _state = _state.copyWith(contacts: updatedContacts);
    await _persist();
  }

  Future<void> logCrisisEvent(String tag) async {
    final tags = [..._state.crisisTags, tag];
    final now = DateTime.now();
    _state = _state.copyWith(
      crisisTags: tags,
      lastCrisisAt: now,
    );
    await _persist();
    // Also reflect this in the Weekly Snapshot engine so storms show up in summaries.
    await WeeklySnapshotService.instance.logDay(
      date: now,
      moodScore: 0.0, // will be overwritten by mood check-ins, this just marks the storm.
      stormsCount: 1,
      usedCareMode: true,
      note: 'Crisis event: ' + tag,
    );
  }
}