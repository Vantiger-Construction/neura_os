import 'package:flutter/foundation.dart';

/// Broad category of a legacy entry.
///
/// This is intentionally simple and human, not legal.
enum NeuraLegacyCategory {
  memory,       // A moment or story you want remembered.
  lesson,       // Something you learned the hard way.
  message,      // A letter to future-you or someone you care about.
  value,        // A core value / principle you live by.
  bucketList,   // Something you still want to do.
}

/// One "tile" in the Legacy Hall – a story, letter, value, etc.
class NeuraLegacyEntry {
  NeuraLegacyEntry({
    required this.id,
    required this.createdAt,
    required this.updatedAt,
    required this.category,
    required this.title,
    required this.body,
    this.tags = const [],
  });

  final String id;
  final DateTime createdAt;
  final DateTime updatedAt;
  final NeuraLegacyCategory category;
  final String title;
  final String body;
  final List<String> tags;

  NeuraLegacyEntry copyWith({
    DateTime? updatedAt,
    String? title,
    String? body,
    List<String>? tags,
    NeuraLegacyCategory? category,
  }) {
    return NeuraLegacyEntry(
      id: id,
      createdAt: createdAt,
      updatedAt: updatedAt ?? this.updatedAt,
      category: category ?? this.category,
      title: title ?? this.title,
      body: body ?? this.body,
      tags: tags ?? this.tags,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'createdAt': createdAt.toIso8601String(),
      'updatedAt': updatedAt.toIso8601String(),
      'category': category.name,
      'title': title,
      'body': body,
      'tags': tags,
    };
  }

  static NeuraLegacyEntry fromJson(Map<String, dynamic> json) {
    return NeuraLegacyEntry(
      id: json['id'] as String,
      createdAt: DateTime.parse(json['createdAt'] as String),
      updatedAt: DateTime.parse(json['updatedAt'] as String),
      category: NeuraLegacyCategory.values.firstWhere(
        (c) => c.name == (json['category'] as String? ?? 'memory'),
        orElse: () => NeuraLegacyCategory.memory,
      ),
      title: json['title'] as String? ?? 'Untitled',
      body: json['body'] as String? ?? '',
      tags: (json['tags'] as List<dynamic>?)
              ?.map((e) => e.toString())
              .toList() ??
          const [],
    );
  }
}
