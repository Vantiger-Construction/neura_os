import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import 'neura_legacy_models.dart';

/// Engine for the Legacy Hall – long-term stories, values, and messages.
///
/// This stores data *locally on the device* using SharedPreferences.
/// It is not a legal will or guaranteed archive. Users should keep
/// their own backups if something is truly critical.
class NeuraLegacyEngine extends ChangeNotifier {
  static const _storageKey = 'neura_legacy_entries_v1';

  final List<NeuraLegacyEntry> _entries = <NeuraLegacyEntry>[];
  bool _loaded = false;

  bool get isLoaded => _loaded;
  List<NeuraLegacyEntry> get entries => List.unmodifiable(_entries);

  Future<void> ensureLoaded() async {
    if (_loaded) return;
    await _loadFromStorage();
  }

  Future<void> _loadFromStorage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_storageKey);
      if (raw == null || raw.isEmpty) {
        _entries.clear();
        _loaded = true;
        notifyListeners();
        return;
      }

      final decoded = jsonDecode(raw);
      if (decoded is! List) {
        _entries.clear();
        _loaded = true;
        notifyListeners();
        return;
      }

      _entries
        ..clear()
        ..addAll(
          decoded
              .whereType<Map<String, dynamic>>()
              .map(NeuraLegacyEntry.fromJson),
        );
      _entries.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
      _loaded = true;
      notifyListeners();
    } catch (e) {
      debugPrint('[NeuraLegacyEngine] Failed to load: $e');
      _entries.clear();
      _loaded = true;
      notifyListeners();
    }
  }

  Future<void> _saveToStorage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final list = _entries.map((e) => e.toJson()).toList();
      await prefs.setString(_storageKey, jsonEncode(list));
    } catch (e) {
      debugPrint('[NeuraLegacyEngine] Failed to save: $e');
    }
  }

  Future<void> upsertEntry(NeuraLegacyEntry entry) async {
    await ensureLoaded();
    final index = _entries.indexWhere((e) => e.id == entry.id);
    if (index >= 0) {
      _entries[index] = entry;
    } else {
      _entries.add(entry);
    }
    _entries.sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
    notifyListeners();
    await _saveToStorage();
  }

  Future<void> deleteEntry(String id) async {
    await ensureLoaded();
    _entries.removeWhere((e) => e.id == id);
    notifyListeners();
    await _saveToStorage();
  }

  List<NeuraLegacyEntry> entriesByCategory(NeuraLegacyCategory category) {
    if (!_loaded) return const [];
    return _entries
        .where((e) => e.category == category)
        .toList()
      ..sort((a, b) => b.updatedAt.compareTo(a.updatedAt));
  }

  NeuraLegacyEntry? latestEntry() {
    if (!_loaded || _entries.isEmpty) return null;
    return _entries.first;
  }

  int get totalCount => _entries.length;

  DateTime? get lastUpdatedAt =>
      _entries.isEmpty ? null : _entries.first.updatedAt;
}
