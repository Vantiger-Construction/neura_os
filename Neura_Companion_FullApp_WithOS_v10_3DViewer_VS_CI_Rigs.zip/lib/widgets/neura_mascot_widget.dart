import 'dart:math';

import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

/// Lightweight Neura mascot widget.
/// Uses Lottie animations when available, falls back to a simple icon.
class NeuraMascotWidget extends StatefulWidget {
  final double size;

  const NeuraMascotWidget({super.key, this.size = 160});

  @override
  State<NeuraMascotWidget> createState() => _NeuraMascotWidgetState();
}

class _NeuraMascotWidgetState extends State<NeuraMascotWidget> {
  static const _lottieAnimations = [
    'assets/neura/lottie/neura_idle_blink.json',
    'assets/neura/lottie/neura_idle_breath.json',
    'assets/neura/lottie/neura_talking_viseme_loop.json',
    'assets/neura/lottie/neura_look_left_right.json',
  ];

  late String _currentAsset;

  @override
  void initState() {
    super.initState();
    _currentAsset = _lottieAnimations.first;
  }

  void _shuffleAnimation() {
    setState(() {
      _currentAsset = (_lottieAnimations.toList()..shuffle()).first;
    });
  }

  @override
  Widget build(BuildContext context) {
    final size = widget.size;

    return GestureDetector(
      onTap: _shuffleAnimation,
      child: SizedBox(
        width: size,
        height: size,
        child: Lottie.asset(
          _currentAsset,
          repeat: true,
          fit: BoxFit.contain,
        ),
      ),
    );
  }
}
