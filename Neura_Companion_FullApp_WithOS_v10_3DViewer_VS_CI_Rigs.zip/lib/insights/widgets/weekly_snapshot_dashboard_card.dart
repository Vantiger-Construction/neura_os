import 'package:flutter/material.dart';
import '../services/weekly_snapshot_service.dart';
import '../models/weekly_snapshot_entry.dart';

class WeeklySnapshotDashboardCard extends StatefulWidget {
  final VoidCallback onTapOpen;

  const WeeklySnapshotDashboardCard({
    Key? key,
    required this.onTapOpen,
  }) : super(key: key);

  @override
  State<WeeklySnapshotDashboardCard> createState() => _WeeklySnapshotDashboardCardState();
}

class _WeeklySnapshotDashboardCardState extends State<WeeklySnapshotDashboardCard> {
  bool _loading = true;
  WeeklySnapshotEntry? _latest;

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final svc = WeeklySnapshotService.instance;
    await svc.load();
    final history = svc.history;
    setState(() {
      _latest = history.isNotEmpty ? history.last : null;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: widget.onTapOpen,
      child: Container(
        decoration: BoxDecoration(
          color: Colors.black.withOpacity(0.45),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(color: Colors.white.withOpacity(0.12)),
        ),
        padding: const EdgeInsets.all(12),
        child: _loading
            ? const Center(
                child: SizedBox(
                  height: 18,
                  width: 18,
                  child: CircularProgressIndicator(strokeWidth: 2),
                ),
              )
            : _buildContent(),
      ),
    );
  }

  Widget _buildContent() {
    if (_latest == null) {
      return const Text(
        'Weekly snapshot\nNo data yet',
        style: TextStyle(fontSize: 12),
      );
    }
    final e = _latest!;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        const Text(
          'Weekly Snapshot',
          style: TextStyle(
            fontSize: 13,
            fontWeight: FontWeight.bold,
          ),
        ),
        const SizedBox(height: 4),
        Text(
          'Mood ${(e.avgMood * 100).round()}% • Energy ${(e.avgEnergy * 100).round()}%',
          style: const TextStyle(fontSize: 11, color: Colors.white70),
        ),
        const SizedBox(height: 2),
        Text(
          'Rituals ${e.ritualsCompleted} • Goals ${e.goalsProgressed}',
          style: const TextStyle(fontSize: 11, color: Colors.white70),
        ),
      ],
    );
  }
}
