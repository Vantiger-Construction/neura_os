
import 'dart:math';

import 'neura_values_profile.dart';
import 'neura_weekly_snapshot.dart';
import 'neura_values_alignment.dart';
import 'neura_focus_modes.dart';

import '../neura_core/neura_telemetry.dart';
import 'neura_session_engine.dart';
import 'neura_weekly_snapshot.dart' as weekly;
import 'neura_weekly_snapshot.dart';

/// Types of values-aligned suggestions Neura can make.
enum NeuraValueAlignedSuggestionType {
  journal,
  ritual,
  session,
  goodDeed,
  microAction,
}

class NeuraValueAlignedSuggestion {
  final String id;
  final String title;
  final String description;
  final String primaryValueId;
  final NeuraValueAlignedSuggestionType type;

  /// Optional payload used to invoke something specific:
  /// - session id for session suggestions
  /// - ritual id for ritual suggestions
  /// - category for good-deed suggestions
  final String? payload;

  const NeuraValueAlignedSuggestion({
    required this.id,
    required this.title,
    required this.description,
    required this.primaryValueId,
    required this.type,
    this.payload,
  });
}

/// Engine that generates a small set of value-aligned suggestions for
/// "today", using values + last week's snapshot.
class NeuraValuesActionEngine {
  NeuraValuesActionEngine._();

  static final NeuraValuesActionEngine instance =
      NeuraValuesActionEngine._();

  /// Generate suggestions for right now.
  ///
  /// - `maxSuggestions` controls how many items (default 4–5).
  /// - Uses the latest weekly snapshot if not supplied.
  List<NeuraValueAlignedSuggestion> generateTodaySuggestions({
    int maxSuggestions = 4,
    NeuraWeeklySnapshot? snapshotOverride,
  }) {
    final valuesProfile = NeuraValuesService.instance.profile;
    if (valuesProfile.isEmpty) return const [];

    final snapshot = snapshotOverride ??
        (NeuraWeeklySnapshotService.instance
                .computeRecentWeeks(weeks: 1)
                .isNotEmpty
            ? NeuraWeeklySnapshotService.instance
                .computeRecentWeeks(weeks: 1)
                .first
            : null);
    if (snapshot == null) return const [];

    final alignment = NeuraValuesAlignmentCalculator.estimateAlignment(
      profile: valuesProfile,
      snapshot: snapshot,
    );

    final suggestions = <NeuraValueAlignedSuggestion>[];

    final topValues = valuesProfile.topN(4);
    final rand = Random();

    for (final valueId in topValues) {
      final valueMeta = NeuraDefaultValuesLibrary.byId(valueId);
      if (valueMeta == null) continue;

      final alignedScore = alignment.perValueScore[valueId] ?? 0.5;

      // If alignment is low, we bias towards suggestions.
      if (alignedScore < 0.85 || suggestions.isEmpty) {
        suggestions.addAll(_buildSuggestionsForValue(
          valueId: valueId,
          label: valueMeta.label,
          snapshot: snapshot,
        ));
      }
    }

    // Shuffle to avoid feeling robotic.
    suggestions.shuffle(rand);

    if (suggestions.length > maxSuggestions) {
      return suggestions.sublist(0, maxSuggestions);
    }
    return suggestions;
  }

  List<NeuraValueAlignedSuggestion> _buildSuggestionsForValue({
    required String valueId,
    required String label,
    required NeuraWeeklySnapshot snapshot,
  }) {
    switch (valueId) {
      case 'kindness':
      case 'contribution':
        return [
          NeuraValueAlignedSuggestion(
            id: 'good_deed_plan_$valueId',
            title: 'Plan a small act of $label',
            description:
                'Pick one person you could support or encourage today. '
                'Neura can help you log it as a Good Deed later.',
            primaryValueId: valueId,
            type: NeuraValueAlignedSuggestionType.goodDeed,
            payload: 'kindness',
          ),
          NeuraValueAlignedSuggestion(
            id: 'journal_on_$valueId',
            title: 'Reflect on $label',
            description:
                'Take 2 minutes in your journal to write about a time you '
                'lived this value recently—or wish you had.',
            primaryValueId: valueId,
            type: NeuraValueAlignedSuggestionType.journal,
          ),
        ];
      case 'growth':
        return [
          NeuraValueAlignedSuggestion(
            id: 'session_growth_deep_work',
            title: 'Run a Deep Work Sprint',
            description:
                'Give yourself 25–30 focused minutes on one meaningful task. '
                'Neura will handle the Deep Work session flow.',
            primaryValueId: valueId,
            type: NeuraValueAlignedSuggestionType.session,
            payload: 'deep_work_sprint',
          ),
          NeuraValueAlignedSuggestion(
            id: 'journal_growth_edge',
            title: 'Journal: Growth Edge',
            description:
                'Write about one skill or area you'd like to grow in this week. '
                'What is a tiny action you can take today?',
            primaryValueId: valueId,
            type: NeuraValueAlignedSuggestionType.journal,
          ),
        ];
      case 'health':
        return [
          NeuraValueAlignedSuggestion(
            id: 'ritual_health_breath',
            title: '2-Minute Reset for Health',
            description:
                'Run a short calming breath ritual to give your nervous system '
                'a tiny break.',
            primaryValueId: valueId,
            type: NeuraValueAlignedSuggestionType.ritual,
            payload: 'calming_breath_2min',
          ),
          NeuraValueAlignedSuggestion(
            id: 'journal_health_checkin',
            title: 'Body & Mind Check-In',
            description:
                'In your journal, note one thing your body is asking for '
                'today (rest, water, movement, food, connection).',
            primaryValueId: valueId,
            type: NeuraValueAlignedSuggestionType.journal,
          ),
        ];
      case 'creativity':
        return [
          NeuraValueAlignedSuggestion(
            id: 'micro_creative_block',
            title: '10-Minute Creative Block',
            description:
                'Block out 10 minutes to doodle, write, play music, or '
                'explore an idea—no pressure to be good.',
            primaryValueId: valueId,
            type: NeuraValueAlignedSuggestionType.microAction,
          ),
          NeuraValueAlignedSuggestion(
            id: 'journal_creative_idea',
            title: 'Capture a Creative Idea',
            description:
                'Use your journal to record one idea you've been putting off '
                'or ignoring. No editing, just capture.',
            primaryValueId: valueId,
            type: NeuraValueAlignedSuggestionType.journal,
          ),
        ];
      case 'family':
        return [
          NeuraValueAlignedSuggestion(
            id: 'good_deed_family_reachout',
            title: 'Reach Out to Family',
            description:
                'Message or call a family member just to check in and say hi. '
                'You can log it as a Good Deed if it feels right.',
            primaryValueId: valueId,
            type: NeuraValueAlignedSuggestionType.goodDeed,
            payload: 'family',
          ),
        ];
      case 'adventure':
        return [
          NeuraValueAlignedSuggestion(
            id: 'micro_adventure',
            title: 'Plan a Tiny Adventure',
            description:
                'Pick something small-but-new you can do this week '
                '(a route, a café, a park, a hobby).',
            primaryValueId: valueId,
            type: NeuraValueAlignedSuggestionType.microAction,
          ),
        ];
      case 'stability':
        return [
          NeuraValueAlignedSuggestion(
            id: 'micro_stability_action',
            title: '10 Minutes on Foundations',
            description:
                'Do one small action that makes life more stable: '
                'tidy a hotspot, pay a bill, organize a folder.',
            primaryValueId: valueId,
            type: NeuraValueAlignedSuggestionType.microAction,
          ),
        ];
      default:
        return [];
    }
  }
}
