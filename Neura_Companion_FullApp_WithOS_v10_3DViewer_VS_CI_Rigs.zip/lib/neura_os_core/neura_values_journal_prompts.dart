
import 'neura_values_profile.dart';
import 'neura_weekly_snapshot.dart';
import 'neura_values_alignment.dart';

/// Builds a small set of journal prompts based on values + last week.
class NeuraValuesJournalPrompts {
  static List<String> buildPrompts({
    required NeuraValuesProfile profile,
    NeuraWeeklySnapshot? snapshot,
  }) {
    if (profile.isEmpty) return const [];

    final prompts = <String>[];
    final topValues = profile.topN(3);

    if (snapshot != null) {
      final alignment = NeuraValuesAlignmentCalculator.estimateAlignment(
        profile: profile,
        snapshot: snapshot,
      );

      for (final id in topValues) {
        final valueMeta = NeuraDefaultValuesLibrary.byId(id);
        if (valueMeta == null) continue;

        final label = valueMeta.label;
        final score = alignment.perValueScore[id] ?? 0.5;

        if (score < 0.5) {
          prompts.add(
            'You value $label, but last week didn't seem to reflect it '
            'as much as you might like. What got in the way?',
          );
        } else if (score > 0.8) {
          prompts.add(
            'You lived your value of $label strongly last week. '
            'What did you do that you're proud of?',
          );
        } else {
          prompts.add(
            'In what small ways did you live your value of $label last week?',
          );
        }
      }
    } else {
      for (final id in topValues) {
        final valueMeta = NeuraDefaultValuesLibrary.byId(id);
        if (valueMeta == null) continue;
        final label = valueMeta.label;
        prompts.add('What would a $label-focused day look like for you?');
      }
    }

    return prompts;
  }
}
