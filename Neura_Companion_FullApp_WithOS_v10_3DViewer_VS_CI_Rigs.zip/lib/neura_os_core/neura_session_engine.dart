
import 'dart:async';

import '../neura_core/neura_telemetry.dart';
import 'neura_focus_modes.dart';
import 'neura_module_registry.dart';
import 'neura_status_center.dart';

/// Types of steps supported in a guided session.
enum NeuraSessionStepType {
  setFocusMode,
  startRitual,
  journalPrompt,
  goodDeedPrompt,
  smartHomeScene,
  messageOnly,
}

class NeuraSessionStep {
  final NeuraSessionStepType type;
  final String? label;
  final String? payload; // used for ritual id, scene id, etc.

  const NeuraSessionStep({
    required this.type,
    this.label,
    this.payload,
  });
}

class NeuraGuidedSession {
  final String id;
  final String title;
  final String description;
  final List<NeuraSessionStep> steps;
  final Duration? suggestedDuration; // approximate length

  const NeuraGuidedSession({
    required this.id,
    required this.title,
    required this.description,
    required this.steps,
    this.suggestedDuration,
  });
}

/// Tracks current running session state.
class NeuraSessionRunState {
  final NeuraGuidedSession? session;
  final int currentIndex;
  final bool isRunning;

  const NeuraSessionRunState({
    required this.session,
    required this.currentIndex,
    required this.isRunning,
  });

  NeuraSessionRunState.initial()
      : session = null,
        currentIndex = 0,
        isRunning = false;

  NeuraSessionRunState copyWith({
    NeuraGuidedSession? session,
    int? currentIndex,
    bool? isRunning,
  }) {
    return NeuraSessionRunState(
      session: session ?? this.session,
      currentIndex: currentIndex ?? this.currentIndex,
      isRunning: isRunning ?? this.isRunning,
    );
  }
}

/// Engine to run guided sessions.
class NeuraSessionEngine {
  NeuraSessionEngine._();

  static final NeuraSessionEngine instance = NeuraSessionEngine._();

  final Map<String, NeuraGuidedSession> _sessions = {};
  NeuraSessionRunState _state = NeuraSessionRunState.initial();

  NeuraSessionRunState get state => _state;
  List<NeuraGuidedSession> get allSessions =>
      _sessions.values.toList(growable: false);

  void registerSession(NeuraGuidedSession session) {
    _sessions[session.id] = session;
  }

  void registerAll(Iterable<NeuraGuidedSession> sessions) {
    for (final s in sessions) {
      registerSession(s);
    }
  }

  NeuraGuidedSession? getSession(String id) => _sessions[id];

  /// Starts a session from the beginning.
  Future<void> startSession(String id) async {
    final session = _sessions[id];
    if (session == null) {
      throw ArgumentError('No session with id $id');
    }
    _state = NeuraSessionRunState(
      session: session,
      currentIndex: 0,
      isRunning: true,
    );
    NeuraTelemetryService.instance.log('session_started', {
      'id': session.id,
      'title': session.title,
    });
    await _runCurrentStep();
  }

  /// Moves to the next step and executes it.
  Future<void> nextStep() async {
    if (_state.session == null || !_state.isRunning) return;
    final session = _state.session!;
    final nextIndex = _state.currentIndex + 1;
    if (nextIndex >= session.steps.length) {
      // Finished.
      NeuraTelemetryService.instance.log('session_completed', {
        'id': session.id,
        'title': session.title,
      });
      _state = NeuraSessionRunState.initial();
      return;
    }
    _state = _state.copyWith(currentIndex: nextIndex);
    await _runCurrentStep();
  }

  /// Stops the current session.
  void stop() {
    if (_state.session != null && _state.isRunning) {
      NeuraTelemetryService.instance.log('session_stopped', {
        'id': _state.session!.id,
        'title': _state.session!.title,
      });
    }
    _state = NeuraSessionRunState.initial();
  }

  Future<void> _runCurrentStep() async {
    final s = _state.session;
    if (s == null || !_state.isRunning) return;
    if (_state.currentIndex < 0 || _state.currentIndex >= s.steps.length) {
      return;
    }
    final step = s.steps[_state.currentIndex];
    final modules = NeuraModuleRegistry.instance;
    final focus = NeuraFocusModeController.instance;
    final status = NeuraStatusCenter.instance;

    NeuraTelemetryService.instance.log('session_step', {
      'session_id': s.id,
      'index': _state.currentIndex,
      'type': step.type.toString(),
      'label': step.label,
      'payload': step.payload,
    });

    switch (step.type) {
      case NeuraSessionStepType.setFocusMode:
        final mode = _parseFocusMode(step.payload);
        await focus.setMode(mode);
        break;
      case NeuraSessionStepType.startRitual:
        if (step.payload != null) {
          await modules.startRitual(step.payload!);
        }
        break;
      case NeuraSessionStepType.journalPrompt:
        // You can wire this to navigate to journal or show a prompt.
        // For now we just log it; UI can read state.session + index to show text.
        break;
      case NeuraSessionStepType.goodDeedPrompt:
        // Same idea: UI decides how to render, engine logs intent.
        break;
      case NeuraSessionStepType.smartHomeScene:
        if (step.payload != null) {
          await modules.smartHomeAction(
            deviceIdOrScene: step.payload!,
            payload: const {},
          );
        }
        break;
      case NeuraSessionStepType.messageOnly:
        // UI-only; engine logs but no side effect.
        break;
    }

    // You can add minor side-effects based on step type, e.g. status tweaks.
    status.setActiveRitual(step.type == NeuraSessionStepType.startRitual
        ? step.payload
        : status.activeRitualId);
  }

  NeuraFocusMode _parseFocusMode(String? payload) {
    switch (payload) {
      case 'deep_work':
        return NeuraFocusMode.deepWork;
      case 'reflection':
        return NeuraFocusMode.reflection;
      case 'social':
        return NeuraFocusMode.social;
      case 'wind_down':
        return NeuraFocusMode.windDown;
      case 'normal':
      default:
        return NeuraFocusMode.normal;
    }
  }
}
