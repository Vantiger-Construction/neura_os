import 'package:flutter/foundation.dart';

/// High-level "mode" Neura thinks the user is in.
/// This is intentionally small and generic so any module can reuse it.
enum NeuraFocusMode {
  normal,
  deepWork,
  reflection,
  social,
  windDown,
}

extension NeuraFocusModeX on NeuraFocusMode {
  String get id {
    switch (this) {
      case NeuraFocusMode.deepWork:
        return 'deep_work';
      case NeuraFocusMode.reflection:
        return 'reflection';
      case NeuraFocusMode.social:
        return 'social';
      case NeuraFocusMode.windDown:
        return 'wind_down';
      case NeuraFocusMode.normal:
      default:
        return 'normal';
    }
  }

  String get label {
    switch (this) {
      case NeuraFocusMode.deepWork:
        return 'Deep Work';
      case NeuraFocusMode.reflection:
        return 'Reflection';
      case NeuraFocusMode.social:
        return 'Social / Connection';
      case NeuraFocusMode.windDown:
        return 'Wind Down';
      case NeuraFocusMode.normal:
      default:
        return 'Everyday';
    }
  }
}

/// Simple global controller so the rest of the OS can flip modes.
class NeuraFocusModeController extends ChangeNotifier {
  NeuraFocusModeController._();

  static final NeuraFocusModeController instance =
      NeuraFocusModeController._();

  NeuraFocusMode _mode = NeuraFocusMode.normal;

  NeuraFocusMode get mode => _mode;

  void setMode(NeuraFocusMode mode) {
    if (mode == _mode) return;
    _mode = mode;
    notifyListeners();
  }
}
