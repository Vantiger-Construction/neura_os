
import 'dart:core';

import 'neura_session_engine.dart';

/// Returns a list of default guided sessions for Neura Companion.
List<NeuraGuidedSession> buildDefaultNeuraSessions() {
  return [
    NeuraGuidedSession(
      id: 'morning_launch',
      title: 'Morning Launch',
      description: 'Start your day with intention, a quick check-in, '
          'and a tiny act of kindness.',
      suggestedDuration: const Duration(minutes: 10),
      steps: const [
        NeuraSessionStep(
          type: NeuraSessionStepType.setFocusMode,
          payload: 'normal',
          label: 'Set to Normal mode',
        ),
        NeuraSessionStep(
          type: NeuraSessionStepType.messageOnly,
          label: 'Welcome to a new day. Let's set one small intention.',
        ),
        NeuraSessionStep(
          type: NeuraSessionStepType.journalPrompt,
          label: 'What's one thing you want to feel proud of tonight?',
        ),
        NeuraSessionStep(
          type: NeuraSessionStepType.startRitual,
          payload: 'calming_breath_2min',
          label: '2-minute grounding breath',
        ),
        NeuraSessionStep(
          type: NeuraSessionStepType.goodDeedPrompt,
          label: 'Plan one kind thing you can do for someone today.',
        ),
      ],
    ),
    NeuraGuidedSession(
      id: 'deep_work_sprint',
      title: 'Deep Work Sprint',
      description: 'Drop into focus with a short ritual and a clear target.',
      suggestedDuration: const Duration(minutes: 30),
      steps: const [
        NeuraSessionStep(
          type: NeuraSessionStepType.setFocusMode,
          payload: 'deep_work',
          label: 'Switch to Deep Work mode',
        ),
        NeuraSessionStep(
          type: NeuraSessionStepType.messageOnly,
          label: 'Pick ONE task that really matters for the next 30 minutes.',
        ),
        NeuraSessionStep(
          type: NeuraSessionStepType.startRitual,
          payload: 'focus_breath_90s',
          label: '90-second focus priming ritual',
        ),
        NeuraSessionStep(
          type: NeuraSessionStepType.messageOnly,
          label: 'Silence optional distractions. Neura will keep track.',
        ),
      ],
    ),
    NeuraGuidedSession(
      id: 'reflection_micro',
      title: 'Reflection Micro-Session',
      description: 'A small pause to notice what's happening inside.',
      suggestedDuration: const Duration(minutes: 5),
      steps: const [
        NeuraSessionStep(
          type: NeuraSessionStepType.setFocusMode,
          payload: 'reflection',
          label: 'Switch to Reflection mode',
        ),
        NeuraSessionStep(
          type: NeuraSessionStepType.journalPrompt,
          label: 'What emotion is loudest right now? Name it.',
        ),
        NeuraSessionStep(
          type: NeuraSessionStepType.journalPrompt,
          label: 'What does that emotion seem to be protecting?',
        ),
      ],
    ),
    NeuraGuidedSession(
      id: 'wind_down_night',
      title: 'Wind Down Night',
      description: 'Slow down, soften, and prepare your mind for sleep.',
      suggestedDuration: const Duration(minutes: 15),
      steps: const [
        NeuraSessionStep(
          type: NeuraSessionStepType.setFocusMode,
          payload: 'wind_down',
          label: 'Switch to Wind Down mode',
        ),
        NeuraSessionStep(
          type: NeuraSessionStepType.smartHomeScene,
          payload: 'wind_down_scene',
          label: 'Dim lights and soften environment',
        ),
        NeuraSessionStep(
          type: NeuraSessionStepType.startRitual,
          payload: 'evening_gratitude_3',
          label: '3-point gratitude reflection',
        ),
        NeuraSessionStep(
          type: NeuraSessionStepType.journalPrompt,
          label: 'What is one thing you can let go of before sleep?',
        ),
      ],
    ),
  ];
}

/// Helper to register the defaults at startup.
void registerDefaultNeuraSessions() {
  final engine = NeuraSessionEngine.instance;
  engine.registerAll(buildDefaultNeuraSessions());
}
