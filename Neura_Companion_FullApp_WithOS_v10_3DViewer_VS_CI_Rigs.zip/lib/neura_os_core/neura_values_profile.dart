
import 'package:flutter/foundation.dart';

/// A core value like "Kindness", "Growth", "Family", "Adventure".
class NeuraCoreValue {
  final String id;
  final String label;
  final String description;

  const NeuraCoreValue({
    required this.id,
    required this.label,
    required this.description,
  });
}

/// The user's selection & priority of values.
class NeuraValuesProfile {
  /// Ordered list of value IDs from most important to least.
  final List<String> valuePriority;

  const NeuraValuesProfile({
    required this.valuePriority,
  });

  NeuraValuesProfile.empty() : valuePriority = const [];

  bool get isEmpty => valuePriority.isEmpty;

  List<String> topN(int n) {
    if (valuePriority.length <= n) return valuePriority;
    return valuePriority.sublist(0, n);
  }
}

/// Service that holds and updates the user's value profile.
/// You can later hook this to persistence (local or remote).
class NeuraValuesService extends ChangeNotifier {
  NeuraValuesService._();

  static final NeuraValuesService instance = NeuraValuesService._();

  NeuraValuesProfile _profile = NeuraValuesProfile.empty();

  NeuraValuesProfile get profile => _profile;

  void updateProfile(NeuraValuesProfile profile) {
    _profile = profile;
    notifyListeners();
  }
}

/// A small library of suggested core values.
class NeuraDefaultValuesLibrary {
  static const List<NeuraCoreValue> all = [
    NeuraCoreValue(
      id: 'kindness',
      label: 'Kindness',
      description: 'Being gentle, supportive, and compassionate to others.',
    ),
    NeuraCoreValue(
      id: 'growth',
      label: 'Growth',
      description: 'Learning, improving, and stretching your abilities.',
    ),
    NeuraCoreValue(
      id: 'health',
      label: 'Health',
      description: 'Caring for your body and mind long-term.',
    ),
    NeuraCoreValue(
      id: 'family',
      label: 'Family',
      description: 'Investing in the people closest to you.',
    ),
    NeuraCoreValue(
      id: 'creativity',
      label: 'Creativity',
      description: 'Making things, expressing ideas, playing with new forms.',
    ),
    NeuraCoreValue(
      id: 'contribution',
      label: 'Contribution',
      description:
          'Leaving things better than you found them; helping your community.',
    ),
    NeuraCoreValue(
      id: 'adventure',
      label: 'Adventure',
      description: 'Exploring new places, ideas, and experiences.',
    ),
    NeuraCoreValue(
      id: 'stability',
      label: 'Stability',
      description: 'Safety, consistency, and solid foundations.',
    ),
  ];

  static NeuraCoreValue? byId(String id) {
    try {
      return all.firstWhere((v) => v.id == id);
    } catch (_) {
      return null;
    }
  }
}
