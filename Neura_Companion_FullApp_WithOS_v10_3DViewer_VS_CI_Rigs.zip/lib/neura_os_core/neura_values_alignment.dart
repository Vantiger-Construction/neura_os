
import 'neura_values_profile.dart';
import 'neura_weekly_snapshot.dart';

/// Tiny heuristic to estimate how much the last week aligned with a few
/// key values. This is not "truth", it's a conversation starter.
class NeuraValuesAlignmentResult {
  final double overallScore; // 0–1
  final Map<String, double> perValueScore; // valueId -> 0–1

  NeuraValuesAlignmentResult({
    required this.overallScore,
    required this.perValueScore,
  });
}

class NeuraValuesAlignmentCalculator {
  /// Simple heuristic:
  /// - Kindness / Contribution -> good deeds
  /// - Growth / Creativity -> sessions + rituals
  /// - Health -> rituals (esp. calming / health-tagged later) + mood
  /// - Family -> (not directly tracked yet, stays neutral)
  /// - Adventure -> currently neutral; could map to "new rituals" later.
  static NeuraValuesAlignmentResult estimateAlignment({
    required NeuraValuesProfile profile,
    required NeuraWeeklySnapshot snapshot,
  }) {
    if (profile.isEmpty) {
      return NeuraValuesAlignmentResult(overallScore: 0, perValueScore: const {});
    }

    final perValue = <String, double>{};

    for (final id in profile.topN(4)) {
      perValue[id] = _scoreForValue(id, snapshot);
    }

    final scores = perValue.values.toList();
    final overall =
        scores.isEmpty ? 0.0 : scores.reduce((a, b) => a + b) / scores.length;

    return NeuraValuesAlignmentResult(
      overallScore: overall,
      perValueScore: perValue,
    );
  }

  static double _scoreForValue(String id, NeuraWeeklySnapshot snap) {
    switch (id) {
      case 'kindness':
      case 'contribution':
        // More good deeds -> higher alignment.
        return _normalizeCount(snap.goodDeedsLogged, target: 7);
      case 'growth':
        // Sessions + rituals indicate growth efforts.
        return _normalizeCount(
          snap.sessionsCompleted + snap.ritualsCompleted,
          target: 14,
        );
      case 'health':
        // Mood + rituals together.
        final moodScore = snap.averageMood / 5.0; // 0–1
        final ritualsScore = _normalizeCount(snap.ritualsCompleted, target: 7);
        return (moodScore + ritualsScore) / 2.0;
      case 'creativity':
        // For now, piggyback on sessions; later we can tag "creative" sessions.
        return _normalizeCount(snap.sessionsCompleted, target: 7);
      case 'family':
      case 'adventure':
      case 'stability':
      default:
        // Neutral placeholder until more signals exist.
        return 0.5;
    }
  }

  static double _normalizeCount(int count, {required int target}) {
    if (target <= 0) return 0;
    final ratio = count / target;
    if (ratio <= 0) return 0;
    if (ratio >= 1) return 1;
    return ratio;
  }
}
