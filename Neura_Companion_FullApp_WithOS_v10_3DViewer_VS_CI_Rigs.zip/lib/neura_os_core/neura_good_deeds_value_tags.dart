
import 'neura_values_profile.dart';

/// Maps Good Deed categories into values so your Good Deeds Network
/// can show which values you're living in practice.
class NeuraGoodDeedsValueTags {
  /// Given a good-deed category or tag, infer likely values.
  static List<String> inferValuesForCategory(String category) {
    final c = category.toLowerCase();
    if (c.contains('family')) {
      return ['family', 'kindness'];
    }
    if (c.contains('neighbor') || c.contains('community')) {
      return ['contribution', 'kindness'];
    }
    if (c.contains('health') || c.contains('wellness')) {
      return ['health'];
    }
    if (c.contains('teaching') || c.contains('mentoring')) {
      return ['growth', 'contribution'];
    }
    if (c.contains('creative') || c.contains('art')) {
      return ['creativity'];
    }
    return ['kindness'];
  }
}
