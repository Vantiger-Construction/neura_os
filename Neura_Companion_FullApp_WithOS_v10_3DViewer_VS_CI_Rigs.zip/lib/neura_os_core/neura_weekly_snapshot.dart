
import 'dart:math';

import '../neura_core/neura_telemetry.dart';
import 'neura_focus_modes.dart';

class NeuraWeeklySnapshot {
  final DateTime weekStart; // Monday of the week
  final DateTime weekEnd;   // Sunday of the week (inclusive end-of-day)
  final int ritualsCompleted;
  final int sessionsCompleted;
  final int goodDeedsLogged;
  final double averageMood; // 1–5 scale (or 0 if not enough data)
  final NeuraFocusMode? dominantFocusMode;

  const NeuraWeeklySnapshot({
    required this.weekStart,
    required this.weekEnd,
    required this.ritualsCompleted,
    required this.sessionsCompleted,
    required this.goodDeedsLogged,
    required this.averageMood,
    required this.dominantFocusMode,
  });
}

/// Service to compute weekly snapshots from telemetry.
class NeuraWeeklySnapshotService {
  NeuraWeeklySnapshotService._();

  static final NeuraWeeklySnapshotService instance =
      NeuraWeeklySnapshotService._();

  /// Computes snapshots for the last [weeks] weeks including the current one.
  /// Week is considered Monday–Sunday based on local time.
  List<NeuraWeeklySnapshot> computeRecentWeeks({int weeks = 4}) {
    final telemetry = NeuraTelemetryService.instance.recentEvents;
    if (telemetry.isEmpty) return const [];

    final now = DateTime.now();
    final mondayThisWeek = _startOfWeek(now);
    final snapshots = <NeuraWeeklySnapshot>[];

    for (int i = 0; i < weeks; i++) {
      final start = mondayThisWeek.subtract(Duration(days: 7 * i));
      final end = start.add(const Duration(days: 6, hours: 23, minutes: 59));
      final snap = _computeForRange(
        telemetry: telemetry,
        start: start,
        end: end,
      );
      snapshots.add(snap);
    }

    return snapshots;
  }

  NeuraWeeklySnapshot _computeForRange({
    required List<NeuraTelemetryEvent> telemetry,
    required DateTime start,
    required DateTime end,
  }) {
    int rituals = 0;
    int sessions = 0;
    int goodDeeds = 0;
    final moodScores = <double>[];
    final focusCounts = <NeuraFocusMode, int>{};

    for (final ev in telemetry) {
      final ts = ev.timestamp;
      if (ts.isBefore(start) || ts.isAfter(end)) continue;

      final type = ev.type;
      final data = ev.data ?? {};

      if (type == 'ritual_completed') {
        rituals++;
      } else if (type == 'session_completed') {
        sessions++;
      } else if (type == 'good_deed_logged') {
        goodDeeds++;
      } else if (type == 'mood_check' || type == 'mood_changed') {
        final score = _extractMoodScore(data);
        if (score != null) moodScores.add(score);
      } else if (type == 'focus_mode_changed') {
        final mode = _parseFocusMode(data['mode'] as String?);
        if (mode != null) {
          focusCounts[mode] = (focusCounts[mode] ?? 0) + 1;
        }
      }
    }

    final avgMood = moodScores.isEmpty
        ? 0.0
        : moodScores.reduce((a, b) => a + b) / moodScores.length;

    NeuraFocusMode? dominantMode;
    int maxCount = 0;
    focusCounts.forEach((mode, count) {
      if (count > maxCount) {
        maxCount = count;
        dominantMode = mode;
      }
    });

    return NeuraWeeklySnapshot(
      weekStart: start,
      weekEnd: end,
      ritualsCompleted: rituals,
      sessionsCompleted: sessions,
      goodDeedsLogged: goodDeeds,
      averageMood: avgMood,
      dominantFocusMode: dominantMode,
    );
  }

  DateTime _startOfWeek(DateTime dt) {
    // Monday as start of week.
    final weekday = dt.weekday; // 1=Mon, 7=Sun
    return DateTime(dt.year, dt.month, dt.day)
        .subtract(Duration(days: weekday - 1));
  }

  double? _extractMoodScore(Map<String, dynamic> data) {
    // Try a few common patterns.
    final raw = data['mood_score'] ?? data['score'] ?? data['mood'];
    if (raw == null) return null;

    if (raw is num) {
      final v = raw.toDouble();
      if (v.isNaN) return null;
      return v;
    }
    if (raw is String) {
      // Try to parse numeric, or map mood labels.
      final parsed = double.tryParse(raw);
      if (parsed != null) return parsed;
      final lower = raw.toLowerCase();
      switch (lower) {
        case 'low':
          return 2.0;
        case 'ok':
        case 'neutral':
          return 3.0;
        case 'high':
        case 'great':
          return 4.0;
      }
    }
    return null;
  }

  NeuraFocusMode? _parseFocusMode(String? raw) {
    if (raw == null) return null;
    switch (raw) {
      case 'normal':
        return NeuraFocusMode.normal;
      case 'deep_work':
        return NeuraFocusMode.deepWork;
      case 'reflection':
        return NeuraFocusMode.reflection;
      case 'social':
        return NeuraFocusMode.social;
      case 'wind_down':
        return NeuraFocusMode.windDown;
    }
    return null;
  }
}
