
import 'neura_persona_context.dart';
import 'neura_values_profile.dart';

/// Structured hints you can pass into your chat or TTS layer.
class NeuraToneHints {
  final String styleName;
  final List<String> tags;
  final String shortDescription;

  const NeuraToneHints({
    required this.styleName,
    required this.tags,
    required this.shortDescription,
  });

  Map<String, dynamic> toJson() => {
        'style_name': styleName,
        'tags': tags,
        'description': shortDescription,
      };
}

class NeuraToneEngine {
  NeuraToneEngine._();

  static final NeuraToneEngine instance = NeuraToneEngine._();

  NeuraToneHints buildToneHints(NeuraPersonaContext ctx) {
    final tags = <String>[];

    switch (ctx.energy) {
      case NeuraToneEnergy.calm:
        tags.addAll(['low_energy', 'gentle']);
        break;
      case NeuraToneEnergy.balanced:
        tags.addAll(['steady_energy']);
        break;
      case NeuraToneEnergy.high:
        tags.addAll(['high_energy', 'motivating']);
        break;
    }

    switch (ctx.warmth) {
      case NeuraToneWarmth.cool:
        tags.addAll(['matter_of_fact']);
        break;
      case NeuraToneWarmth.neutral:
        tags.addAll(['neutral_warmth']);
        break;
      case NeuraToneWarmth.warm:
        tags.addAll(['warm', 'encouraging']);
        break;
    }

    switch (ctx.playfulness) {
      case NeuraTonePlayfulness.serious:
        tags.addAll(['light_on_jokes']);
        break;
      case NeuraTonePlayfulness.balanced:
        tags.addAll(['balanced_playfulness']);
        break;
      case NeuraTonePlayfulness.playful:
        tags.addAll(['light_humor', 'playful']);
        break;
    }

    switch (ctx.role) {
      case NeuraPersonaRole.coach:
        tags.addAll(['coach', 'goal_oriented']);
        break;
      case NeuraPersonaRole.comforter:
        tags.addAll(['soothing', 'reassuring']);
        break;
      case NeuraPersonaRole.cheerleader:
        tags.addAll(['celebratory', 'supportive']);
        break;
      case NeuraPersonaRole.observer:
        tags.addAll(['reflective', 'curious']);
        break;
    }

    final valuesService = NeuraValuesService.instance;
    final values = valuesService.profile;
    final topValues = values.topN(2);
    for (final v in topValues) {
      final meta = NeuraDefaultValuesLibrary.byId(v);
      if (meta != null) {
        tags.add('values_${meta.id}');
      }
    }

    final styleName = _decideStyleName(ctx);
    final description = _buildDescription(ctx, topValues);

    return NeuraToneHints(
      styleName: styleName,
      tags: tags,
      shortDescription: description,
    );
  }

  String _decideStyleName(NeuraPersonaContext ctx) {
    if (ctx.role == NeuraPersonaRole.comforter) {
      return 'Calm Comforter';
    }
    if (ctx.role == NeuraPersonaRole.cheerleader &&
        ctx.energy == NeuraToneEnergy.high) {
      return 'Hype Cheerleader';
    }
    if (ctx.role == NeuraPersonaRole.observer) {
      return 'Gentle Mirror';
    }
    if (ctx.energy == NeuraToneEnergy.high &&
        ctx.playfulness == NeuraTonePlayfulness.playful) {
      return 'Playful Coach';
    }
    return 'Steady Coach';
  }

  String _buildDescription(NeuraPersonaContext ctx, List<String> topValues) {
    final buf = StringBuffer();

    switch (ctx.role) {
      case NeuraPersonaRole.coach:
        buf.write('Acts like a supportive coach');
        break;
      case NeuraPersonaRole.comforter:
        buf.write('Acts like a calm, reassuring friend');
        break;
      case NeuraPersonaRole.cheerleader:
        buf.write('Acts like an enthusiastic cheerleader');
        break;
      case NeuraPersonaRole.observer:
        buf.write('Acts like a gentle mirror, asking reflective questions');
        break;
    }

    buf.write(', with ');
    switch (ctx.energy) {
      case NeuraToneEnergy.calm:
        buf.write('calm energy');
        break;
      case NeuraToneEnergy.balanced:
        buf.write('steady energy');
        break;
      case NeuraToneEnergy.high:
        buf.write('high, motivating energy');
        break;
    }

    buf.write(' and ');
    switch (ctx.playfulness) {
      case NeuraTonePlayfulness.serious:
        buf.write('minimal humor');
        break;
      case NeuraTonePlayfulness.balanced:
        buf.write('occasional light humor');
        break;
      case NeuraTonePlayfulness.playful:
        buf.write('frequent playful touches');
        break;
    }

    if (topValues.isNotEmpty) {
      final names = topValues
          .map((id) => NeuraDefaultValuesLibrary.byId(id)?.label ?? id)
          .join(' & ');
      buf.write('. Keeps an eye on the user's values: $names.');
    } else {
      buf.write('.');
    }

    return buf.toString();
  }
}
