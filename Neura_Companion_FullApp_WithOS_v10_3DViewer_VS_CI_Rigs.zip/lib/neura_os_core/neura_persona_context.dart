
import 'package:flutter/foundation.dart';

import 'neura_focus_modes.dart';
import 'neura_values_profile.dart';
import 'neura_weekly_snapshot.dart';
import 'neura_values_alignment.dart';

/// High-level energy dial for Neura's presence.
enum NeuraToneEnergy {
  calm,
  balanced,
  high,
}

/// Warmth / distance dial.
enum NeuraToneWarmth {
  cool,
  neutral,
  warm,
}

/// Playfulness dial.
enum NeuraTonePlayfulness {
  serious,
  balanced,
  playful,
}

/// High-level role Neura is "leaning into" right now.
enum NeuraPersonaRole {
  coach,
  comforter,
  cheerleader,
  observer,
}

/// Snapshot of how Neura should behave right now.
class NeuraPersonaContext {
  final NeuraToneEnergy energy;
  final NeuraToneWarmth warmth;
  final NeuraTonePlayfulness playfulness;
  final NeuraPersonaRole role;

  final NeuraFocusMode focusMode;
  final List<String> primaryValueIds;
  final double valuesAlignment; // 0–1 for last week
  final double averageMood; // 0–1, if available, else ~0.5

  const NeuraPersonaContext({
    required this.energy,
    required this.warmth,
    required this.playfulness,
    required this.role,
    required this.focusMode,
    required this.primaryValueIds,
    required this.valuesAlignment,
    required this.averageMood,
  });

  NeuraPersonaContext copyWith({
    NeuraToneEnergy? energy,
    NeuraToneWarmth? warmth,
    NeuraTonePlayfulness? playfulness,
    NeuraPersonaRole? role,
    NeuraFocusMode? focusMode,
    List<String>? primaryValueIds,
    double? valuesAlignment,
    double? averageMood,
  }) {
    return NeuraPersonaContext(
      energy: energy ?? this.energy,
      warmth: warmth ?? this.warmth,
      playfulness: playfulness ?? this.playfulness,
      role: role ?? this.role,
      focusMode: focusMode ?? this.focusMode,
      primaryValueIds: primaryValueIds ?? this.primaryValueIds,
      valuesAlignment: valuesAlignment ?? this.valuesAlignment,
      averageMood: averageMood ?? this.averageMood,
    );
  }

  static NeuraPersonaContext initial() => NeuraPersonaContext(
        energy: NeuraToneEnergy.balanced,
        warmth: NeuraToneWarmth.warm,
        playfulness: NeuraTonePlayfulness.balanced,
        role: NeuraPersonaRole.coach,
        focusMode: NeuraFocusMode.normal,
        primaryValueIds: const [],
        valuesAlignment: 0.5,
        averageMood: 0.5,
      );
}

/// Service that keeps a live PersonaContext up to date based on the rest
/// of the OS state.
class NeuraPersonaContextService extends ChangeNotifier {
  NeuraPersonaContextService._() {
    // Listen to values & focus mode for automatic refresh.
    NeuraValuesService.instance.addListener(_onSeedChanged);
    NeuraFocusModeController.instance.addListener(_onSeedChanged);
  }

  static final NeuraPersonaContextService instance =
      NeuraPersonaContextService._();

  NeuraPersonaContext _context = NeuraPersonaContext.initial();

  NeuraPersonaContext get context => _context;

  /// Force a recompute. Call this when weekly snapshot or mood changes.
  void refresh() {
    _context = _buildFromSeeds();
    notifyListeners();
  }

  void _onSeedChanged() {
    refresh();
  }

  NeuraPersonaContext _buildFromSeeds() {
    final focus = NeuraFocusModeController.instance.mode;
    final valuesProfile = NeuraValuesService.instance.profile;

    final snaps =
        NeuraWeeklySnapshotService.instance.computeRecentWeeks(weeks: 1);
    final snap = snaps.isNotEmpty ? snaps.first : null;

    double avgMood = 0.5;
    double alignmentScore = 0.5;

    if (snap != null) {
      // Mood normalized to 0–1.
      avgMood = (snap.averageMood / 5.0).clamp(0.0, 1.0);
      if (!valuesProfile.isEmpty) {
        final alignment = NeuraValuesAlignmentCalculator.estimateAlignment(
          profile: valuesProfile,
          snapshot: snap,
        );
        alignmentScore = alignment.overallScore;
      }
    }

    final primaryValues = valuesProfile.topN(3);

    // Decide energy / role based on focus mode + mood.
    final energy = _decideEnergy(focus, avgMood);
    final warmth = _decideWarmth(avgMood);
    final playfulness = _decidePlayfulness(focus, avgMood);
    final role = _decideRole(focus, avgMood, alignmentScore);

    return NeuraPersonaContext(
      energy: energy,
      warmth: warmth,
      playfulness: playfulness,
      role: role,
      focusMode: focus,
      primaryValueIds: primaryValues,
      valuesAlignment: alignmentScore,
      averageMood: avgMood,
    );
  }

  NeuraToneEnergy _decideEnergy(NeuraFocusMode mode, double mood) {
    switch (mode) {
      case NeuraFocusMode.deepWork:
        return NeuraToneEnergy.high;
      case NeuraFocusMode.windDown:
        return NeuraToneEnergy.calm;
      case NeuraFocusMode.reflection:
        return NeuraToneEnergy.calm;
      case NeuraFocusMode.social:
        return NeuraToneEnergy.high;
      case NeuraFocusMode.normal:
        return mood < 0.4
            ? NeuraToneEnergy.calm
            : (mood > 0.7 ? NeuraToneEnergy.high : NeuraToneEnergy.balanced);
    }
  }

  NeuraToneWarmth _decideWarmth(double mood) {
    if (mood < 0.4) return NeuraToneWarmth.warm;
    if (mood > 0.8) return NeuraToneWarmth.warm;
    return NeuraToneWarmth.neutral;
  }

  NeuraTonePlayfulness _decidePlayfulness(
    NeuraFocusMode mode,
    double mood,
  ) {
    if (mode == NeuraFocusMode.deepWork) return NeuraTonePlayfulness.serious;
    if (mode == NeuraFocusMode.windDown && mood < 0.4) {
      return NeuraTonePlayfulness.balanced;
    }
    if (mode == NeuraFocusMode.social && mood > 0.6) {
      return NeuraTonePlayfulness.playful;
    }
    return NeuraTonePlayfulness.balanced;
  }

  NeuraPersonaRole _decideRole(
    NeuraFocusMode mode,
    double mood,
    double alignment,
  ) {
    if (mood < 0.35) {
      return NeuraPersonaRole.comforter;
    }
    if (alignment < 0.4 && mode == NeuraFocusMode.reflection) {
      return NeuraPersonaRole.observer;
    }
    if (mode == NeuraFocusMode.deepWork || mode == NeuraFocusMode.normal) {
      return NeuraPersonaRole.coach;
    }
    if (mode == NeuraFocusMode.social) {
      return NeuraPersonaRole.cheerleader;
    }
    return NeuraPersonaRole.coach;
  }
}
