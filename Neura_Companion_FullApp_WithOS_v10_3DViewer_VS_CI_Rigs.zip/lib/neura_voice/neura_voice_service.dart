import 'dart:developer' as dev;
import 'package:flutter/foundation.dart';
import '../neura_core/neura_voice.dart';
import '../empathy_core/voice/tts_engine.dart';
import '../empathy_core/avatar/rive_viseme_controller.dart';

/// High‑level voice service that ties NeuraVoice (planning),
/// the concrete TTS engine, and the viseme controller together.
class NeuraVoiceService extends ChangeNotifier implements NeuraVoicePlanHandler {
  final TtsEngine tts;
  final RiveVisemeController visemes;
  late final NeuraVoice voice;

  NeuraVoiceService({
    required this.tts,
    required this.visemes,
  }) {
    voice = NeuraVoice(onPlan: call);
  }

  @override
  Future<void> call(String text, {NeuraTone? tone}) async {
    dev.log(
      '[NeuraVoiceService] speak tone=$tone text=$text',
      name: 'NeuraVoice',
    );
    await tts.speak(
      text,
      onStart: () => visemes.onSpeechStart(),
      onChunk: visemes.onViseme,
      onComplete: () => visemes.onSpeechEnd(),
    );
  }
}
