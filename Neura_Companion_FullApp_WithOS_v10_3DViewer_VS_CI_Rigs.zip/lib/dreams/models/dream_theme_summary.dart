class DreamThemeSummary {
  final String theme;
  final int count;
  final double intensity; // 0–1
  final List<String> exampleDates;

  const DreamThemeSummary({
    required this.theme,
    required this.count,
    required this.intensity,
    required this.exampleDates,
  });

  Map<String, dynamic> toJson() => {
    'theme': theme,
    'count': count,
    'intensity': intensity,
    'exampleDates': exampleDates,
  };

  factory DreamThemeSummary.fromJson(Map<String, dynamic> json) {
    return DreamThemeSummary(
      theme: json['theme'] as String? ?? '',
      count: json['count'] as int? ?? 0,
      intensity: (json['intensity'] as num?)?.toDouble() ?? 0.0,
      exampleDates: (json['exampleDates'] as List<dynamic>?)
              ?.map((e) => e.toString())
              .toList() ??
          const <String>[],
    );
  }
}
