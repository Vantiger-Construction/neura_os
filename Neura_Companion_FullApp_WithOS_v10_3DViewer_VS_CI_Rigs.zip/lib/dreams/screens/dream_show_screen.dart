import 'package:flutter/material.dart';
import '../services/dream_theme_service.dart';
import '../models/dream_theme_summary.dart';
import '../../os/widgets/neura_shell_scaffold.dart';

class DreamShowScreen extends StatefulWidget {
  const DreamShowScreen({Key? key}) : super(key: key);

  @override
  State<DreamShowScreen> createState() => _DreamShowScreenState();
}

class _DreamShowScreenState extends State<DreamShowScreen> {
  bool _loading = true;
  List<DreamThemeSummary> _themes = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final svc = DreamThemeService.instance;
    await svc.load();
    setState(() {
      _themes = svc.themes;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const NeuraShellScaffold(
        appBar: null,
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return NeuraShellScaffold(
      appBar: AppBar(
        title: const Text('Dream Show'),
      ),
      body: _themes.isEmpty
          ? const Center(
              child: Text(
                'No recurring dream themes yet.\nAs you log dreams, I will track patterns here.',
                textAlign: TextAlign.center,
              ),
            )
          : ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: _themes.length,
              itemBuilder: (context, index) {
                final t = _themes[index];
                return Card(
                  color: Colors.black.withOpacity(0.45),
                  margin: const EdgeInsets.only(bottom: 12),
                  child: ListTile(
                    title: Text(t.theme),
                    subtitle: Text(
                      'Seen ${t.count} time(s) • Intensity ${(t.intensity * 100).round()}%\n'
                      'Examples: ${t.exampleDates.join(', ')}',
                    ),
                  ),
                );
              },
            ),
    );
  }
}
