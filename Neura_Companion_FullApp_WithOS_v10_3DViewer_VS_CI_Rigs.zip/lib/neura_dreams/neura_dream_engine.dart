import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Minimal dream log model.
class NeuraDreamEntry {
  final String id;
  final DateTime createdAt;
  final String title;
  final String body;

  NeuraDreamEntry({
    required this.id,
    required this.createdAt,
    required this.title,
    required this.body,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'createdAt': createdAt.toIso8601String(),
        'title': title,
        'body': body,
      };

  static NeuraDreamEntry fromJson(Map<String, dynamic> json) =>
      NeuraDreamEntry(
        id: json['id'] as String,
        createdAt: DateTime.parse(json['createdAt'] as String),
        title: json['title'] as String? ?? '',
        body: json['body'] as String? ?? '',
      );
}

class NeuraDreamEngine extends ChangeNotifier {
  static const _storageKey = 'neura_dream_entries_v1';

  final List<NeuraDreamEntry> _entries = [];
  bool _loaded = false;

  List<NeuraDreamEntry> get entries =>
      List.unmodifiable(_entries)..sort((a, b) => b.createdAt.compareTo(a.createdAt));

  Future<void> ensureLoaded() async {
    if (_loaded) return;
    await _load();
  }

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_storageKey);
    if (raw == null || raw.isEmpty) {
      _entries.clear();
      _loaded = true;
      notifyListeners();
      return;
    }

    final decoded = jsonDecode(raw) as List<dynamic>;
    _entries
      ..clear()
      ..addAll(decoded
          .whereType<Map<String, dynamic>>()
          .map(NeuraDreamEntry.fromJson));
    _loaded = true;
    notifyListeners();
  }

  Future<void> addEntry(String title, String body) async {
    final entry = NeuraDreamEntry(
      id: DateTime.now().microsecondsSinceEpoch.toString(),
      createdAt: DateTime.now(),
      title: title,
      body: body,
    );
    _entries.insert(0, entry);
    await _persist();
    notifyListeners();
  }

  Future<void> _persist() async {
    final prefs = await SharedPreferences.getInstance();
    final raw = jsonEncode(_entries.map((e) => e.toJson()).toList());
    await prefs.setString(_storageKey, raw);
  }
}
