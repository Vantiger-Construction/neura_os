import 'dart:developer' as dev;

/// Tiny diagnostic helper that mimics the older Self‑Heal service.
///
/// Right now it just logs issues; you can later plug this into your
/// real error tracker or Dimensional Sync gag.
class NeuraSelfHealService {
  void recordIssue(String code, {String? details}) {
    dev.log(
      '[NeuraSelfHeal] issue=$code details=${details ?? ''}',
      name: 'NeuraSelfHeal',
    );
  }

  void recordRecovery(String code) {
    dev.log(
      '[NeuraSelfHeal] recovery=$code',
      name: 'NeuraSelfHeal',
    );
  }
}
