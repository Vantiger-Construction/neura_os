import 'package:flutter/foundation.dart';

/// Serializable snapshot of Neura's persona sliders for a given user.
class NeuraPersonaModel extends ChangeNotifier {
  double trust;
  double warmth;
  double motivation;
  double attunement;

  NeuraPersonaModel({
    this.trust = 0.5,
    this.warmth = 0.5,
    this.motivation = 0.5,
    this.attunement = 0.5,
  });

  Map<String, double> toJson() => {
        'trust': trust,
        'warmth': warmth,
        'motivation': motivation,
        'attunement': attunement,
      };

  void applyJson(Map<String, dynamic> json) {
    trust = (json['trust'] ?? trust).toDouble();
    warmth = (json['warmth'] ?? warmth).toDouble();
    motivation = (json['motivation'] ?? motivation).toDouble();
    attunement = (json['attunement'] ?? attunement).toDouble();
    notifyListeners();
  }
}
