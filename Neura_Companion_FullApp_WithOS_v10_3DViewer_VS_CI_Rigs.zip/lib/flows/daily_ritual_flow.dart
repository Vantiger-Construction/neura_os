import 'package:flutter/material.dart';
import 'package:provider/provider.dart';

import '../neura_core/neura_event_hub.dart';
import '../neura_core/neura_emotion_engine.dart';
import '../neura_core/neura_persona_engine.dart';
import '../neura_avatar/neura_face_reaction.dart';
import '../neura_apartment/neura_room_state.dart';
import '../neura_apartment/neura_rooms.dart';
import '../neura_apartment/neura_room_badge.dart';

// You can replace this with your real Ritual model.
enum RitualCategory { grounding, joy, focus, recovery }

class Ritual {
  final String id;
  final String name;
  final RitualCategory category;
  final String description;
  const Ritual({
    required this.id,
    required this.name,
    required this.category,
    required this.description,
  });
}

// Sample rituals; replace with real data / API
const kSampleRituals = <Ritual>[
  Ritual(
    id: "ground_breath_1",
    name: "2-Minute Grounding Breath",
    category: RitualCategory.grounding,
    description: "Slow inhale, slow exhale, drop your shoulders.",
  ),
  Ritual(
    id: "joy_song_1",
    name: "One Favorite Song",
    category: RitualCategory.joy,
    description: "Play a song that makes you grin, no matter what.",
  ),
  Ritual(
    id: "focus_sprint_1",
    name: "5-Min Focus Sprint",
    category: RitualCategory.focus,
    description: "Pick one tiny task and crush it.",
  ),
  Ritual(
    id: "recovery_stretch_1",
    name: "Gentle Stretch & Reset",
    category: RitualCategory.recovery,
    description: "Release some tension from your body.",
  ),
];

class DailyRitualFlowScreen extends StatefulWidget {
  const DailyRitualFlowScreen({super.key});

  @override
  State<DailyRitualFlowScreen> createState() => _DailyRitualFlowScreenState();
}

class _DailyRitualFlowScreenState extends State<DailyRitualFlowScreen> {
  int _step = 0;
  double _valence = 0.0; // -1 .. 1
  double _energy = 0.5;  // 0 .. 1
  Ritual? _selectedRitual;
  double _reflectionValence = 0.0;
  final TextEditingController _reflectionCtrl = TextEditingController();

  bool _appOpenedSent = false;

  NeuraRitualPhase get _phase {
    switch (_step) {
      case 0:
        return NeuraRitualPhase.intro;
      case 1:
        return NeuraRitualPhase.moodCheckin;
      case 2:
        return NeuraRitualPhase.ritualSelect;
      case 3:
        return NeuraRitualPhase.ritualRun;
      case 4:
        return NeuraRitualPhase.reflection;
      default:
        return NeuraRitualPhase.intro;
    }
  }

  void _goToStep(int step) {
    setState(() => _step = step);
    _syncRoomWithStep();
  }

  void _syncRoomWithStep() {
    final roomState = context.read<NeuraRoomState>();
    switch (_phase) {
      case NeuraRitualPhase.intro:
        roomState.setRoom(NeuraRoomId.reflectionBay);
        break;
      case NeuraRitualPhase.moodCheckin:
        roomState.setRoom(NeuraRoomId.moodDen);
        break;
      case NeuraRitualPhase.ritualSelect:
        roomState.setRoom(NeuraRoomId.focusLab);
        break;
      case NeuraRitualPhase.ritualRun:
        // If a ritual is selected, use its category
        if (_selectedRitual != null) {
          switch (_selectedRitual!.category) {
            case RitualCategory.grounding:
              roomState.setRoom(NeuraRoomId.reflectionBay);
              break;
            case RitualCategory.joy:
              roomState.setRoom(NeuraRoomId.joyLounge);
              break;
            case RitualCategory.focus:
              roomState.setRoom(NeuraRoomId.focusLab);
              break;
            case RitualCategory.recovery:
              roomState.setRoom(NeuraRoomId.moodDen);
              break;
          }
        } else {
          roomState.setRoom(NeuraRoomId.focusLab);
        }
        break;
      case NeuraRitualPhase.reflection:
        roomState.setRoom(NeuraRoomId.reflectionBay);
        break;
    }
  }

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    if (!_appOpenedSent) {
      _appOpenedSent = true;
      final hub = context.read<NeuraEventHub>();
      // TODO: compute real firstOpenToday from storage
      hub.onAppOpened(firstOpenToday: true);
      _syncRoomWithStep();
    }
  }

  @override
  void dispose() {
    _reflectionCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final emotion = context.watch<NeuraEmotionEngine>();
    final persona = context.watch<NeuraPersonaEngine>();

    return Scaffold(
      appBar: AppBar(
        title: const Text("Daily Ritual Path"),
        centerTitle: true,
      ),
      body: SafeArea(
        child: Column(
          children: [
            // Neura face + room badge + emotional strip
            Padding(
              padding: const EdgeInsets.only(top: 12, bottom: 8),
              child: Column(
                children: [
                  AnimatedSwitcher(
                    duration: const Duration(milliseconds: 400),
                    transitionBuilder: (child, anim) {
                      return ScaleTransition(
                        scale: CurvedAnimation(
                          parent: anim,
                          curve: Curves.easeOutBack,
                        ),
                        child: FadeTransition(opacity: anim, child: child),
                      );
                    },
                    child: NeuraFaceReaction(
                      key: ValueKey(_phase),
                      phase: _phase,
                      size: 140,
                    ),
                  ),
                  const SizedBox(height: 8),
                  const NeuraRoomBadge(),
                  const SizedBox(height: 6),
                  _NeuraStatusStrip(
                    label: persona.exportState().toString(),
                    moodLabel: emotion.label,
                  ),
                ],
              ),
            ),
            const Divider(height: 1),
            Expanded(
              child: AnimatedSwitcher(
                duration: const Duration(milliseconds: 300),
                child: _buildStep(context),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildStep(BuildContext context) {
    switch (_step) {
      case 0:
        return _buildIntro(context);
      case 1:
        return _buildMoodStep(context);
      case 2:
        return _buildRitualSelect(context);
      case 3:
        return _buildRitualRun(context);
      case 4:
        return _buildReflection(context);
      default:
        return _buildIntro(context);
    }
  }

  Widget _buildIntro(BuildContext context) {
    return Padding(
      key: const ValueKey("intro"),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Let’s run today’s ritual.",
            style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          const Text(
            "We’ll check in, pick one tiny action, do it, then reflect together.",
          ),
          const Spacer(),
          Align(
            alignment: Alignment.bottomRight,
            child: ElevatedButton(
              onPressed: () => _goToStep(1),
              child: const Text("Start"),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildMoodStep(BuildContext context) {
    return Padding(
      key: const ValueKey("mood_step"),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "How are you right now?",
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          const Text("Mood (low → high):"),
          Slider(
            value: _valence,
            min: -1,
            max: 1,
            divisions: 10,
            label: _valence.toStringAsFixed(1),
            onChanged: (v) => setState(() => _valence = v),
          ),
          const SizedBox(height: 12),
          const Text("Energy (drained → wired):"),
          Slider(
            value: _energy,
            min: 0,
            max: 1,
            divisions: 10,
            label: _energy.toStringAsFixed(1),
            onChanged: (v) => setState(() => _energy = v),
          ),
          const Spacer(),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              TextButton(
                onPressed: () => _goToStep(0),
                child: const Text("Back"),
              ),
              ElevatedButton(
                onPressed: () async {
                  final hub = context.read<NeuraEventHub>();
                  await hub.onMoodCheckin(_valence, _energy);
                  _goToStep(2);
                },
                child: const Text("Continue"),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildRitualSelect(BuildContext context) {
    return Padding(
      key: const ValueKey("ritual_select"),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Pick a micro-ritual for right now.",
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          Expanded(
            child: ListView.builder(
              itemCount: kSampleRituals.length,
              itemBuilder: (context, index) {
                final r = kSampleRituals[index];
                final selected = _selectedRitual?.id == r.id;
                return Card(
                  color: selected
                      ? Theme.of(context).colorScheme.primary.withOpacity(0.08)
                      : null,
                  child: ListTile(
                    title: Text(r.name),
                    subtitle: Text(r.description),
                    trailing: Text(
                      r.category.name,
                      style: const TextStyle(fontStyle: FontStyle.italic),
                    ),
                    onTap: () {
                      setState(() => _selectedRitual = r);
                    },
                  ),
                );
              },
            ),
          ),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              TextButton(
                onPressed: () => _goToStep(1),
                child: const Text("Back"),
              ),
              ElevatedButton(
                onPressed: _selectedRitual == null
                    ? null
                    : () => _goToStep(3),
                child: const Text("Do this ritual"),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildRitualRun(BuildContext context) {
    final ritual = _selectedRitual!;
    return Padding(
      key: const ValueKey("ritual_run"),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Text(
            ritual.name,
            style: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 8),
          Text(ritual.description),
          const SizedBox(height: 16),
          const Text(
            "Take a moment and actually do this.\nWhen you're done, tap Complete.",
          ),
          const Spacer(),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              TextButton(
                onPressed: () => _goToStep(2),
                child: const Text("Back"),
              ),
              ElevatedButton(
                onPressed: () async {
                  final hub = context.read<NeuraEventHub>();
                  await hub.onRitualCompleted(
                    ritualId: ritual.id,
                    category: ritual.category.name,
                  );
                  _goToStep(4);
                },
                child: const Text("Complete ritual"),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildReflection(BuildContext context) {
    return Padding(
      key: const ValueKey("reflection"),
      padding: const EdgeInsets.all(16),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Text(
            "Quick reflection",
            style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
          ),
          const SizedBox(height: 12),
          const Text("How do you feel *now* (after the ritual)?"),
          Slider(
            value: _reflectionValence,
            min: -1,
            max: 1,
            divisions: 10,
            label: _reflectionValence.toStringAsFixed(1),
            onChanged: (v) => setState(() => _reflectionValence = v),
          ),
          const SizedBox(height: 12),
          TextField(
            controller: _reflectionCtrl,
            maxLines: 4,
            decoration: const InputDecoration(
              labelText: "You can write a sentence or two about it (optional)",
              border: OutlineInputBorder(),
            ),
          ),
          const Spacer(),
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              TextButton(
                onPressed: () => _goToStep(3),
                child: const Text("Back"),
              ),
              ElevatedButton(
                onPressed: () async {
                  final hub = context.read<NeuraEventHub>();
                  await hub.onJournalSaved(
                    valence: _reflectionValence,
                    isDeepEntry: _reflectionCtrl.text.length > 300,
                  );
                  if (mounted) {
                    Navigator.of(context).pop(); // Flow complete
                  }
                },
                child: const Text("Finish"),
              ),
            ],
          ),
        ],
      ),
    );
  }
}

class _NeuraStatusStrip extends StatelessWidget {
  final String label;
  final String moodLabel;

  const _NeuraStatusStrip({
    required this.label,
    required this.moodLabel,
  });

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
      decoration: BoxDecoration(
        color: Theme.of(context).colorScheme.surfaceVariant,
        borderRadius: const BorderRadius.all(Radius.circular(12)),
      ),
      child: Row(
        children: [
          const Icon(Icons.auto_awesome, size: 18),
          const SizedBox(width: 8),
          Expanded(
            child: Text(
              "Neura is synced. Mood: $moodLabel",
              overflow: TextOverflow.ellipsis,
            ),
          ),
        ],
      ),
    );
  }
}
