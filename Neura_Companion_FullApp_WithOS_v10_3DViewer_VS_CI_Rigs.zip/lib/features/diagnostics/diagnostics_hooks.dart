import 'dart:developer' as dev;
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import '../config/neura_config_model.dart';
import '../voice/viseme_timing_controller.dart';

/// Centralised hooks used by config + diagnostics screens.
///
/// For now this is deliberately gentle: it logs to dev tools and
/// shows SnackBars instead of throwing when Hue is misconfigured.
class DiagnosticsHooks {
  final VisemeTimingController visemeTiming;

  DiagnosticsHooks(this.visemeTiming);

  Future<void> runHueRelaxTest(
    BuildContext context,
    NeuraConfigModel cfg,
  ) async {
    final bridge = cfg.bridgeBase;
    final token = cfg.hueToken;
    final group = cfg.hueGroupId;
    final scene = cfg.hueRelaxSceneId;

    if (bridge == null ||
        bridge.isEmpty ||
        token == null ||
        token.isEmpty ||
        group == null ||
        group.isEmpty ||
        scene == null ||
        scene.isEmpty) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(
          content: Text(
            'Hue config incomplete – set bridge, token, group & scene first.',
          ),
        ),
      );
      return;
    }

    final uri = Uri.parse(
      '$bridge/api/$token/groups/$group/action',
    );

    try {
      final resp = await http.put(
        uri,
        body: '{"scene":"$scene"}',
        headers: {'Content-Type': 'application/json'},
      );
      dev.log(
        '[DiagnosticsHooks] Hue test response: '
        '${resp.statusCode} ${resp.body}',
        name: 'NeuraDiagnostics',
      );
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Hue Relax test: HTTP ${resp.statusCode}'),
        ),
      );
    } catch (e) {
      dev.log(
        '[DiagnosticsHooks] Hue test failed: $e',
        name: 'NeuraDiagnostics',
      );
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Hue Relax test failed: $e'),
        ),
      );
    }
  }

  Future<void> runVisemeDemo(BuildContext context) async {
    if (visemeTiming.busy) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('Viseme demo already running...')),
      );
      return;
    }
    await visemeTiming.playDemo();
    if (!context.mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Viseme demo played')),
    );
  }
}
