import 'dart:async';
import 'dart:developer' as dev;

/// Thin timing helper for viseme demos.
///
/// The real implementation can talk to a NeuraRiveVisemeController
/// or NeuraLottie avatar; for now we just expose a simple async demo
/// entry point and log timing.
class VisemeTimingController {
  bool _busy = false;
  bool get busy => _busy;

  Future<void> playDemo() async {
    if (_busy) return;
    _busy = true;
    dev.log('[VisemeTimingController] demo start', name: 'NeuraViseme');
    try {
      // Fake timeline duration
      await Future.delayed(const Duration(milliseconds: 1600));
    } finally {
      dev.log('[VisemeTimingController] demo end', name: 'NeuraViseme');
      _busy = false;
    }
  }
}
