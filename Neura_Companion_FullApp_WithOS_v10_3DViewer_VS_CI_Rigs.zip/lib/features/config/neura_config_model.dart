import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// Persistent configuration for Phase 2.1 features:
/// - Philips Hue bridge + scene
/// - Preferred BLE device
/// - Auto viseme demo flag
class NeuraConfigModel with ChangeNotifier {
  // Hue
  String? bridgeBase;
  String? hueToken;
  String? hueGroupId;
  String? hueRelaxSceneId;

  // BLE
  String? bleDeviceId;

  // Viseme
  bool autoVisemeDemo = false;

  static const _kBridgeBaseKey = 'neura_cfg_bridge_base';
  static const _kHueTokenKey = 'neura_cfg_hue_token';
  static const _kHueGroupKey = 'neura_cfg_hue_group';
  static const _kHueRelaxSceneKey = 'neura_cfg_hue_relax';
  static const _kBleDeviceKey = 'neura_cfg_ble_device';
  static const _kAutoVisemeKey = 'neura_cfg_auto_viseme';

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    bridgeBase = prefs.getString(_kBridgeBaseKey);
    hueToken = prefs.getString(_kHueTokenKey);
    hueGroupId = prefs.getString(_kHueGroupKey);
    hueRelaxSceneId = prefs.getString(_kHueRelaxSceneKey);
    bleDeviceId = prefs.getString(_kBleDeviceKey);
    autoVisemeDemo = prefs.getBool(_kAutoVisemeKey) ?? false;
    notifyListeners();
  }

  Future<void> save() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kBridgeBaseKey, bridgeBase ?? '');
    await prefs.setString(_kHueTokenKey, hueToken ?? '');
    await prefs.setString(_kHueGroupKey, hueGroupId ?? '');
    await prefs.setString(_kHueRelaxSceneKey, hueRelaxSceneId ?? '');
    await prefs.setString(_kBleDeviceKey, bleDeviceId ?? '');
    await prefs.setBool(_kAutoVisemeKey, autoVisemeDemo);
  }

  void setHueConfig({
    String? bridge,
    String? token,
    String? group,
    String? scene,
  }) {
    bridgeBase = bridge ?? bridgeBase;
    hueToken = token ?? hueToken;
    hueGroupId = group ?? hueGroupId;
    hueRelaxSceneId = scene ?? hueRelaxSceneId;
    notifyListeners();
  }

  void setBleDevice(String? id) {
    bleDeviceId = id;
    notifyListeners();
  }

  void setAutoViseme(bool v) {
    autoVisemeDemo = v;
    notifyListeners();
  }
}
