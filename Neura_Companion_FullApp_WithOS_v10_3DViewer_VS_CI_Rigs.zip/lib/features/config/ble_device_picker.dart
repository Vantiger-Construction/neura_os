import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter_blue_plus/flutter_blue_plus.dart';

/// Simple BLE picker that scans for nearby devices and lets the user
/// select one that Neura can use for HRV / biofeedback later.
class BleDevicePicker extends StatefulWidget {
  final String? selectedId;
  final void Function(String? id) onSelected;

  const BleDevicePicker({
    super.key,
    required this.selectedId,
    required this.onSelected,
  });

  @override
  State<BleDevicePicker> createState() => _BleDevicePickerState();
}

class _BleDevicePickerState extends State<BleDevicePicker> {
  StreamSubscription<List<ScanResult>>? _sub;
  final List<ScanResult> _results = [];

  @override
  void initState() {
    super.initState();
    _startScan();
  }

  @override
  void dispose() {
    _sub?.cancel();
    FlutterBluePlus.stopScan();
    super.dispose();
  }

  Future<void> _startScan() async {
    _results.clear();
    try {
      await FlutterBluePlus.startScan(timeout: const Duration(seconds: 4));
      _sub = FlutterBluePlus.scanResults.listen((results) {
        if (!mounted) return;
        setState(() {
          _results
            ..clear()
            ..addAll(results);
        });
      });
    } catch (e) {
      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('BLE scan failed: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            const Expanded(
              child: Text(
                'Preferred BLE Device',
                style: TextStyle(fontWeight: FontWeight.bold),
              ),
            ),
            IconButton(
              onPressed: _startScan,
              icon: const Icon(Icons.refresh),
              tooltip: 'Rescan',
            ),
          ],
        ),
        const SizedBox(height: 8),
        SizedBox(
          height: 200,
          child: _results.isEmpty
              ? const Center(child: Text('No devices yet – scanning...'))
              : ListView.builder(
                  itemCount: _results.length,
                  itemBuilder: (context, index) {
                    final r = _results[index];
                    final id = r.device.remoteId.str;
                    final name = r.device.platformName.isNotEmpty
                        ? r.device.platformName
                        : '(unknown)';
                    final selected = id == widget.selectedId;
                    return ListTile(
                      title: Text(name),
                      subtitle: Text(id),
                      trailing: selected ? const Icon(Icons.check) : null,
                      onTap: () => widget.onSelected(id),
                    );
                  },
                ),
        ),
      ],
    );
  }
}
