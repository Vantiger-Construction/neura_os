import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../diagnostics/diagnostics_hooks.dart';
import '../voice/viseme_timing_controller.dart';
import 'neura_config_model.dart';
import 'ble_device_picker.dart';

class NeuraConfigScreen extends StatefulWidget {
  const NeuraConfigScreen({super.key});

  @override
  State<NeuraConfigScreen> createState() => _NeuraConfigScreenState();
}

class _NeuraConfigScreenState extends State<NeuraConfigScreen> {
  final _bridgeCtrl = TextEditingController();
  final _tokenCtrl = TextEditingController();
  final _groupCtrl = TextEditingController();
  final _sceneCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    final cfg = context.read<NeuraConfigModel>();
    _bridgeCtrl.text = cfg.bridgeBase ?? '';
    _tokenCtrl.text = cfg.hueToken ?? '';
    _groupCtrl.text = cfg.hueGroupId ?? '';
    _sceneCtrl.text = cfg.hueRelaxSceneId ?? '';
  }

  @override
  void dispose() {
    _bridgeCtrl.dispose();
    _tokenCtrl.dispose();
    _groupCtrl.dispose();
    _sceneCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final cfg = context.watch<NeuraConfigModel>();
    final hooks = context.read<DiagnosticsHooks>();
    return Scaffold(
      appBar: AppBar(title: const Text('Neura Config')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text(
              'Philips Hue',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: _bridgeCtrl,
              decoration: const InputDecoration(
                labelText: 'Bridge base (e.g. http://192.168.1.2)',
              ),
              onChanged: (v) => cfg.setHueConfig(bridge: v),
            ),
            TextField(
              controller: _tokenCtrl,
              decoration: const InputDecoration(labelText: 'Hue token'),
              onChanged: (v) => cfg.setHueConfig(token: v),
            ),
            TextField(
              controller: _groupCtrl,
              decoration: const InputDecoration(labelText: 'Group ID'),
              onChanged: (v) => cfg.setHueConfig(group: v),
            ),
            TextField(
              controller: _sceneCtrl,
              decoration: const InputDecoration(labelText: 'Relax scene ID'),
              onChanged: (v) => cfg.setHueConfig(scene: v),
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                ElevatedButton(
                  onPressed: () =>
                      hooks.runHueRelaxTest(context, cfg),
                  child: const Text('Test Relax Scene'),
                ),
                const SizedBox(width: 12),
                Text(
                  cfg.bridgeBase == null || cfg.bridgeBase!.isEmpty
                      ? 'Not configured'
                      : 'Configured',
                  style: TextStyle(
                    color: (cfg.bridgeBase == null ||
                            cfg.bridgeBase!.isEmpty)
                        ? Colors.red
                        : Colors.green,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 24),
            const Divider(),
            const SizedBox(height: 8),
            const Text(
              'BLE Device',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            const SizedBox(height: 8),
            BleDevicePicker(
              selectedId: cfg.bleDeviceId,
              onSelected: (id) {
                cfg.setBleDevice(id);
              },
            ),
            const SizedBox(height: 24),
            const Divider(),
            const SizedBox(height: 8),
            const Text(
              'Viseme Demo',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SwitchListTile(
              title: const Text('Run viseme demo automatically on startup'),
              value: cfg.autoVisemeDemo,
              onChanged: (v) => setState(() {
                cfg.setAutoViseme(v);
              }),
            ),
            const SizedBox(height: 8),
            Consumer<VisemeTimingController>(
              builder: (context, timing, _) {
                return ElevatedButton(
                  onPressed: timing.busy
                      ? null
                      : () => hooks.runVisemeDemo(context),
                  child: Text(timing.busy
                      ? 'Playing demo...'
                      : 'Play viseme demo'),
                );
              },
            ),
            const SizedBox(height: 24),
            Row(
              mainAxisAlignment: MainAxisAlignment.end,
              children: [
                ElevatedButton(
                  onPressed: () async {
                    await cfg.save();
                    if (!context.mounted) return;
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(
                        content: Text('Config saved'),
                      ),
                    );
                  },
                  child: const Text('Save'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
