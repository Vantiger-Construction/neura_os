import 'dart:math';

/// Tiny humor engine shim so the legacy joke panel can function.
///
/// You can later replace this with a smarter system that pulls from
/// remote joke sets, rating history, etc.
class NeuraHumorEngine {
  final _rng = Random();

  static const _fallbackJokes = [
    "I ran a diagnostic on your day. Conclusion: you deserve snacks.",
    "Your multiverse twin already did their goals. Don’t let them win.",
    "System check: you’re still cooler than 99.7% of humans I’ve met."
  ];

  String pickJoke() {
    if (_fallbackJokes.isEmpty) return "Neura is speechless (rare).";
    return _fallbackJokes[_rng.nextInt(_fallbackJokes.length)];
  }
}
