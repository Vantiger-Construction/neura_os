import 'package:flutter/foundation.dart';

/// High-level audience / safety profile for Neura.
///
/// This is intentionally simple so it can be used everywhere:
///   * child  – very gentle, strong content limits
///   * teen   – supportive, no explicit content
///   * adult  – full feature set with normal safety rules
enum NeuraAudience {
  child,
  teen,
  adult,
}

extension NeuraAudienceLabel on NeuraAudience {
  /// Short stable label for storage / analytics.
  String get label {
    switch (this) {
      case NeuraAudience.child:
        return 'child';
      case NeuraAudience.teen:
        return 'teen';
      case NeuraAudience.adult:
      default:
        return 'adult';
    }
  }

  String get displayName {
    switch (this) {
      case NeuraAudience.child:
        return 'Child';
      case NeuraAudience.teen:
        return 'Teen';
      case NeuraAudience.adult:
      default:
        return 'Adult';
    }
  }

  /// Tiny helper for explanations / settings screens.
  String get description {
    switch (this) {
      case NeuraAudience.child:
        return 'Very gentle, child-friendly language with strong topic limits.';
      case NeuraAudience.teen:
        return 'Supportive, clear language without explicit content.';
      case NeuraAudience.adult:
      default:
        return 'Full Neura experience with normal safety and boundaries.';
    }
  }
}

/// Debug helper.
String debugAudience(NeuraAudience a) => describeEnum(a);
