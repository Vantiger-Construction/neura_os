import 'dart:convert';

import 'package:shared_preferences/shared_preferences.dart';

import '../../neura_brain/neura_persona_model.dart';

/// Central place to load / store NeuraPersonaModel so the whole OS
/// can agree on the same sliders.
class NeuraPersonaService {
  NeuraPersonaService._internal();

  static final NeuraPersonaService instance = NeuraPersonaService._internal();

  static const _storageKey = 'neura_persona_v1';

  final NeuraPersonaModel model = NeuraPersonaModel();

  bool _loaded = false;

  bool get isLoaded => _loaded;

  Future<void> load() async {
    if (_loaded) return;
    final prefs = await SharedPreferences.getInstance();
    final raw = prefs.getString(_storageKey);
    if (raw != null) {
      try {
        final data = json.decode(raw) as Map<String, dynamic>;
        model.trust = (data['trust'] as num?)?.toDouble() ?? model.trust;
        model.warmth = (data['warmth'] as num?)?.toDouble() ?? model.warmth;
        model.motivation =
            (data['motivation'] as num?)?.toDouble() ?? model.motivation;
        model.attunement =
            (data['attunement'] as num?)?.toDouble() ?? model.attunement;
      } catch (_) {
        // If anything goes wrong, fall back to defaults.
      }
    }
    _loaded = true;
  }

  Future<void> update({
    double? trust,
    double? warmth,
    double? motivation,
    double? attunement,
  }) async {
    if (!_loaded) {
      await load();
    }
    if (trust != null) model.trust = trust;
    if (warmth != null) model.warmth = warmth;
    if (motivation != null) model.motivation = motivation;
    if (attunement != null) model.attunement = attunement;
    await _persist();
    model.notifyListeners();
  }

  Future<void> _persist() async {
    final prefs = await SharedPreferences.getInstance();
    final data = <String, dynamic>{
      'trust': model.trust,
      'warmth': model.warmth,
      'motivation': model.motivation,
      'attunement': model.attunement,
    };
    await prefs.setString(_storageKey, json.encode(data));
  }
}
