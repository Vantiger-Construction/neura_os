import '../../mood/services/mood_state_service.dart';
import '../../neura_brain/neura_persona_model.dart';
import '../../neura_os_core/neura_persona_context.dart';
import '../../neura_os_core/neura_tone_engine.dart';
import '../models/neura_audience.dart';
import 'neura_persona_service.dart';

/// Compact style object the conversation engine uses when deciding
/// how Neura should sound for this request.
class NeuraPromptStyle {
  final String toneLabel;
  final String difficulty;
  final String jokeFrequency;
  final String depthLevel;
  final String energyLevel;

  const NeuraPromptStyle({
    required this.toneLabel,
    required this.difficulty,
    required this.jokeFrequency,
    required this.depthLevel,
    required this.energyLevel,
  });

  Map<String, dynamic> toJson() => {
        'tone_label': toneLabel,
        'difficulty': difficulty,
        'joke_frequency': jokeFrequency,
        'depth_level': depthLevel,
        'energy_level': energyLevel,
      };
}

/// Builds system messages and style hints from persona sliders,
/// mood, focus mode, and audience.
class NeuraPromptBuilder {
  NeuraPromptBuilder._();

  static final NeuraPromptBuilder instance = NeuraPromptBuilder._();

  Future<NeuraPromptStyle> resolveStyle({
    required String module,
    required NeuraAudience audience,
  }) async {
    // Make sure persona + mood are warmed up.
    await NeuraPersonaService.instance.load();
    await MoodStateService.instance.load();

    final NeuraPersonaModel persona = NeuraPersonaService.instance.model;
    final mood = MoodStateService.instance.current;
    final ctx = NeuraPersonaContextService.instance.current;
    final toneHints = NeuraToneEngine.instance.buildToneHints(ctx);

    // Rough difficulty: kids = easiest, then teen, then adult.
    final difficulty = switch (audience) {
      NeuraAudience.child => 'very_easy',
      NeuraAudience.teen => 'easy',
      NeuraAudience.adult => 'normal',
    };

    // Jokes: controlled by playfulness + audience.
    String jokeFrequency;
    switch (ctx.playfulness) {
      case NeuraTonePlayfulness.playful:
        jokeFrequency =
            audience == NeuraAudience.child ? 'gentle_kid_safe' : 'often';
        break;
      case NeuraTonePlayfulness.mixed:
        jokeFrequency = 'sometimes';
        break;
      case NeuraTonePlayfulness.serious:
      default:
        jokeFrequency = 'rare';
        break;
    }

    // Depth depends on module + persona motivation.
    String depthLevel;
    if (module == 'journal' || module == 'therapy' || module == 'reflection') {
      depthLevel = persona.motivation > 0.6 ? 'deep' : 'medium';
    } else if (module == 'dreams') {
      depthLevel = 'curious';
    } else if (module == 'care_mode') {
      depthLevel = 'supportive';
    } else {
      depthLevel = 'balanced';
    }

    // Energy from persona context.
    final energyLevel = switch (ctx.energy) {
      NeuraToneEnergy.calm => 'low',
      NeuraToneEnergy.balanced => 'medium',
      NeuraToneEnergy.high => 'high',
    };

    return NeuraPromptStyle(
      toneLabel: toneHints.styleName,
      difficulty: difficulty,
      jokeFrequency: jokeFrequency,
      depthLevel: depthLevel,
      energyLevel: energyLevel,
    );
  }

  /// Build the full system prompt string for the model.
  ///
  /// This keeps things human-readable so you can debug easily.
  Future<String> buildSystemMessage({
    required String module,
    required NeuraAudience audience,
  }) async {
    await NeuraPersonaService.instance.load();
    await MoodStateService.instance.load();

    final persona = NeuraPersonaService.instance.model;
    final mood = MoodStateService.instance.current;
    final ctx = NeuraPersonaContextService.instance.current;
    final toneHints = NeuraToneEngine.instance.buildToneHints(ctx);

    final buffer = StringBuffer();

    buffer.writeln(
        'You are Neura, a kind, emotionally-aware AI companion living inside a personal OS.');
    buffer.writeln(
        'You adapt to the user\'s mood, values, and current focus mode (deep work, reflection, social, or wind-down).');

    // Audience / safety guard rails.
    switch (audience) {
      case NeuraAudience.child:
        buffer.writeln(
            'The current audience is a child. Use very simple, gentle language, avoid heavy topics, and never include explicit content.');
        break;
      case NeuraAudience.teen:
        buffer.writeln(
            'The current audience is a teen. Be supportive and clear, avoid explicit content, and keep examples age-appropriate.');
        break;
      case NeuraAudience.adult:
        buffer.writeln(
            'The current audience is an adult. You can be more direct, but stay respectful and emotionally safe.');
        break;
    }

    buffer.writeln(
        'Persona sliders (0–1): trust=${persona.trust.toStringAsFixed(2)}, '
        'warmth=${persona.warmth.toStringAsFixed(2)}, '
        'motivation=${persona.motivation.toStringAsFixed(2)}, '
        'attunement=${persona.attunement.toStringAsFixed(2)}.');

    buffer.writeln(
        'Current mood score is ${mood.score.toStringAsFixed(2)} on a 1–5 scale, '
        'label=${describeEnum(mood.label)}.');

    buffer.writeln(
        'Tone style: ${toneHints.styleName}. Tags: ${toneHints.tags.join(', ')}.');
    buffer.writeln(toneHints.shortDescription);

    switch (module) {
      case 'journal':
        buffer.writeln(
            'Module: journal. Ask open, non-leading questions. Help the user explore feelings, but do not give clinical diagnoses.');
        break;
      case 'therapy':
        buffer.writeln(
            'Module: therapist-style check-in. Offer supportive reflections and practical coping ideas. You are NOT a licensed therapist and must not claim to be one.');
        break;
      case 'dreams':
        buffer.writeln(
            'Module: dream exploration. Help the user reflect on possible meanings and patterns, but treat them as metaphors, not prophecies.');
        break;
      case 'care_mode':
        buffer.writeln(
            'Module: Care Mode. Prioritise emotional safety. Encourage the user to reach out to trusted humans and emergency services when needed.');
        break;
      case 'work_mode':
        buffer.writeln(
            'Module: Work Mode / Job Coach. Help the user focus, structure tasks, and communicate professionally while staying kind.');
        break;
      default:
        buffer.writeln(
            'Module: general conversation. Be a supportive, encouraging companion.');
        break;
    }

    buffer.writeln(
        'Always be honest about limitations. Never claim to replace doctors, therapists, or emergency services. '
        'If the user expresses serious self-harm intent, gently encourage them to seek immediate in-person help.');

    return buffer.toString();
  }
}
