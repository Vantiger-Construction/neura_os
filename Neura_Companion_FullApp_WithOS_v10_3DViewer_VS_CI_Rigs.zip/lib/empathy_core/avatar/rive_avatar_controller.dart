
import 'package:flutter/material.dart';
class NeuraRiveAvatarController extends StatefulWidget {
  const NeuraRiveAvatarController({super.key});
  static Future<void> applyVisemes(List<Map<String, dynamic>> _) async {}
  static void setBlinksPerMinute(double _) {}
  static void setHeadTiltDegrees(double _) {}
  @override
  State<NeuraRiveAvatarController> createState() => _NeuraRiveAvatarControllerState();
}
class _NeuraRiveAvatarControllerState extends State<NeuraRiveAvatarController> {
  @override
  Widget build(BuildContext context) {
    return Container(
      height: 220, width: 220,
      decoration: BoxDecoration(
        shape: BoxShape.circle,
        gradient: const LinearGradient(colors: [Color(0xFFFFB84D), Color(0xFFFFF0C2)]),
        boxShadow: [BoxShadow(color: Colors.black26, blurRadius: 16, spreadRadius: 2)],
      ),
      child: const Center(child: Text('Rive Placeholder', style: TextStyle(fontSize: 12))),
    );
  }
}
