
// lib/empathy_core/avatar/rive_viseme_controller.dart
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:rive/rive.dart';

/// Drives a Rive state machine with three numeric inputs:
///   - viseme: double 0..5 (A,E,O,U,L,M)
///   - blinkRate: blinks per minute (approx; your SM should interpret it)
///   - headTilt: degrees 0..10 (tiny tilt)
///
/// Timeline format expected: [{'t': secondsFromStart, 'shape': 'A'|'E'|'O'|'U'|'L'|'M'}, ...]
class NeuraRiveVisemeController extends StatefulWidget {
  final String riveAsset;
  final String stateMachineName;
  final String visemeInput;
  final String blinkRateInput;
  final String headTiltInput;

  const NeuraRiveVisemeController({
    super.key,
    this.riveAsset = 'assets/avatars/NeuraFace.riv',
    this.stateMachineName = 'NeuraSM',
    this.visemeInput = 'viseme',
    this.blinkRateInput = 'blinkRate',
    this.headTiltInput = 'headTilt',
  });

  /// Static mapping helper for external callers.
  static int shapeIndex(String s) {
    switch (s.toUpperCase()) {
      case 'A': return 0;
      case 'E': return 1;
      case 'O': return 2;
      case 'U': return 3;
      case 'L': return 4;
      case 'M': return 5;
      default: return 0;
    }
  }

  @override
  State<NeuraRiveVisemeController> createState() => _NeuraRiveVisemeControllerState();
}

class _NeuraRiveVisemeControllerState extends State<NeuraRiveVisemeController> {
  Artboard? _artboard;
  StateMachineController? _sm;
  SMIInput<double>? _viseme;
  SMIInput<double>? _blinkRate;
  SMIInput<double>? _headTilt;

  Timer? _timelineTimer;
  DateTime? _timelineStart;
  List<Map<String, dynamic>> _timeline = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final data = await rootBundle.load(widget.riveAsset);
    final file = RiveFile.import(data);
    final art = file.mainArtboard;
    final sm = StateMachineController.fromArtboard(art, widget.stateMachineName);
    if (sm != null) {
      art.addController(sm);
      _sm = sm;
      _viseme    = sm.findInput<double>(widget.visemeInput);
      _blinkRate = sm.findInput<double>(widget.blinkRateInput);
      _headTilt  = sm.findInput<double>(widget.headTiltInput);
      // Defaults
      _viseme?.value = 0;
      _blinkRate?.value = 14; // comfy baseline
      _headTilt?.value = 0;
    }
    setState(()=> _artboard = art);
  }

  @override
  void dispose() {
    _timelineTimer?.cancel();
    super.dispose();
  }

  /// Public: apply a viseme timeline (restarts any previous one).
  void applyVisemeTimeline(List<Map<String, dynamic>> events) {
    _timelineTimer?.cancel();
    _timeline = List<Map<String, dynamic>>.from(events);
    _timelineStart = DateTime.now();
    if (_timeline.isEmpty) return;

    _tickTimeline(); // immediate first tick
    _timelineTimer = Timer.periodic(const Duration(milliseconds: 8), (_) => _tickTimeline());
  }

  void _tickTimeline() {
    if (_timelineStart == null || _timeline.isEmpty) return;
    final elapsed = DateTime.now().difference(_timelineStart!).inMilliseconds / 1000.0;

    // Find the most recent viseme event whose t <= elapsed
    Map<String, dynamic>? current;
    for (final e in _timeline) {
      final t = (e['t'] as num).toDouble();
      if (t <= elapsed) current = e; else break;
    }
    if (current != null) {
      final idx = NeuraRiveVisemeController.shapeIndex((current['shape'] as String?) ?? 'A');
      _viseme?.value = idx.toDouble();
    }

    // Stop after last event + grace
    final lastT = (_timeline.last['t'] as num).toDouble();
    if (elapsed > lastT + 0.2) {
      _timelineTimer?.cancel();
      _timelineTimer = null;
      // relax mouth
      _viseme?.value = 0;
    }
  }

  /// Public: map arousal [-1..+1] to blink cadence and micro tilt,
  /// and valence [-1..+1] to a tiny tilt direction (L<0, R>0).
  /// You can also listen to this externally for ambient color changes.
  void setAffect({required double arousal, required double valence}) {
    final a = arousal.clamp(-1.0, 1.0);
    final v = valence.clamp(-1.0, 1.0);

    // Blink cadence: baseline ~14 BPM, add ±10 * arousal
    final bpm = 14.0 + (a * 10.0);
    _blinkRate?.value = bpm.clamp(4, 40);

    // Tilt: direction from valence (left neg / right pos), magnitude from |arousal|
    final tilt = (a.abs() * 6.0) * (v >= 0 ? 1.0 : -1.0);
    _headTilt?.value = tilt.clamp(-10, 10).abs(); // SM expects 0..10
  }

  @override
  Widget build(BuildContext context) {
    if (_artboard == null) {
      return const SizedBox(height: 220, child: Center(child: CircularProgressIndicator()));
    }
    return SizedBox(height: 220, child: Rive(artboard: _artboard!));
  }
}
