
import 'dart:async';
import 'package:flutter/material.dart';
import 'package:lottie/lottie.dart';

class NeuraLottieAvatarController extends StatefulWidget {
  final String lottieAsset;
  const NeuraLottieAvatarController({super.key, this.lottieAsset = 'assets/neura/lottie/NeuraFace_Lottie.json'});
  @override
  State<NeuraLottieAvatarController> createState() => _NeuraLottieAvatarControllerState();
  static Future<void> applyVisemes(List<Map<String, dynamic>> visemes) async {}
}

class _NeuraLottieAvatarControllerState extends State<NeuraLottieAvatarController> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  Map<String, double> _markerTimes = {'A':0.05,'E':0.15,'O':0.25,'U':0.35,'L':0.45,'M':0.55};
  @override
  void initState() { super.initState(); _ctrl = AnimationController(vsync: this); }
  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }
  void jumpToShape(String s){ final p=_markerTimes[s.toUpperCase()]??0.05; _ctrl.value=p; }
  @override
  Widget build(BuildContext context) {
    return Lottie.asset(widget.lottieAsset, controller:_ctrl, fit:BoxFit.contain, onLoaded:(comp){
      _ctrl..duration=comp.duration..repeat();
      final markers = comp.markers;
      if (markers.isNotEmpty) {
        final map=<String,double>{};
        for (final m in markers) {
          final name = m.name.replaceFirst('viseme_', '').toUpperCase();
          map[name] = m.frame / comp.endFrame;
        }
        if (map.isNotEmpty) _markerTimes = map;
      }
    });
  }
}
