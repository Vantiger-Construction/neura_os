
// lib/empathy_core/voice/tts_engine.dart
import 'dart:async';
import 'viseme_sync.dart';

enum TTSProvider { softEcho, azure, elevenLabs, google }

/// Placeholder "SoftEcho" TTS: returns fake phoneme timings so
/// visemes can sync realistically to speech.
class NeuraTTSEngine {
  final TTSProvider provider;
  NeuraTTSEngine({this.provider = TTSProvider.softEcho});

  Future<void> startAmbientBreathLoop() async {}

  /// Returns phoneme timestamps (ARPABET-like) and a derived viseme timeline.
  /// Return shape: {'phonemes': [{'t':..,'p':'AH'},...], 'visemes':[{'t':..,'shape':'A'},...]}
  Future<Map<String, dynamic>> speakWithPhonemes(String text) async {
    // naive phoneme builder: space-separated words, each gets AH->L->M rhythm
    final words = text.trim().split(RegExp(r'\s+'));
    final ph = <Map<String, dynamic>>[];
    double t = 0.0;
    for (final w in words) {
      final dur = (w.length * 0.03 + 0.12);
      ph.add({'t': double.parse(t.toStringAsFixed(3)), 'p':'M'});
      ph.add({'t': double.parse((t + dur*0.4).toStringAsFixed(3)), 'p': _pickVowel(w)});
      ph.add({'t': double.parse((t + dur*0.8).toStringAsFixed(3)), 'p':'L'});
      t += dur + 0.04;
    }
    final vis = buildVisemeTimeline(ph).map((e)=>e.toJson()).toList();
    return {'phonemes': ph, 'visemes': vis};
  }

  String _pickVowel(String w) {
    final s = w.toLowerCase();
    if (RegExp(r'[ou]').hasMatch(s)) return 'UW';
    if (RegExp(r'[iey]').hasMatch(s)) return 'IY';
    return 'AH';
  }
}
