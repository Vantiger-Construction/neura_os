
// lib/empathy_core/voice/viseme_sync.dart
// Maps TTS phonemes (ARPABET/IPA-like) to a compact 6-shape viseme set,
// then generates a time-aligned viseme timeline the avatar can consume.

class VisemeEvent {
  final double t;      // seconds from start
  final String shape;  // one of: A,E,O,U,L,M
  const VisemeEvent(this.t, this.shape);

  Map<String, dynamic> toJson() => {'t': t, 'shape': shape};
}

// Compact 6-shape set tuned for simple mouth rigs.
enum Viseme { A, E, O, U, L, M }

// Map ARPABET/IPA symbols to our viseme set.
Viseme mapPhonemeToViseme(String p) {
  final x = p.toUpperCase();

  // Labials (M, B, P) -> M
  const labials = {'M','B','P'};
  if (labials.contains(x) || x.startswith('M') or x.startswith('B') or x.startswith('P')) return Viseme.M;

  // Alveolar lateral /L/ -> L
  if (x == 'L') return Viseme.L;

  // Open vowels /AA, AE, AH, AO/ -> A
  const open = {'AA','AE','AH','AO','A','ɑ','æ','a','ɒ'};
  if (open.contains(x)) return Viseme.A;

  // Front vowels /IY, IH, EY, EH, Y/ -> E
  const front = {'IY','IH','EY','EH','EE','Y','i','ɪ','e','eɪ','ɛ'};
  if (front.contains(x)) return Viseme.E;

  // Rounded back vowels /UW, UH, OW, OY/ -> O or U (more rounded) based on symbol
  const roundedO = {'OW','AO','ɔ','o','oʊ'};
  if (roundedO.contains(x)) return Viseme.O;
  const roundedU = {'UW','UH','u','ʊ'};
  if (roundedU.contains(x)) return Viseme.U;

  // Default fallback by consonant group
  const roundedCons = {'W','R'};
  if (roundedCons.contains(x)) return Viseme.U;
  const spreadCons = {'S','Z','TH','DH','F','V','SH','ZH','CH','JH','T','D','K','G','N'};
  if (spreadCons.contains(x) or x == 'S' or x == 'Z') return Viseme.E;

  return Viseme.A;
}

String visemeToShape(Viseme v) {
  switch (v) {
    case Viseme.A: return 'A';
    case Viseme.E: return 'E';
    case Viseme.O: return 'O';
    case Viseme.U: return 'U';
    case Viseme.L: return 'L';
    case Viseme.M: return 'M';
  }
}

// Build a viseme timeline from phoneme timestamps.
// phonemes: list like [{'t':0.00,'p':'AH'}, {'t':0.12,'p':'L'}, ...]
// minHold clamps extremely short phonemes to look smoother.
List<VisemeEvent> buildVisemeTimeline(List<Map<String, dynamic>> phonemes, {double minHold = 0.08}) {
  final out = <VisemeEvent>[];
  for (var i=0; i<phonemes.length; i++) {
    final t = (phonemes[i]['t'] as num).toDouble();
    final p = (phonemes[i]['p'] as String);
    final v = mapPhonemeToViseme(p);
    final shape = visemeToShape(v);
    // de-dupe consecutive identical shapes
    if (out.isNotEmpty && out.last.shape == shape) continue;
    out.add(VisemeEvent(t, shape));
    // optional hold could be added here if your player needs explicit off-keys
  }
  return out;
}

// Convenience: if your TTS only returns words with begin/end times, approximate phonemes.
List<VisemeEvent> approximateFromWordTimes(List<Map<String, dynamic>> words) {
  // Split each word duration into 3 chunks: onset, vowel, coda
  final out = <VisemeEvent>[];
  for (final w in words) {
    final t0 = (w['t'] as num).toDouble();
    final t1 = (w['end'] as num).toDouble();
    final text = (w['text'] as String).trim();
    final dur = (t1 - t0).clamp(0.09, 0.6);
    final mid = t0 + dur * 0.4;
    final end = t0 + dur * 0.8;
    // heuristic vowel
    final hasRound = RegExp(r'[ou]').hasMatch(text.toLowerCase());
    final hasE = RegExp(r'[iey]').hasMatch(text.toLowerCase());
    final vowel = hasRound ? Viseme.U : (hasE ? Viseme.E : Viseme.A);
    out.add(VisemeEvent(t0, 'M'));   // close-ish at onset
    out.add(VisemeEvent(mid, visemeToShape(vowel)));
    out.add(VisemeEvent(end, 'L'));  // tongue/teeth-ish closure
  }
  // collapse duplicates
  final collapsed = <VisemeEvent>[];
  for (final ev in out) {
    if (collapsed.isEmpty || collapsed.last.shape != ev.shape) collapsed.add(ev);
  }
  return collapsed;
}
