
// lib/empathy_core/affect/affect_to_micro.dart
/// Tiny helper to map (arousal, valence) into blink cadence, head tilt, and ambient hue.
import 'dart:ui';

class MicroAffect {
  final double blinkBpm;
  final double headTiltDeg; // 0..10
  final Color ambientColor;
  const MicroAffect(this.blinkBpm, this.headTiltDeg, this.ambientColor);
}

MicroAffect mapAffect({required double arousal, required double valence}) {
  final a = arousal.clamp(-1.0, 1.0);
  final v = valence.clamp(-1.0, 1.0);
  final bpm = (14.0 + a * 10.0).clamp(4.0, 40.0);

  // Tilt magnitude from |arousal|, direction from valence sign; clamp 0..10
  final tilt = (a.abs() * 6.0).clamp(0.0, 10.0);

  // Ambient hue: valence maps warm<->cool
  // warm (gold) for positive, cool (violet) for negative
  final warm = const Color(0xFFFFB84D);
  final cool = const Color(0xFF6C63FF);
  Color lerp(Color a, Color b, double t) => Color.lerp(a, b, t)!;
  final hue = v >= 0 ? lerp(cool, warm, v) : lerp(warm, cool, -v);

  return MicroAffect(bpm, tilt, hue);
}
