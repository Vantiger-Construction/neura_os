class JournalPromptService {
  /// Fetches an AI-style prompt based on mood and time of day.
  /// This is offline logic that can later be swapped with a cloud AI call.
  Future<String> fetchPrompt({String mood = '', DateTime? time}) async {
    final moodTag = (mood.trim().toLowerCase());
    final now = time ?? DateTime.now();
    final hour = now.hour;

    bool isMorning = hour >= 5 && hour < 12;
    bool isAfternoon = hour >= 12 && hour < 18;
    bool isEvening = hour >= 18 || hour < 5;

    if (moodTag.contains('happy')) {
      if (isMorning) {
        return 'You woke up in a good mood. What are you most looking forward to today?';
      } else if (isAfternoon) {
        return 'What has gone well so far today, and how can you build on that momentum?';
      } else {
        return 'Looking back on today, what small joy are you most grateful for?';
      }
    }

    if (moodTag.contains('anxious')) {
      if (isMorning) {
        return 'What is worrying you today, and what is one tiny thing you can control right now?';
      } else if (isAfternoon) {
        return 'Name three things that feel heavy right now. Which one could you lighten, even just a little?';
      } else {
        return 'Before sleep, what fears are looping in your mind, and what would you say to a friend who felt this way?';
      }
    }

    if (moodTag.contains('sad')) {
      return 'What loss or disappointment is resting in your chest right now, and what would comfort look like today?';
    }

    if (moodTag.contains('tired')) {
      return 'Your energy feels low. What have you been carrying lately, and what could you set down for a while?';
    }

    if (moodTag.contains('calm')) {
      return 'In this calm moment, what would you like to remember about this version of yourself?';
    }

    // Default neutral prompts
    if (isMorning) {
      return 'What kind of person do you want to be today, and what is one small action that matches that?';
    } else if (isAfternoon) {
      return 'How has today gone compared to what you expected this morning?';
    } else {
      return 'What story did today tell about you, and what story do you want tomorrow to tell?';
    }
  }
}
