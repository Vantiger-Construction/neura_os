import 'dart:typed_data';
import 'package:http/http.dart' as http;

class AzureSttClient {
  final String base;
  AzureSttClient(this.base);

  Future<String?> recognize(Uint8List wavBytes, {String language = 'en-US'}) async {
    final uri = Uri.parse('$base/stt/azure/recognize');
    final req = http.MultipartRequest('POST', uri);
    req.fields['language'] = language;
    req.files.add(http.MultipartFile.fromBytes('file', wavBytes, filename: 'audio.wav', contentType: null));
    final resp = await req.send();
    final body = await http.Response.fromStream(resp);
    if (body.statusCode != 200) { throw Exception('STT failed: ${body.statusCode}'); }
    return body.body;
  }
}
