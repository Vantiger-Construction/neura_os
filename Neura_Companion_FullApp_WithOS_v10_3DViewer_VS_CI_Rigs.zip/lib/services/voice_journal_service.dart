import 'dart:async';

/// Simple in-memory voice journal stub.
/// The actual audio/STT integration can be swapped in later, but this
/// implementation guarantees non-null, non-empty behavior.
class VoiceJournalService {
  bool _isRecording = false;
  final StringBuffer _buffer = StringBuffer();

  /// Starts voice "recording".
  /// In this offline stub we just reset the buffer and mark the state.
  Future<void> startRecording() async {
    _isRecording = true;
    _buffer
      ..clear()
      ..write('Voice entry started. ');
  }

  /// Stops recording and returns a fake transcript.
  /// This guarantees a non-empty string for the UI to display.
  Future<String> stopRecording() async {
    if (!_isRecording) {
      return 'No active recording. Tap record before stopping.';
    }
    _isRecording = false;
    _buffer.write('Voice entry finished. (Stub transcript – replace with STT.)');
    return _buffer.toString();
  }
}
