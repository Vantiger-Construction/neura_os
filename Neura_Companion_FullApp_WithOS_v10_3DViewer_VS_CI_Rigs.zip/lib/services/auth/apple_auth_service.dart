import 'dart:io';
import 'package:sign_in_with_apple/sign_in_with_apple.dart';
import 'package:firebase_auth/firebase_auth.dart';

class AppleAuthService {
  final _auth = FirebaseAuth.instance;

  Future<UserCredential?> signIn() async {
    if (!Platform.isIOS) return null;
    final result = await SignInWithApple.getAppleIDCredential(
      scopes: [AppleIDAuthorizationScopes.email, AppleIDAuthorizationScopes.fullName],
    );
    final oauth = OAuthProvider('apple.com').credential(
      idToken: result.identityToken, accessToken: result.authorizationCode);
    return _auth.signInWithCredential(oauth);
  }
}
