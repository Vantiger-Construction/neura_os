import 'package:google_sign_in/google_sign_in.dart';
import 'package:firebase_auth/firebase_auth.dart';

class GoogleAuthService {
  final _google = GoogleSignIn(scopes: ['email']);
  final _auth = FirebaseAuth.instance;

  Future<UserCredential?> signIn() async {
    final account = await _google.signIn();
    if (account == null) return null;
    final auth = await account.authentication;
    final credential = GoogleAuthProvider.credential(
      accessToken: auth.accessToken, idToken: auth.idToken);
    return _auth.signInWithCredential(credential);
  }

  Future<void> signOut() async {
    await _auth.signOut();
    await _google.disconnect();
  }

  User? get currentUser => _auth.currentUser;
}
