import 'package:firebase_messaging/firebase_messaging.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';

class NotificationsService {
  final _fcm = FirebaseMessaging.instance;
  final _local = FlutterLocalNotificationsPlugin();

  Future<String?> init() async {
    await _fcm.requestPermission();
    final token = await _fcm.getToken();
    const android = AndroidInitializationSettings('@mipmap/ic_launcher');
    const ios = DarwinInitializationSettings();
    await _local.initialize(const InitializationSettings(android: android, iOS: ios));
    FirebaseMessaging.onMessage.listen((RemoteMessage m) async {
      final n = m.notification;
      if (n != null) {
        await _local.show(
          0,
          n.title,
          n.body,
          const NotificationDetails(
            android: AndroidNotificationDetails('default', 'General'),
            iOS: DarwinNotificationDetails(),
          ),
        );
      }
    });
    return token;
  }
}
