class EmotionAnalysisService {
  /// Analyzes text and returns a simple mood tag.
  /// This is a lightweight, offline heuristic so the app works without cloud.
  Future<String> analyzeEmotion(String text) async {
    final lower = text.toLowerCase();

    // Very naive keyword-based heuristic, but better than an empty string.
    if (lower.contains('happy') ||
        lower.contains('great') ||
        lower.contains('excited') ||
        lower.contains('love') ||
        lower.contains('awesome')) {
      return 'happy';
    }

    if (lower.contains('calm') ||
        lower.contains('peaceful') ||
        lower.contains('relaxed')) {
      return 'calm';
    }

    if (lower.contains('tired') ||
        lower.contains('exhausted') ||
        lower.contains('drained')) {
      return 'tired';
    }

    if (lower.contains('anxious') ||
        lower.contains('worried') ||
        lower.contains('stressed') ||
        lower.contains('overwhelmed')) {
      return 'anxious';
    }

    if (lower.contains('sad') ||
        lower.contains('down') ||
        lower.contains('depressed') ||
        lower.contains('lonely')) {
      return 'sad';
    }

    // Default neutral / unknown.
    return 'neutral';
  }
}
