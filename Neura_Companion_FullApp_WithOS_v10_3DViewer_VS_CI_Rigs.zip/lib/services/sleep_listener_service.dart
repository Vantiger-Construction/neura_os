import 'dart:async';

/// Stub sleep listener that pretends to record sleep audio.
/// This keeps the app stable while you decide on the real audio pipeline.
class SleepListenerService {
  bool _recording = false;

  /// Starts recording audio during sleep.
  Future<void> startRecording() async {
    _recording = true;
  }

  /// Stops recording and returns path to a "saved" audio file.
  /// In this stub, we just return a fake local path.
  Future<String> stopRecording() async {
    if (!_recording) {
      return '';
    }
    _recording = false;
    return '/tmp/neura_sleep_recording_stub.wav';
  }
}
