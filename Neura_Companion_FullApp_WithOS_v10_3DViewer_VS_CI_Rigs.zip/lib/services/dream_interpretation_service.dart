class DreamInterpretationService {
  /// Returns a lightweight interpretation string for a dream description.
  /// This keeps the feature usable offline while allowing future AI upgrades.
  Future<String> interpret(String description) async {
    final lower = description.toLowerCase();

    if (lower.contains('falling')) {
      return 'Falling often points to feeling out of control or afraid of failure.';
    }
    if (lower.contains('flying')) {
      return 'Flying can symbolize freedom, hope, or escaping limits.';
    }
    if (lower.contains('chased') || lower.contains('running')) {
      return 'Being chased can reflect stress or something you are avoiding in waking life.';
    }
    if (lower.contains('water') || lower.contains('ocean') || lower.contains('river')) {
      return 'Water in dreams often relates to emotions and how deeply you are feeling them.';
    }
    if (lower.contains('house') || lower.contains('home')) {
      return 'A house can symbolize your inner world – different rooms as different parts of you.';
    }

    // Default interpretation
    return 'This dream carries pieces of your current thoughts and emotions. Focus on what felt strongest – that feeling is your main clue.';
  }
}
