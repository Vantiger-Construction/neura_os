import 'dart:typed_data';
import 'package:http/http.dart' as http;

class AzureTtsClient {
  final String base; // e.g., http://localhost:8000
  AzureTtsClient(this.base);

  Future<Uint8List> speak(String text, {String voice = 'en-US-JennyNeural'}) async {
    final uri = Uri.parse('$base/tts/azure/speak?text=${Uri.encodeComponent(text)}&voice=$voice');
    final r = await http.post(uri);
    if (r.statusCode != 200) { throw Exception('TTS failed: ${r.statusCode}'); }
    return r.bodyBytes;
  }
}
