import 'dart:async';
import 'package:in_app_purchase/in_app_purchase.dart';

class BillingService {
  final InAppPurchase _iap = InAppPurchase.instance;
  StreamSubscription<List<PurchaseDetails>>? _sub;

  Future<void> init(void Function(PurchaseDetails) onPurchaseUpdate) async {
    final available = await _iap.isAvailable();
    if (!available) return;
    _sub = _iap.purchaseStream.listen((purchases) {
      for (final p in purchases) {
        onPurchaseUpdate(p);
      }
    });
  }

  Future<ProductDetailsResponse> queryProducts(Set<String> ids) {
    return _iap.queryProductDetails(ids);
  }

  Future<void> buy(ProductDetails p) async {
    final purchaseParam = PurchaseParam(productDetails: p);
    await _iap.buyNonConsumable(purchaseParam: purchaseParam);
  }

  Future<void> dispose() async {
    await _sub?.cancel();
  }
}
