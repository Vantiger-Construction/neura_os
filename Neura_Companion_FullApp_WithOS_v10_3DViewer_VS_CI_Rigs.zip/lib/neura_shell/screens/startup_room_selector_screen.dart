import 'package:flutter/material.dart';

import '../models/neura_room.dart';
import '../state/neura_shell_scope.dart';

class StartupRoomSelectorScreen extends StatelessWidget {
  const StartupRoomSelectorScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final shell = NeuraShellScope.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Choose Your Starting Room'),
        centerTitle: true,
      ),
      body: Padding(
        padding: const EdgeInsets.all(16),
        child: GridView.count(
          crossAxisCount: MediaQuery.of(context).size.width > 700 ? 3 : 2,
          mainAxisSpacing: 16,
          crossAxisSpacing: 16,
          children: neuraRooms.map((room) {
            return InkWell(
              borderRadius: BorderRadius.circular(24),
              onTap: () async {
                await shell.setStartupRoom(room.id);
              },
              child: Card(
                shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(24),
                ),
                elevation: 4,
                child: Padding(
                  padding: const EdgeInsets.all(16),
                  child: Column(
                    mainAxisAlignment: MainAxisAlignment.center,
                    children: [
                      Icon(room.icon, size: 40),
                      const SizedBox(height: 12),
                      Text(
                        room.title,
                        textAlign: TextAlign.center,
                        style: const TextStyle(
                          fontSize: 16,
                          fontWeight: FontWeight.bold,
                        ),
                      ),
                      const SizedBox(height: 6),
                      Text(
                        room.subtitle,
                        textAlign: TextAlign.center,
                        style: TextStyle(
                          fontSize: 13,
                          color: Colors.white70,
                        ),
                      ),
                    ],
                  ),
                ),
              ),
            );
          }).toList(),
        ),
      ),
    );
  }
}
