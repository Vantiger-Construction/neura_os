import 'package:flutter/material.dart';

import '../models/neura_room.dart';
import '../rooms/penthouse_room.dart';
import '../rooms/mood_den_room.dart';
import '../rooms/dream_bay_room.dart';
import '../rooms/reflection_bay_room.dart';
import '../rooms/clinical_bay_room.dart';
import '../rooms/legacy_hall_room.dart';
import '../state/neura_shell_scope.dart';

import '../../neura_3d/screens/neura_3d_viewer_screen.dart';

/// Main "world" view that hosts all Neura OS rooms and navigation.
///
/// This does NOT create the NeuraShellState – it expects you to have
/// wrapped your app with NeuraShellScope already. It just:
///   - Reads the current room from NeuraShellState
///   - Shows the corresponding room widget
///   - Provides a bottom navigation bar to move between rooms
///   - Links to Neura OS Settings
class NeuraOsShellScreen extends StatelessWidget {
  const NeuraOsShellScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final shell = NeuraShellScope.of(context);

    return AnimatedBuilder(
      animation: shell,
      builder: (context, _) {
        if (shell.isLoading) {
          return const Scaffold(
            body: Center(
              child: CircularProgressIndicator(),
            ),
          );
        }

        final room = shell.currentRoom;
        final rooms = NeuraRoomId.values;
        final currentIndex = rooms.indexOf(room).clamp(0, rooms.length - 1);

        return Scaffold(
          appBar: AppBar(
            title: const Text('Neura OS'),
            actions: [
              IconButton(
                tooltip: 'Neura 3D Lab',
                icon: const Icon(Icons.view_in_ar_rounded),
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => const Neura3DViewerScreen(),
                    ),
                  );
                },
              ),
              IconButton(
                tooltip: 'Neura OS Settings',
                icon: const Icon(Icons.settings_suggest_rounded),
                onPressed: () {
                  Navigator.of(context).pushNamed('/neura/settings');
                },
              ),
            ],
          ),
          body: _buildRoomBody(room),
          bottomNavigationBar: BottomNavigationBar(
            currentIndex: currentIndex,
            onTap: (index) {
              if (index < 0 || index >= rooms.length) return;
              final target = rooms[index];
              shell.switchRoom(target);
            },
            type: BottomNavigationBarType.fixed,
            items: [
              for (final r in rooms)
                BottomNavigationBarItem(
                  icon: Icon(_iconForRoom(r)),
                  label: _labelForRoom(r),
                ),
            ],
          ),
        );
      },
    );
  }

  Widget _buildRoomBody(NeuraRoomId room) {
    switch (room) {
      case NeuraRoomId.penthouse:
        return const PenthouseRoom();
      case NeuraRoomId.mood_den:
        return const MoodDenRoom();
      case NeuraRoomId.dream_bay:
        return const DreamBayRoom();
      case NeuraRoomId.reflection_bay:
        return const ReflectionBayRoom();
      case NeuraRoomId.clinical_bay:
        return const ClinicalBayRoom();
      case NeuraRoomId.legacy_hall:
        return const LegacyHallRoom();
    }
  }

  IconData _iconForRoom(NeuraRoomId room) {
    final name = room.name;

    if (name.contains('penthouse')) {
      return Icons.home_rounded;
    }
    if (name.contains('mood')) {
      return Icons.auto_awesome_rounded;
    }
    if (name.contains('dream')) {
      return Icons.bedtime_rounded;
    }
    if (name.contains('reflection')) {
      return Icons.self_improvement_rounded;
    }
    if (name.contains('clinical')) {
      return Icons.health_and_safety_rounded;
    }
    if (name.contains('legacy') || name.contains('hall')) {
      return Icons.museum_rounded;
    }

    return Icons.circle_rounded;
  }

  String _labelForRoom(NeuraRoomId room) {
    final raw = room.name;
    if (raw.isEmpty) return 'Room';

    final withSpaces = raw.replaceAll('_', ' ');
    final capitalised =
        withSpaces[0].toUpperCase() + withSpaces.substring(1);
    return capitalised;
  }
}
