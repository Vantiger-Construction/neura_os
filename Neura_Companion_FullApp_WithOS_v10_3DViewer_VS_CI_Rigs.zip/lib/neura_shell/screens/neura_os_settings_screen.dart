import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/neura_room.dart';
import '../state/neura_shell_scope.dart';

/// Central settings panel for the Neura OS shell.
///
/// This screen:
///   * Lets you choose the startup room
///   * Toggles Neura's voice greeting on launch (stored in SharedPreferences)
///   * Toggles a global "show Neura everywhere" flag (stored in SharedPreferences)
///   * Surfaces Self-Heal Safe Mode toggle from NeuraSelfHealService
///
/// It does NOT touch any platform settings. All prefs are app-local.
class NeuraOsSettingsScreen extends StatefulWidget {
  const NeuraOsSettingsScreen({super.key});

  @override
  State<NeuraOsSettingsScreen> createState() =>
      _NeuraOsSettingsScreenState();
}

class _NeuraOsSettingsScreenState extends State<NeuraOsSettingsScreen> {
  static const _prefVoiceGreetingKey =
      'neura_pref_voice_greeting_enabled_v1';
  static const _prefAvatarOverlayKey =
      'neura_pref_avatar_overlay_enabled_v1';

  bool _loading = true;
  bool _voiceGreetingEnabled = true;
  bool _avatarOverlayEnabled = true;

  @override
  void initState() {
    super.initState();
    _loadPrefs();
  }

  Future<void> _loadPrefs() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      setState(() {
        _voiceGreetingEnabled =
            prefs.getBool(_prefVoiceGreetingKey) ?? true;
        _avatarOverlayEnabled =
            prefs.getBool(_prefAvatarOverlayKey) ?? true;
        _loading = false;
      });
    } catch (_) {
      setState(() {
        _loading = false;
      });
    }
  }

  Future<void> _setVoiceGreetingEnabled(bool value) async {
    setState(() {
      _voiceGreetingEnabled = value;
    });
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_prefVoiceGreetingKey, value);
    } catch (_) {
      // ignore
    }
  }

  Future<void> _setAvatarOverlayEnabled(bool value) async {
    setState(() {
      _avatarOverlayEnabled = value;
    });
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setBool(_prefAvatarOverlayKey, value);
    } catch (_) {
      // ignore
    }
  }

  @override
  Widget build(BuildContext context) {
    final shell = NeuraShellScope.of(context);

    final theme = Theme.of(context);
    final startupRoom =
        shell.startupRoom ?? shell.currentRoom;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Neura OS Settings'),
      ),
      body: _loading
          ? const Center(
              child: CircularProgressIndicator(),
            )
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Text(
                  'Shell & startup',
                  style: theme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Tune how Neura OS behaves when it first wakes up '
                  'and how visible Neura is around the app.',
                  style: theme.textTheme.bodyMedium,
                ),
                const SizedBox(height: 16),
                _buildStartupRoomTile(context, startupRoom),
                const SizedBox(height: 12),
                SwitchListTile(
                  value: _voiceGreetingEnabled,
                  onChanged: _setVoiceGreetingEnabled,
                  title: const Text('Voice greeting on launch'),
                  subtitle: const Text(
                    'When enabled, Neura can say a short hello when she '
                    'wakes up or when you enter her world.',
                  ),
                ),
                SwitchListTile(
                  value: _avatarOverlayEnabled,
                  onChanged: _setAvatarOverlayEnabled,
                  title: const Text('Show Neura on every screen'),
                  subtitle: const Text(
                    'When enabled, your Neura avatar can float on other '
                    'screens too, not just the main OS views. '
                    'Hook this flag into your app scaffold if you want '
                    'a truly omnipresent companion.',
                  ),
                ),
                const SizedBox(height: 24),
                Text(
                  'Stability & recovery',
                  style: theme.textTheme.titleLarge?.copyWith(
                    fontWeight: FontWeight.bold,
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  'Safe Mode and automatic fixes are controlled here. '
                  'These settings do not change any of your data. They just '
                  'influence how Neura responds around errors.',
                  style: theme.textTheme.bodyMedium,
                ),
                const SizedBox(height: 12),
                SwitchListTile(
                  value: shell.selfHeal.safeMode,
                  onChanged: (value) {
                    shell.selfHeal.setSafeMode(value);
                    setState(() {}); // rebuild to reflect new state
                  },
                  title: const Text('Safe Mode'),
                  subtitle: const Text(
                    'In Safe Mode, Neura will favor simpler behaviour and '
                    'turn off some risky or experimental features when '
                    'errors are detected.',
                  ),
                ),
                ListTile(
                  leading: const Icon(Icons.developer_board_rounded),
                  title: const Text('Open Diagnostics & Self-Heal'),
                  subtitle: const Text(
                    'See internal logs, run health checks, and trigger '
                    'Dimensional Sync if needed.',
                  ),
                  onTap: () {
                    Navigator.of(context).pushNamed('/neura/diagnostics');
                  },
                ),
              ],
            ),
    );
  }

  Widget _buildStartupRoomTile(
    BuildContext context,
    NeuraRoomId startupRoom,
  ) {
    final theme = Theme.of(context);

    return ListTile(
      contentPadding: const EdgeInsets.symmetric(
        horizontal: 0,
        vertical: 4,
      ),
      leading: const Icon(Icons.home_rounded),
      title: const Text('Start Neura in'),
      subtitle: Text(
        _roomLabel(startupRoom),
        style: theme.textTheme.bodyMedium?.copyWith(
          fontWeight: FontWeight.w600,
        ),
      ),
      trailing: const Icon(Icons.chevron_right_rounded),
      onTap: () => _showStartupRoomPicker(context, startupRoom),
    );
  }

  Future<void> _showStartupRoomPicker(
    BuildContext context,
    NeuraRoomId current,
  ) async {
    final shell = NeuraShellScope.of(context);

    final selected = await showModalBottomSheet<NeuraRoomId>(
      context: context,
      builder: (context) {
        final rooms = NeuraRoomId.values;
        return SafeArea(
          child: ListView.separated(
            shrinkWrap: true,
            itemCount: rooms.length,
            separatorBuilder: (_, __) => const Divider(height: 0),
            itemBuilder: (context, index) {
              final room = rooms[index];
              final selected = room == current;
              return ListTile(
                leading: Icon(
                  selected
                      ? Icons.radio_button_checked_rounded
                      : Icons.radio_button_unchecked_rounded,
                ),
                title: Text(_roomLabel(room)),
                onTap: () {
                  Navigator.of(context).pop(room);
                },
              );
            },
          ),
        );
      },
    );

    if (selected == null) return;

    await shell.setStartupRoom(selected);
    if (!mounted) return;
    setState(() {});
  }

  String _roomLabel(NeuraRoomId room) {
    final raw = room.name;
    if (raw.isEmpty) return 'Unknown';

    // Simple "nice" formatting:
    //  - Replace underscores with spaces
    //  - Capitalise first letter
    final withSpaces = raw.replaceAll('_', ' ');
    return withSpaces[0].toUpperCase() + withSpaces.substring(1);
  }
}
