import 'package:flutter/material.dart';

import '../state/neura_shell_scope.dart';
import 'startup_room_selector_screen.dart';
import '../widgets/neura_shell_scaffold.dart';

class NeuraShellRootScreen extends StatelessWidget {
  const NeuraShellRootScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final shell = NeuraShellScope.of(context);

    if (shell.isLoading) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    if (shell.startupRoom == null) {
      return const StartupRoomSelectorScreen();
    }

    return const NeuraShellScaffold();
  }
}
