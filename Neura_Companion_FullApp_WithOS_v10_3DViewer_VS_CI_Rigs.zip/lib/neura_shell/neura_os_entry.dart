import 'package:flutter/material.dart';

import 'state/neura_shell_state.dart';
import 'state/neura_shell_scope.dart';
import 'screens/neura_os_shell_screen.dart';

/// Convenience entry widget that wires up [NeuraShellState] and
/// exposes the Neura OS world.
///
/// Use this if you want a one-liner in `main.dart` like:
///
///   void main() {
///     runApp(const NeuraOsEntry());
///   }
///
/// By default it shows [NeuraOsShellScreen] as its content, but you
/// can wrap your own [MaterialApp] or navigation structure around it
/// by passing a [builder].
class NeuraOsEntry extends StatefulWidget {
  const NeuraOsEntry({
    super.key,
    this.builder,
  });

  /// Optional builder to customise how the shell is mounted.
  ///
  /// If null, [NeuraOsShellScreen] is used directly.
  ///
  /// Example:
  ///
  ///   NeuraOsEntry(
  ///     builder: (context, shell) {
  ///       return MaterialApp(
  ///         theme: myTheme,
  ///         home: const NeuraOsShellScreen(),
  ///       );
  ///     },
  ///   )
  final Widget Function(BuildContext context, NeuraShellState shell)?
      builder;

  @override
  State<NeuraOsEntry> createState() => _NeuraOsEntryState();
}

class _NeuraOsEntryState extends State<NeuraOsEntry> {
  late final NeuraShellState _shellState;

  @override
  void initState() {
    super.initState();
    _shellState = NeuraShellState();
  }

  @override
  void dispose() {
    _shellState.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return NeuraShellScope(
      state: _shellState,
      child: _buildChild(context),
    );
  }

  Widget _buildChild(BuildContext context) {
    final builder = widget.builder;
    if (builder != null) {
      return builder(context, _shellState);
    }

    // Default: basic MaterialApp around the OS shell.
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: 'Neura OS',
      home: const NeuraOsShellScreen(),
      // You can also wire your /neura/settings and /neura/diagnostics
      // routes here later if you prefer centralised routing.
    );
  }
}
