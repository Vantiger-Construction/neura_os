import 'package:flutter/material.dart';

import 'state/neura_shell_scope.dart';
import 'state/neura_shell_state.dart';
import 'screens/neura_shell_root_screen.dart';

class NeuraShellApp extends StatefulWidget {
  const NeuraShellApp({super.key});

  @override
  State<NeuraShellApp> createState() => _NeuraShellAppState();
}

class _NeuraShellAppState extends State<NeuraShellApp> {
  late final NeuraShellState _shellState;

  @override
  void initState() {
    super.initState();
    _shellState = NeuraShellState();
  }

  @override
  void dispose() {
    _shellState.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return NeuraShellScope(
      notifier: _shellState,
      child: MaterialApp(
        debugShowCheckedModeBanner: false,
        title: 'Neura Companion OS',
        theme: ThemeData(
          brightness: Brightness.dark,
          colorScheme: ColorScheme.fromSeed(
            seedColor: Color(0xFFB793FF),
            brightness: Brightness.dark,
          ),
          useMaterial3: true,
        ),
        home: const NeuraShellRootScreen(),
      ),
    );
  }
}
