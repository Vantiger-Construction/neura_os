import 'package:flutter/material.dart';

enum NeuraRoomId {
  penthouse,
  reflectionBay,
  moodDen,
  joyLounge,
  dreamBay,
  clinicalWing,
  legacyHall,
}

class NeuraRoomMeta {
  final NeuraRoomId id;
  final String title;
  final String subtitle;
  final IconData icon;

  const NeuraRoomMeta({
    required this.id,
    required this.title,
    required this.subtitle,
    required this.icon,
  });
}

const List<NeuraRoomMeta> neuraRooms = [
  NeuraRoomMeta(
    id: NeuraRoomId.penthouse,
    title: 'Neura Penthouse',
    subtitle: 'Your main sky hub',
    icon: Icons.home,
  ),
  NeuraRoomMeta(
    id: NeuraRoomId.reflectionBay,
    title: 'Reflection Bay',
    subtitle: 'Deep thoughts & journaling',
    icon: Icons.edit_note,
  ),
  NeuraRoomMeta(
    id: NeuraRoomId.moodDen,
    title: 'Mood Den',
    subtitle: 'Emotional weather & charts',
    icon: Icons.mood,
  ),
  NeuraRoomMeta(
    id: NeuraRoomId.joyLounge,
    title: 'Joy Lounge',
    subtitle: 'Music, play & celebration',
    icon: Icons.music_note,
  ),
  NeuraRoomMeta(
    id: NeuraRoomId.dreamBay,
    title: 'Dream Bay',
    subtitle: 'Sleep, dreams & shows',
    icon: Icons.nights_stay,
  ),
  NeuraRoomMeta(
    id: NeuraRoomId.clinicalWing,
    title: 'Clinical Wing',
    subtitle: 'Therapist / support tools',
    icon: Icons.health_and_safety,
  ),
  NeuraRoomMeta(
    id: NeuraRoomId.legacyHall,
    title: 'Legacy Hall',
    subtitle: 'Memories & future messages',
    icon: Icons.auto_stories,
  ),
];

NeuraRoomMeta roomMetaFor(NeuraRoomId id) =>
    neuraRooms.firstWhere((r) => r.id == id);
