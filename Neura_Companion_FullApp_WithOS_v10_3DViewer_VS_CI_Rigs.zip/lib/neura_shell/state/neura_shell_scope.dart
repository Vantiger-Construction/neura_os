import 'package:flutter/widgets.dart';

import 'neura_shell_state.dart';

class NeuraShellScope extends InheritedNotifier<NeuraShellState> {
  const NeuraShellScope({
    super.key,
    required NeuraShellState notifier,
    required Widget child,
  }) : super(notifier: notifier, child: child);

  static NeuraShellState of(BuildContext context) {
    final scope =
        context.dependOnInheritedWidgetOfExactType<NeuraShellScope>();
    assert(scope != null, 'NeuraShellScope not found in widget tree');
    return scope!.notifier!;
  }

  @override
  bool updateShouldNotify(NeuraShellScope oldWidget) =>
      notifier != oldWidget.notifier;
}
