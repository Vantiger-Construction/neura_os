import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../models/neura_room.dart';

class NeuraShellState extends ChangeNotifier {
  static const _prefKeyStartupRoom = 'neura_startup_room_v1';

  NeuraRoomId _currentRoom = NeuraRoomId.penthouse;
  NeuraRoomId? _startupRoom;
  bool _isLoading = true;

  NeuraShellState() {
    _loadStartupRoom();
  }

  bool get isLoading => _isLoading;
  NeuraRoomId get currentRoom => _currentRoom;
  NeuraRoomId? get startupRoom => _startupRoom;

  Future<void> _loadStartupRoom() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final roomName = prefs.getString(_prefKeyStartupRoom);

      if (roomName != null) {
        final parsed = NeuraRoomId.values.firstWhere(
          (r) => r.name == roomName,
          orElse: () => NeuraRoomId.penthouse,
        );
        _startupRoom = parsed;
        _currentRoom = parsed;
      }
    } catch (_) {
      // swallow & use defaults
    } finally {
      _isLoading = false;
      notifyListeners();
    }
  }

  Future<void> setStartupRoom(NeuraRoomId id) async {
    _startupRoom = id;
    _currentRoom = id;
    notifyListeners();
    try {
      final prefs = await SharedPreferences.getInstance();
      await prefs.setString(_prefKeyStartupRoom, id.name);
    } catch (_) {
      // ignore persist failure; state is still live in memory
    }
  }

  void switchRoom(NeuraRoomId id) {
    _currentRoom = id;
    notifyListeners();
  }
}
