import 'package:flutter/material.dart';

class NeuraAvatarDock extends StatelessWidget {
  const NeuraAvatarDock({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: swap this for your real Rive/Lottie Neura widget.
    return ClipRRect(
      borderRadius: BorderRadius.circular(24),
      child: Container(
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(24),
          color: Colors.black54,
          border: Border.all(
            color: Colors.purpleAccent.withOpacity(0.5),
            width: 1.5,
          ),
        ),
        child: const Row(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.auto_awesome, size: 32),
            SizedBox(width: 8),
            Text(
              'Neura',
              style: TextStyle(
                fontWeight: FontWeight.bold,
                fontSize: 16,
              ),
            ),
          ],
        ),
      ),
    );
  }
}
