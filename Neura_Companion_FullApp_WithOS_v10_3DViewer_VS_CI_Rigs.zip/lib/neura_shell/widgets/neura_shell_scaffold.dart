import 'package:flutter/material.dart';

import '../models/neura_room.dart';
import '../rooms/penthouse_room.dart';
import '../rooms/reflection_bay_room.dart';
import '../rooms/mood_den_room.dart';
import '../rooms/joy_lounge_room.dart';
import '../rooms/dream_bay_room.dart';
import '../rooms/clinical_wing_room.dart';
import '../rooms/legacy_hall_room.dart';
import '../state/neura_shell_scope.dart';
import 'neura_avatar_dock.dart';

class NeuraShellScaffold extends StatelessWidget {
  const NeuraShellScaffold({super.key});

  @override
  Widget build(BuildContext context) {
    final shell = NeuraShellScope.of(context);
    final currentRoom = shell.currentRoom;
    final meta = roomMetaFor(currentRoom);

    return LayoutBuilder(
      builder: (context, constraints) {
        final useRail = constraints.maxWidth >= 900;

        final content = Stack(
          children: [
            Container(
              decoration: const BoxDecoration(
                gradient: LinearGradient(
                  colors: [
                    Color(0xFF050510),
                    Color(0xFF15152A),
                  ],
                  begin: Alignment.topCenter,
                  end: Alignment.bottomCenter,
                ),
              ),
              child: SafeArea(
                child: _buildRoomContent(currentRoom),
              ),
            ),
            const Align(
              alignment: Alignment.bottomRight,
              child: Padding(
                padding: EdgeInsets.all(16),
                child: NeuraAvatarDock(),
              ),
            ),
          ],
        );

        if (useRail) {
          return Scaffold(
            body: Row(
              children: [
                NavigationRail(
                  selectedIndex:
                      NeuraRoomId.values.indexOf(shell.currentRoom),
                  leading: const Padding(
                    padding: EdgeInsets.all(8.0),
                    child: Icon(Icons.auto_awesome, size: 32),
                  ),
                  labelType: NavigationRailLabelType.all,
                  onDestinationSelected: (index) {
                    final id = NeuraRoomId.values[index];
                    shell.switchRoom(id);
                  },
                  destinations: neuraRooms
                      .map(
                        (room) => NavigationRailDestination(
                          icon: Icon(room.icon),
                          label: Text(room.title),
                        ),
                      )
                      .toList(),
                ),
                const VerticalDivider(width: 1),
                Expanded(child: content),
              ],
            ),
          );
        }

        return Scaffold(
          appBar: AppBar(
            title: Text(meta.title),
            centerTitle: true,
          ),
          body: content,
          bottomNavigationBar: NavigationBar(
            selectedIndex: NeuraRoomId.values.indexOf(shell.currentRoom),
            onDestinationSelected: (index) {
              final id = NeuraRoomId.values[index];
              shell.switchRoom(id);
            },
            destinations: neuraRooms
                .map(
                  (room) => NavigationDestination(
                    icon: Icon(room.icon),
                    label: room.title,
                  ),
                )
                .toList(),
          ),
        );
      },
    );
  }

  Widget _buildRoomContent(NeuraRoomId room) {
    switch (room) {
      case NeuraRoomId.penthouse:
        return const PenthouseRoom();
      case NeuraRoomId.reflectionBay:
        return const ReflectionBayRoom();
      case NeuraRoomId.moodDen:
        return const MoodDenRoom();
      case NeuraRoomId.joyLounge:
        return const JoyLoungeRoom();
      case NeuraRoomId.dreamBay:
        return const DreamBayRoom();
      case NeuraRoomId.clinicalWing:
        return const ClinicalWingRoom();
      case NeuraRoomId.legacyHall:
        return const LegacyHallRoom();
    }
  }
}
