import 'package:flutter/material.dart';

class MoodDenRoom extends StatelessWidget {
  const MoodDenRoom({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: Plug in mood charts, emotion forecasting, history timeline.
    return const Center(
      child: Text(
        'Mood Den\n(Emotional weather, charts, mood history)',
        textAlign: TextAlign.center,
        style: TextStyle(fontSize: 20),
      ),
    );
  }
}
