import 'package:flutter/material.dart';

class LegacyHallRoom extends StatelessWidget {
  const LegacyHallRoom({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: Legacy journaling, future messages, story timelines.
    return const Center(
      child: Text(
        'Legacy Hall\n(Memories, legacy, future messages)',
        textAlign: TextAlign.center,
        style: TextStyle(fontSize: 20),
      ),
    );
  }
}
