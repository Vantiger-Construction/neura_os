import 'package:flutter/material.dart';

class PenthouseRoom extends StatelessWidget {
  const PenthouseRoom({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: Mount your main dashboard widgets here.
    return const Center(
      child: Text(
        'Neura Penthouse\n(Main hub / dashboard)',
        textAlign: TextAlign.center,
        style: TextStyle(fontSize: 20),
      ),
    );
  }
}
