import 'package:flutter/material.dart';

class JoyLoungeRoom extends StatelessWidget {
  const JoyLoungeRoom({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: Music coach, games, celebrations, streak parties.
    return const Center(
      child: Text(
        'Joy Lounge\n(Music, fun, rewards, celebrations)',
        textAlign: TextAlign.center,
        style: TextStyle(fontSize: 20),
      ),
    );
  }
}
