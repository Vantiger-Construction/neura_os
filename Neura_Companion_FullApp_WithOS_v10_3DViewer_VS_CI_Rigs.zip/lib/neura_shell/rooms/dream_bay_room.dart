import 'package:flutter/material.dart';

class DreamBayRoom extends StatelessWidget {
  const DreamBayRoom({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: Dream listener, Dreamscape Visualizer, nightly & monthly shows.
    return const Center(
      child: Text(
        'Dream Bay\n(Sleep mode, dream capture & visualizer)',
        textAlign: TextAlign.center,
        style: TextStyle(fontSize: 20),
      ),
    );
  }
}
