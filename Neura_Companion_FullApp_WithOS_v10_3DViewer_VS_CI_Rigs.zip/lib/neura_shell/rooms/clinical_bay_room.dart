  import 'package:flutter/material.dart';

  import '../../neura_avatar/neura_avatar_mood.dart';
  import '../../neura_clinical/neura_clinical_engine.dart';
  import '../../neura_clinical/neura_clinical_models.dart';
  import '../../neura_clinical/widgets/neura_checkin_card.dart';
  import '../state/neura_shell_scope.dart';

  /// Clinical / Therapist room.
  ///
  /// Important: this is *not* an emergency service and it is not a diagnosis.
  /// The copy inside this room repeatedly reminds the user of that.
  class ClinicalBayRoom extends StatefulWidget {
    const ClinicalBayRoom({super.key});

    @override
    State<ClinicalBayRoom> createState() => _ClinicalBayRoomState();
  }

  class _ClinicalBayRoomState extends State<ClinicalBayRoom> {
    bool _initialized = false;

    @override
    void didChangeDependencies() {
      super.didChangeDependencies();
      if (_initialized) return;
      _initialized = true;
      final shell = NeuraShellScope.of(context);
      shell.clinicalEngine.ensureLoaded();
    }

    @override
    Widget build(BuildContext context) {
      final shell = NeuraShellScope.of(context);
      final clinical = shell.clinicalEngine;

      return AnimatedBuilder(
        animation: clinical,
        builder: (context, _) {
          final today = DateTime.now();
          final todaysEntries = clinical.entriesForDay(today);
          final recent = clinical.recentEntries(30);
          final flaggedCount = clinical.flaggedSupportCount();

          return Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  'Clinical Bay',
                  style: Theme.of(context)
                      .textTheme
                      .headlineSmall
                      ?.copyWith(fontWeight: FontWeight.bold),
                ),
                const SizedBox(height: 4),
                Text(
                  'A calmer space for structured emotional check-ins. '
                  'This is not a crisis line or a diagnosis.',
                  style: Theme.of(context).textTheme.bodyMedium,
                ),
                const SizedBox(height: 12),
                _buildSafetyNotice(context),
                const SizedBox(height: 12),
                Row(
                  children: [
                    Expanded(
                      child: FilledButton.icon(
                        icon:
                            const Icon(Icons.bolt_rounded),
                        label: const Text('Quick check-in'),
                        onPressed: () =>
                            _openCheckInSheet(context, NeuraCheckInType.quick),
                      ),
                    ),
                    const SizedBox(width: 12),
                    Expanded(
                      child: FilledButton.tonalIcon(
                        icon: const Icon(Icons.menu_book_rounded),
                        label: const Text('Guided check-in'),
                        onPressed: () =>
                            _openCheckInSheet(context, NeuraCheckInType.guided),
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                _buildTodaySummary(context, todaysEntries.length, flaggedCount),
                const SizedBox(height: 8),
                Expanded(
                  child: recent.isEmpty
                      ? Center(
                          child: Text(
                            'No clinical check-ins logged yet.
'
                            'You can start with a short 0–10 intensity rating '
                            'and how you feel right now.',
                            textAlign: TextAlign.center,
                            style:
                                Theme.of(context).textTheme.bodyMedium,
                          ),
                        )
                      : ListView.separated(
                          itemCount: recent.length,
                          separatorBuilder: (_, __) =>
                              const SizedBox(height: 8),
                          itemBuilder: (context, index) {
                            final entry = recent[index];
                            return NeuraCheckInCard(
                              entry: entry,
                              onTap: () =>
                                  _showCheckInDetails(context, entry),
                            );
                          },
                        ),
                ),
              ],
            ),
          );
        },
      );
    }

    Widget _buildSafetyNotice(BuildContext context) {
      final theme = Theme.of(context);
      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: theme.colorScheme.errorContainer.withOpacity(0.9),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(
                  Icons.health_and_safety_rounded,
                  color: theme.colorScheme.onErrorContainer,
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: Text(
                    'Important safety note',
                    style: theme.textTheme.titleSmall?.copyWith(
                      fontWeight: FontWeight.w600,
                      color: theme.colorScheme.onErrorContainer,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 6),
            Text(
              'Neura Companion is not an emergency service and cannot by itself '
              'keep you safe. If you are in immediate danger, thinking about '
              'hurting yourself or someone else, or feel unable to stay safe, '
              'please contact your local emergency number or a crisis hotline '
              'in your area.',
              style: theme.textTheme.bodySmall?.copyWith(
                color:
                    theme.colorScheme.onErrorContainer.withOpacity(0.95),
              ),
            ),
          ],
        ),
      );
    }

    Widget _buildTodaySummary(
      BuildContext context,
      int todaysCount,
      int flaggedCount,
    ) {
      final theme = Theme.of(context);

      return Container(
        width: double.infinity,
        padding: const EdgeInsets.all(12),
        decoration: BoxDecoration(
          color: theme.colorScheme.surfaceVariant.withOpacity(0.9),
          borderRadius: BorderRadius.circular(16),
        ),
        child: Row(
          children: [
            Icon(
              Icons.today_rounded,
              color: theme.colorScheme.primary,
            ),
            const SizedBox(width: 8),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    'Today's check-ins: $todaysCount',
                    style: theme.textTheme.titleMedium?.copyWith(
                      fontWeight: FontWeight.w600,
                    ),
                  ),
                  const SizedBox(height: 2),
                  Text(
                    flaggedCount == 0
                        ? 'No entries today were flagged as "might need extra support".'
                        : '$flaggedCount recent entr${flaggedCount == 1 ? "y" : "ies"} '
                          'were flagged as "might need extra support".',
                    style: theme.textTheme.bodySmall,
                  ),
                ],
              ),
            ),
          ],
        ),
      );
    }

    Future<void> _openCheckInSheet(
      BuildContext context,
      NeuraCheckInType type,
    ) async {
      final result = await showModalBottomSheet<_CheckInDraft>(
        context: context,
        isScrollControlled: true,
        builder: (context) {
          return _CheckInSheet(type: type);
        },
      );

      if (result == null) return;

      final now = DateTime.now();
      final id = '${now.millisecondsSinceEpoch}_${type.name}';

      final entry = NeuraCheckInEntry(
        id: id,
        timestamp: now,
        type: type,
        mood: result.mood,
        intensity: result.intensity,
        note: result.note,
        flaggedForSupport: result.flaggedForSupport,
      );

      final shell = NeuraShellScope.of(context);
      await shell.clinicalEngine.addEntry(entry);

      // Also nudge persona / emotion lightly based on reported mood.
      shell.persona.registerCheckIn(
        positive: result.mood == NeuraAvatarMood.happy ||
            result.mood == NeuraAvatarMood.calm,
      );
      shell.emotionEngine.recordSnapshot(
        mood: result.mood,
        energy: result.intensity / 10.0,
        calm: result.mood == NeuraAvatarMood.calm ? 0.8 : 0.4,
        tension: result.mood == NeuraAvatarMood.anxious ? 0.8 : 0.3,
      );
    }

    void _showCheckInDetails(
      BuildContext context,
      NeuraCheckInEntry entry,
    ) {
      final theme = Theme.of(context);
      final date = entry.timestamp;
      final dateLabel =
          '${date.year}-${date.month.toString().padLeft(2, '0')}-${date.day.toString().padLeft(2, '0')} '
          '${date.hour.toString().padLeft(2, '0')}:'
          '${date.minute.toString().padLeft(2, '0')}';

      showDialog(
        context: context,
        builder: (context) {
          return AlertDialog(
            title: const Text('Check-in details'),
            content: SizedBox(
              width: double.maxFinite,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    dateLabel,
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: theme.hintColor,
                    ),
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Mood: ${entry.mood.name}',
                    style: theme.textTheme.bodyMedium,
                  ),
                  const SizedBox(height: 4),
                  Text(
                    'Intensity: ${entry.intensity.toStringAsFixed(1)} / 10',
                    style: theme.textTheme.bodyMedium,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    entry.note?.isNotEmpty == true
                        ? entry.note!
                        : 'No note was added for this check-in.',
                    style: theme.textTheme.bodyMedium,
                  ),
                  if (entry.flaggedForSupport) ...[
                    const SizedBox(height: 12),
                    Row(
                      children: [
                        Icon(
                          Icons.flag_rounded,
                          color: Colors.redAccent,
                        ),
                        const SizedBox(width: 6),
                        Text(
                          'Marked as "might need extra support".',
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: Colors.redAccent,
                          ),
                        ),
                      ],
                    ),
                  ],
                ],
              ),
            ),
            actions: [
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('Close'),
              ),
            ],
          );
        },
      );
    }
  }

  class _CheckInDraft {
    _CheckInDraft({
      required this.mood,
      required this.intensity,
      required this.flaggedForSupport,
      this.note,
    });

    final NeuraAvatarMood mood;
    final double intensity;
    final bool flaggedForSupport;
    final String? note;
  }

  class _CheckInSheet extends StatefulWidget {
    const _CheckInSheet({
      required this.type,
    });

    final NeuraCheckInType type;

    @override
    State<_CheckInSheet> createState() => _CheckInSheetState();
  }

  class _CheckInSheetState extends State<_CheckInSheet> {
    NeuraAvatarMood _selectedMood = NeuraAvatarMood.neutral;
    double _intensity = 5.0; // 0–10 scale
    bool _flaggedForSupport = false;
    final TextEditingController _noteController = TextEditingController();

    @override
    void dispose() {
      _noteController.dispose();
      super.dispose();
    }

    @override
    Widget build(BuildContext context) {
      final theme = Theme.of(context);
      final bottomInset = MediaQuery.of(context).viewInsets.bottom;

      final title = widget.type == NeuraCheckInType.quick
          ? 'Quick emotional check-in'
          : 'Guided check-in';

      final subtitle = widget.type == NeuraCheckInType.quick
          ? 'One slider, one feeling, one short note if you like.'
          : 'Take a moment to notice how you actually feel and how strong it is.';

      return Padding(
        padding: EdgeInsets.only(
          left: 16,
          right: 16,
          top: 16,
          bottom: bottomInset + 16,
        ),
        child: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Center(
                child: Container(
                  width: 40,
                  height: 4,
                  margin: const EdgeInsets.only(bottom: 10),
                  decoration: BoxDecoration(
                    color: theme.dividerColor,
                    borderRadius: BorderRadius.circular(999),
                  ),
                ),
              ),
              Text(
                title,
                style: theme.textTheme.titleLarge?.copyWith(
                  fontWeight: FontWeight.bold,
                ),
              ),
              const SizedBox(height: 4),
              Text(
                subtitle,
                style: theme.textTheme.bodyMedium,
              ),
              const SizedBox(height: 16),
              Text(
                'Right now, I feel mostly…',
                style: theme.textTheme.titleSmall,
              ),
              const SizedBox(height: 8),
              _buildMoodChips(context),
              const SizedBox(height: 16),
              Text(
                'How intense does it feel? (0–10)',
                style: theme.textTheme.titleSmall,
              ),
              Slider(
                min: 0,
                max: 10,
                divisions: 20,
                value: _intensity,
                label: _intensity.toStringAsFixed(1),
                onChanged: (v) => setState(() => _intensity = v),
              ),
              const SizedBox(height: 8),
              TextField(
                controller: _noteController,
                maxLines: 3,
                decoration: const InputDecoration(
                  labelText: 'Optional note',
                  hintText:
                      'Anything you want to remember or talk about later?',
                ),
              ),
              const SizedBox(height: 8),
              CheckboxListTile(
                value: _flaggedForSupport,
                onChanged: (v) =>
                    setState(() => _flaggedForSupport = v ?? false),
                title: const Text(
                  'I might want extra support with this later',
                ),
                controlAffinity: ListTileControlAffinity.leading,
              ),
              const SizedBox(height: 16),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton(
                      onPressed: () => Navigator.of(context).pop(),
                      child: const Text('Cancel'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: FilledButton(
                      onPressed: () => _submit(),
                      child: const Text('Save check-in'),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      );
    }

    Widget _buildMoodChips(BuildContext context) {
      final theme = Theme.of(context);

      final moodOptions = <NeuraAvatarMood, String>{
        NeuraAvatarMood.happy: 'Lighter',
        NeuraAvatarMood.calm: 'Calmer',
        NeuraAvatarMood.anxious: 'Stressed',
        NeuraAvatarMood.sad: 'Low',
        NeuraAvatarMood.tired: 'Tired',
        NeuraAvatarMood.neutral: 'Mixed',
      };

      return Wrap(
        spacing: 8,
        runSpacing: -4,
        children: moodOptions.entries.map((entry) {
          final selected = _selectedMood == entry.key;
          return ChoiceChip(
            label: Text(entry.value),
            selected: selected,
            onSelected: (_) =>
                setState(() => _selectedMood = entry.key),
            selectedColor: theme.colorScheme.primaryContainer,
          );
        }).toList(),
      );
    }

    void _submit() {
      Navigator.of(context).pop(
        _CheckInDraft(
          mood: _selectedMood,
          intensity: _intensity,
          flaggedForSupport: _flaggedForSupport,
          note: _noteController.text.trim().isEmpty
              ? null
              : _noteController.text.trim(),
        ),
      );
    }
  }
