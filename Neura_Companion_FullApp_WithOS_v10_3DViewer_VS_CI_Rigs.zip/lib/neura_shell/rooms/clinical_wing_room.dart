import 'package:flutter/material.dart';

class ClinicalWingRoom extends StatelessWidget {
  const ClinicalWingRoom({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: Therapist mode, check-ins, safety tools.
    return const Center(
      child: Text(
        'Clinical Wing\n(Therapist mode, support tools)',
        textAlign: TextAlign.center,
        style: TextStyle(fontSize: 20),
      ),
    );
  }
}
