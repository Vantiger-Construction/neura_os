import 'package:flutter/material.dart';

class ReflectionBayRoom extends StatelessWidget {
  const ReflectionBayRoom({super.key});

  @override
  Widget build(BuildContext context) {
    // TODO: Hook up Companion Journal, Mirror Mode, AI reflections.
    return const Center(
      child: Text(
        'Reflection Bay\n(Journal, reflection, Mirror Mode)',
        textAlign: TextAlign.center,
        style: TextStyle(fontSize: 20),
      ),
    );
  }
}
