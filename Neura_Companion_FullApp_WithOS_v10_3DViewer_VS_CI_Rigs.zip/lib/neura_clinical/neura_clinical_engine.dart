import 'dart:convert';

import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';

import '../neura_avatar/neura_avatar_mood.dart';
import 'neura_clinical_models.dart';

/// Engine for structured emotional check-ins in the "Clinical" wing.
///
/// This is an app feature only – it does *not* interpret or diagnose.
/// It stores data so the user (and optionally their clinician) can see
/// patterns over time.
class NeuraClinicalEngine extends ChangeNotifier {
  static const _storageKey = 'neura_clinical_checkins_v1';

  final List<NeuraCheckInEntry> _entries = <NeuraCheckInEntry>[];
  bool _loaded = false;

  bool get isLoaded => _loaded;
  List<NeuraCheckInEntry> get entries => List.unmodifiable(_entries);

  Future<void> ensureLoaded() async {
    if (_loaded) return;
    await _loadFromStorage();
  }

  Future<void> _loadFromStorage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final raw = prefs.getString(_storageKey);
      if (raw == null || raw.isEmpty) {
        _entries.clear();
        _loaded = true;
        notifyListeners();
        return;
      }

      final decoded = jsonDecode(raw);
      if (decoded is! List) {
        _entries.clear();
        _loaded = true;
        notifyListeners();
        return;
      }

      _entries
        ..clear()
        ..addAll(
          decoded
              .whereType<Map<String, dynamic>>()
              .map(NeuraCheckInEntry.fromJson),
        );
      _entries.sort((a, b) => b.timestamp.compareTo(a.timestamp));
      _loaded = true;
      notifyListeners();
    } catch (e) {
      debugPrint('[NeuraClinicalEngine] Failed to load: $e');
      _entries.clear();
      _loaded = true;
      notifyListeners();
    }
  }

  Future<void> _saveToStorage() async {
    try {
      final prefs = await SharedPreferences.getInstance();
      final list = _entries.map((e) => e.toJson()).toList();
      await prefs.setString(_storageKey, jsonEncode(list));
    } catch (e) {
      debugPrint('[NeuraClinicalEngine] Failed to save: $e');
    }
  }

  Future<void> addEntry(NeuraCheckInEntry entry) async {
    await ensureLoaded();
    _entries.add(entry);
    _entries.sort((a, b) => b.timestamp.compareTo(a.timestamp));
    notifyListeners();
    await _saveToStorage();
  }

  List<NeuraCheckInEntry> entriesForDay(DateTime day) {
    if (!_loaded) return const [];
    return _entries
        .where((e) => _sameDate(e.timestamp, day))
        .toList()
      ..sort((a, b) => b.timestamp.compareTo(a.timestamp));
  }

  List<NeuraCheckInEntry> recentEntries([int limit = 50]) {
    if (!_loaded) return const [];
    return _entries.take(limit).toList();
  }

  /// Count how many check-ins were flagged as "might need extra support".
  int flaggedSupportCount() {
    if (!_loaded) return 0;
    return _entries.where((e) => e.flaggedForSupport).length;
  }

  /// Returns the latest flagged check-in if any.
  NeuraCheckInEntry? latestFlaggedSupport() {
    if (!_loaded) return null;
    for (final e in _entries) {
      if (e.flaggedForSupport) return e;
    }
    return null;
  }

  /// Very crude mood histogram for quick UI summaries.
  Map<NeuraAvatarMood, int> moodHistogram() {
    final map = <NeuraAvatarMood, int>{};
    for (final e in _entries) {
      map[e.mood] = (map[e.mood] ?? 0) + 1;
    }
    return map;
  }

  bool _sameDate(DateTime a, DateTime b) {
    return a.year == b.year && a.month == b.month && a.day == b.day;
  }
}
