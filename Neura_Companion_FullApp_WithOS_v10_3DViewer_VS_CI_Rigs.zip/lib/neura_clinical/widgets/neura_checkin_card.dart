import 'package:flutter/material.dart';

import '../../neura_avatar/neura_avatar_mood.dart';
import '../neura_clinical_models.dart';

class NeuraCheckInCard extends StatelessWidget {
  const NeuraCheckInCard({
    super.key,
    required this.entry,
    this.onTap,
  });

  final NeuraCheckInEntry entry;
  final VoidCallback? onTap;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final time =
        '${entry.timestamp.hour.toString().padLeft(2, '0')}:'
        '${entry.timestamp.minute.toString().padLeft(2, '0')}';

    final typeLabel =
        entry.type == NeuraCheckInType.quick ? 'Quick' : 'Guided';

    final moodLabel = _moodLabel(entry.mood);

    return Card(
      shape: RoundedRectangleBorder(
        borderRadius: BorderRadius.circular(18),
      ),
      elevation: entry.flaggedForSupport ? 4 : 2,
      child: InkWell(
        borderRadius: BorderRadius.circular(18),
        onTap: onTap,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              _moodIcon(context, entry.mood),
              const SizedBox(width: 10),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      '$moodLabel • $typeLabel',
                      style: theme.textTheme.titleMedium?.copyWith(
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      entry.note?.isNotEmpty == true
                          ? entry.note!
                          : 'No note added.',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: theme.textTheme.bodyMedium?.color
                            ?.withOpacity(0.9),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Intensity: ${entry.intensity.toStringAsFixed(1)} / 10',
                      style: theme.textTheme.labelMedium,
                    ),
                  ],
                ),
              ),
              const SizedBox(width: 8),
              Column(
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  if (entry.flaggedForSupport)
                    Container(
                      padding: const EdgeInsets.symmetric(
                        horizontal: 8,
                        vertical: 4,
                      ),
                      decoration: BoxDecoration(
                        color: Colors.redAccent.withOpacity(0.15),
                        borderRadius: BorderRadius.circular(999),
                        border: Border.all(
                          color: Colors.redAccent.withOpacity(0.8),
                        ),
                      ),
                      child: const Text(
                        'Needs support',
                        style: TextStyle(
                          fontSize: 11,
                          fontWeight: FontWeight.w600,
                          color: Colors.redAccent,
                        ),
                      ),
                    ),
                  const SizedBox(height: 8),
                  Text(
                    time,
                    style: theme.textTheme.labelSmall?.copyWith(
                      color: theme.textTheme.bodySmall?.color
                          ?.withOpacity(0.7),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _moodIcon(BuildContext context, NeuraAvatarMood mood) {
    final theme = Theme.of(context);
    IconData icon;
    Color color;

    switch (mood) {
      case NeuraAvatarMood.happy:
        icon = Icons.sentiment_satisfied_alt_rounded;
        color = Colors.amber;
        break;
      case NeuraAvatarMood.calm:
        icon = Icons.self_improvement_rounded;
        color = Colors.lightBlueAccent;
        break;
      case NeuraAvatarMood.anxious:
        icon = Icons.sentiment_dissatisfied_rounded;
        color = Colors.orangeAccent;
        break;
      case NeuraAvatarMood.sad:
        icon = Icons.sentiment_very_dissatisfied_rounded;
        color = Colors.blueGrey;
        break;
      case NeuraAvatarMood.tired:
        icon = Icons.bedtime_rounded;
        color = Colors.deepPurpleAccent;
        break;
      case NeuraAvatarMood.neutral:
      default:
        icon = Icons.sentiment_neutral_rounded;
        color = theme.colorScheme.primary;
        break;
    }

    return CircleAvatar(
      radius: 22,
      backgroundColor: color.withOpacity(0.18),
      child: Icon(
        icon,
        color: color,
      ),
    );
  }

  String _moodLabel(NeuraAvatarMood mood) {
    switch (mood) {
      case NeuraAvatarMood.happy:
        return 'Lighter';
      case NeuraAvatarMood.calm:
        return 'Calmer';
      case NeuraAvatarMood.anxious:
        return 'Stressed';
      case NeuraAvatarMood.sad:
        return 'Low';
      case NeuraAvatarMood.tired:
        return 'Tired';
      case NeuraAvatarMood.neutral:
      default:
        return 'Mixed';
    }
  }
}
