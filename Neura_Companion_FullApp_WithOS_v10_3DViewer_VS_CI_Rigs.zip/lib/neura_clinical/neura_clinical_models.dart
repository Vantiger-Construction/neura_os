import 'package:flutter/foundation.dart';
import '../neura_avatar/neura_avatar_mood.dart';

/// Type of check-in Neura is doing.
enum NeuraCheckInType {
  quick,
  guided,
}

/// Basic emotional check-in for the "Clinical / Therapist" wing.
///
/// This is *not* a diagnosis. It is simply a structured log of:
///   - How intense today felt
///   - What the main feeling was
///   - Optional short note
///   - Whether the user said they might need extra support
class NeuraCheckInEntry {
  NeuraCheckInEntry({
    required this.id,
    required this.timestamp,
    required this.type,
    required this.mood,
    required this.intensity,
    this.note,
    this.flaggedForSupport = false,
  });

  /// Unique id (usually timestamp based).
  final String id;

  /// When the check-in happened.
  final DateTime timestamp;

  /// Quick vs guided check-in.
  final NeuraCheckInType type;

  /// Primary mood reported.
  final NeuraAvatarMood mood;

  /// Self-reported intensity from 0–10.
  final double intensity;

  /// Optional free-text note.
  final String? note;

  /// If true, user indicated they might want extra support / to talk more.
  final bool flaggedForSupport;

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'timestamp': timestamp.toIso8601String(),
      'type': type.name,
      'mood': mood.name,
      'intensity': intensity,
      'note': note,
      'flaggedForSupport': flaggedForSupport,
    };
  }

  static NeuraCheckInEntry fromJson(Map<String, dynamic> json) {
    return NeuraCheckInEntry(
      id: json['id'] as String,
      timestamp: DateTime.parse(json['timestamp'] as String),
      type: NeuraCheckInType.values.firstWhere(
        (t) => t.name == (json['type'] as String? ?? 'quick'),
        orElse: () => NeuraCheckInType.quick,
      ),
      mood: NeuraAvatarMood.values.firstWhere(
        (m) => m.name == (json['mood'] as String? ?? 'neutral'),
        orElse: () => NeuraAvatarMood.neutral,
      ),
      intensity: (json['intensity'] as num?)?.toDouble() ?? 0.0,
      note: json['note'] as String?,
      flaggedForSupport: json['flaggedForSupport'] as bool? ?? false,
    );
  }
}
