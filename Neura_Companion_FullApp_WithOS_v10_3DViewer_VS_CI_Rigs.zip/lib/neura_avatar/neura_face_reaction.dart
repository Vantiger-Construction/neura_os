import 'package:flutter/material.dart';
import 'neura_avatar_mood.dart';

/// Small helper widget that shows a tiny emoji / label reaction
/// based on Neura's avatar mood. Used in flows and status banners.
class NeuraFaceReaction extends StatelessWidget {
  final NeuraAvatarMood mood;

  const NeuraFaceReaction({super.key, required this.mood});

  @override
  Widget build(BuildContext context) {
    final textStyle = Theme.of(context).textTheme.bodySmall;
    final emoji = switch (mood) {
      NeuraAvatarMood.happy => '✨',
      NeuraAvatarMood.calm => '🌙',
      NeuraAvatarMood.tired => '😴',
      NeuraAvatarMood.anxious => '⚡',
      NeuraAvatarMood.sad => '💧',
      NeuraAvatarMood.values => '💖',
      NeuraAvatarMood.neutral => '🙂',
    };
    return Text(emoji, style: textStyle?.copyWith(fontSize: 16));
  }
}
