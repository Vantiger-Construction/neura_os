import 'package:flutter/material.dart';
import '../empathy_core/avatar/lottie_avatar_controller.dart'
    as lottie_avatar;
import '../empathy_core/avatar/rive_viseme_controller.dart';
import 'neura_avatar_mood.dart';

/// Thin wrapper that lets the rest of the app treat the avatar as a
/// single component, regardless of whether we are rendering via
/// Lottie or Rive.
class NeuraAvatarController extends ChangeNotifier {
  NeuraAvatarMood _mood = NeuraAvatarMood.calm;

  NeuraAvatarMood get mood => _mood;

  set mood(NeuraAvatarMood value) {
    if (value == _mood) return;
    _mood = value;
    notifyListeners();
  }

  /// Convenience widget for places that just want to draw the face.
  ///
  /// For now we default to the Lottie avatar; you can swap this to
  /// a Rive‑based widget later.
  Widget buildFace() {
    return const lottie_avatar.NeuraLottieAvatarController(
      lottieAsset: 'assets/neura/lottie/NeuraFace_Lottie.json',
    );
  }
}
