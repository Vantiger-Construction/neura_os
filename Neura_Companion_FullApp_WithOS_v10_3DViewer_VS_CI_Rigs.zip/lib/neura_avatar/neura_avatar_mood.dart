/// High‑level mood labels that drive Neura's face, aura and copy.
enum NeuraAvatarMood {
  happy,
  calm,
  tired,
  anxious,
  sad,
  neutral,
  values,
}
