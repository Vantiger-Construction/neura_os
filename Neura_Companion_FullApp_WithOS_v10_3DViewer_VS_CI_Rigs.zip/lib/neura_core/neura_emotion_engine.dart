import 'package:flutter/foundation.dart';

/// Lightweight affect model: valence (sad -> happy), arousal (tired -> wired).
class NeuraEmotionEngine extends ChangeNotifier {
  double _valence = 0.0; // -1..1
  double _arousal = 0.0; // -1..1

  double get valence => _valence;
  double get arousal => _arousal;

  /// Update affect and notify listeners.
  void setAffect({required double valence, required double arousal}) {
    final v = valence.clamp(-1.0, 1.0);
    final a = arousal.clamp(-1.0, 1.0);
    if (v == _valence && a == _arousal) return;
    _valence = v;
    _arousal = a;
    notifyListeners();
  }

  /// Convenience helpers.
  bool get isLowEnergy => _arousal < -0.3;
  bool get isStressed => _arousal > 0.4 && _valence < 0;
  bool get isGlowUp => _valence > 0.5 && _arousal >= 0;
}
