// Neura Adaptive Persona Engine
// Fully included as requested.

import 'dart:math';
import 'package:flutter/foundation.dart';
import 'neura_emotion_engine.dart';
import 'neura_voice.dart';

class NeuraPersonaEngine extends ChangeNotifier {
  final NeuraEmotionEngine emotion;
  final NeuraVoice voice;

  double trust = 0.5;
  double attunement = 0.5;
  double motivation = 0.5;
  double warmth = 0.5;

  final List<String> _microEvents = [];

  NeuraPersonaEngine({
    required this.emotion,
    required this.voice,
  });

  void _record(String event) {
    _microEvents.add("${DateTime.now()}: $event");
    if (_microEvents.length > 200) _microEvents.removeAt(0);
  }

  Future<void> acknowledgeUserAction({
    required String type,
    required Map<String, dynamic> payload,
  }) async {
    _record("action:$type");

    switch (type) {
      case "need":
        await _onNeed(payload["need"]);
        break;
      case "values":
        await _onValuesChanged(payload["values"]);
        break;
      case "mood":
        await _onMood(payload["valence"], payload["energy"]);
        break;
      case "strategy_feedback":
        await _onStrategyFeedback(payload["strategy_id"], payload["helped"]);
        break;
    }

    notifyListeners();
  }

  Future<void> _onNeed(String need) async {
    warmth += 0.03;
    attunement += 0.04;

    emotion.setAffect(
      valence: emotion.valence + 0.1,
      arousal: emotion.arousal - 0.1,
      label: "supportive",
    );

    await voice.plan("It makes sense you'd need some $need today.");
  }

  Future<void> _onValuesChanged(List<String> values) async {
    motivation += 0.04;

    emotion.setAffect(
      valence: emotion.valence + 0.15,
      arousal: emotion.arousal + 0.1,
      label: "meaningful",
    );

    await voice.plan("Your values guide your growth. Updating them was a strong step.");
  }

  Future<void> _onMood(double valence, double energy) async {
    trust += 0.02;

    final tone = valence < -0.2 ? NeuraTone.soft : NeuraTone.neutral;

    emotion.setAffect(
      valence: valence,
      arousal: energy * 2 - 1,
      label: valence < -0.2 ? "concerned" : "steady",
    );

    if (valence < -0.2) {
      await voice.plan("I’m here with you. You don’t have to face this alone.", tone: NeuraTone.soft);
    } else if (valence > 0.4) {
      await voice.plan("I love seeing you thrive. Keep riding that momentum!", tone: NeuraTone.playful);
    }
  }

  Future<void> _onStrategyFeedback(String id, bool helped) async {
    attunement += helped ? 0.05 : -0.02;

    if (helped) {
      await voice.plan("I’m glad that helped. I’ll remember that.");
    } else {
      await voice.plan("Got it. I’ll try a different approach next time.");
    }
  }

  NeuraTone get recommendedTone {
    if (emotion.valence < -0.3) return NeuraTone.soft;
    if (warmth > 0.7) return NeuraTone.playful;
    if (motivation > 0.7) return NeuraTone.serious;
    return NeuraTone.neutral;
  }

  Map<String, double> exportState() => {
        "trust": trust,
        "warmth": warmth,
        "motivation": motivation,
        "attunement": attunement,
      };
}
