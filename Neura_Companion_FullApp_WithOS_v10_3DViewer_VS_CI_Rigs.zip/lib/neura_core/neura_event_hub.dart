import 'dart:developer' as dev;

/// Central event bus for high‑level app events.
///
/// The current implementation just logs events; you can later wire
/// this into analytics, files, or a backend.
class NeuraEventHub {
  void _log(String msg, [Map<String, Object?> extra = const {}]) {
    dev.log('[NeuraEvent] ' + msg, name: 'NeuraEvent', error: extra);
  }

  void onAppOpened({required bool firstOpenToday}) {
    _log('app_opened', {'firstOpenToday': firstOpenToday});
  }

  Future<void> onMoodCheckin(double valence, double energy) async {
    _log('mood_checkin', {'valence': valence, 'energy': energy});
  }

  Future<void> onRitualCompleted({
    required String ritualId,
    required String category,
  }) async {
    _log('ritual_completed', {
      'ritualId': ritualId,
      'category': category,
    });
  }

  Future<void> onJournalSaved({
    required double valence,
    required bool isDeepEntry,
  }) async {
    _log('journal_saved', {
      'valence': valence,
      'deep': isDeepEntry,
    });
  }
}
