import 'package:flutter/foundation.dart';

/// High‑level tone presets Neura can speak in.
enum NeuraTone { neutral, soft, playful, serious }

/// Simple callback interface for routing voice plans to the real TTS engine.
typedef NeuraVoicePlanHandler = Future<void> Function(
  String text, {
  NeuraTone? tone,
});

class NeuraVoice extends ChangeNotifier {
  final NeuraVoicePlanHandler _onPlan;
  bool _inProgress = false;

  NeuraVoice({required NeuraVoicePlanHandler onPlan}) : _onPlan = onPlan;

  bool get inProgress => _inProgress;

  Future<void> plan(String text, {NeuraTone? overrideTone}) async {
    if (text.trim().isEmpty) return;
    _inProgress = true;
    notifyListeners();
    try {
      await _onPlan(text, tone: overrideTone ?? NeuraTone.neutral);
    } finally {
      _inProgress = false;
      notifyListeners();
    }
  }
}
