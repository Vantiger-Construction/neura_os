import 'package:flutter/material.dart';

import '../services/neura_rig_catalog.dart';

class Neura3DViewerScreen extends StatelessWidget {
  const Neura3DViewerScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final rigs = NeuraRigCatalog.rigs;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Neura 3D Lab'),
      ),
      body: ListView.separated(
        padding: const EdgeInsets.all(16),
        itemCount: rigs.length,
        separatorBuilder: (_, __) => const SizedBox(height: 12),
        itemBuilder: (context, index) {
          final rig = rigs[index];
          return Card(
            elevation: 2,
            child: ListTile(
              leading: const Icon(Icons.view_in_ar_rounded),
              title: Text(rig.label),
              subtitle: Text(
                rig.description,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
              ),
              trailing: const Icon(Icons.chevron_right_rounded),
              onTap: () {
                _showRigDetails(context, rig.assetFolder);
              },
            ),
          );
        },
      ),
    );
  }

  void _showRigDetails(BuildContext context, String assetFolder) {
    showDialog<void>(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: const Text('Rig asset folder'),
          content: Text(
            'Neura\'s rig files for this version live in:\n\n'
            '$assetFolder\n\n'
            'You can hook this screen up to a Unity / SceneKit / Three.js view, or a Flutter 3D plugin, '
            'and feed it the files from this folder at runtime.',
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(context).pop(),
              child: const Text('Close'),
            ),
          ],
        );
      },
    );
  }
}
