class NeuraRigAsset {
  final String id;
  final String label;
  final String description;
  final String assetFolder;

  const NeuraRigAsset({
    required this.id,
    required this.label,
    required this.description,
    required this.assetFolder,
  });
}
