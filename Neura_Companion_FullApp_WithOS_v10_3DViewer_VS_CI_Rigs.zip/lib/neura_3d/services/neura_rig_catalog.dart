import '../models/neura_rig_asset.dart';

/// Catalog of Neura rig assets that ship with the app.
///
/// This is intentionally simple and file‑path based so you can:
///  - Plug these folders into Unity / Blender / a custom 3D engine
///  - Or later swap this out for a proper asset manifest coming from backend.
class NeuraRigCatalog {
  static const List<NeuraRigAsset> rigs = [
    NeuraRigAsset(
      id: 'rig_v1_10',
      label: 'Neura Rig v1.10',
      description: 'Latest humanoid rig with refined proportions and facial hooks.',
      assetFolder: 'assets/neura/rig/neura_rig_v1_10',
    ),
    NeuraRigAsset(
      id: 'rig_v1_8',
      label: 'Neura Rig v1.8',
      description: 'Stable production rig; good for in‑app idle animations.',
      assetFolder: 'assets/neura/rig/neura_rig_v1_8',
    ),
    NeuraRigAsset(
      id: 'rig_v1_7',
      label: 'Neura Rig v1.7',
      description: 'Older experimental rig – useful as a fallback or for testing.',
      assetFolder: 'assets/neura/rig/neura_rig_v1_7',
    ),
    NeuraRigAsset(
      id: 'rig_v1_6',
      label: 'Neura Rig v1.6',
      description: 'Early body rig, handy for rough prototyping.',
      assetFolder: 'assets/neura/rig/neura_rig_v1_6',
    ),
    NeuraRigAsset(
      id: 'rig_v1_5',
      label: 'Neura Rig v1.5',
      description: 'Legacy rig kept for full history and compatibility.',
      assetFolder: 'assets/neura/rig/neura_rig_v1_5',
    ),
    NeuraRigAsset(
      id: 'rig_step3_4',
      label: 'Neura Rig Step 3–4',
      description: 'Intermediate work‑in‑progress rig steps captured mid‑pipeline.',
      assetFolder: 'assets/neura/rig/neura_rig_step3_4',
    ),
  ];
}
