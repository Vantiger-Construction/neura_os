import '../../../neura_module01/emotion_debug_screen.dart';
import 'package:flutter/material.dart';

class SettingsScreen extends StatelessWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        children: [
          const ListTile(
            title: Text('App Settings, Avatars, Privacy'),
            subtitle: Text('General configuration & account controls'),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.tune),
            title: const Text('Neura Config (Phase 2.1)'),
            subtitle: const Text('Hue, BLE and viseme demo settings'),
            onTap: () => Navigator.pushNamed(context, '/config'),
          ),
          const Divider(),
          ListTile(
            leading: const Icon(Icons.bug_report),
            title: const Text('Emotion Engine Debug (Module01)'),
            subtitle: const Text('Developer tools – legacy emotion graph'),
            onTap: () {
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (_) => const EmotionDebugHost(),
                ),
              );
            },
          ),
        ],
      ),
    );
  }
}