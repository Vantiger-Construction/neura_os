import 'package:flutter/material.dart';

import '../../../insights/widgets/weekly_snapshot_dashboard_card.dart';
import '../../../insights/screens/weekly_snapshot_screen.dart';

/// Main home dashboard for Neura OS + Companion.
///
/// This is where the user lands after login. It should feel like a
/// "mission control" panel with Neura's weekly insights front and center.
class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  void _openWeeklySnapshot(BuildContext context) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => const WeeklySnapshotScreen()),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Neura Home'),
        centerTitle: true,
      ),
      body: Container(
        decoration: BoxDecoration(
          gradient: LinearGradient(
            colors: [
              theme.colorScheme.surface,
              theme.colorScheme.surfaceVariant.withOpacity(0.8),
            ],
            begin: Alignment.topCenter,
            end: Alignment.bottomCenter,
          ),
        ),
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            Text(
              'This week with Neura',
              style: theme.textTheme.headlineSmall?.copyWith(
                fontWeight: FontWeight.bold,
              ),
            ),
            const SizedBox(height: 8),
            Text(
              'Mood, storms, rituals, and care moments — all in one glance.',
              style: theme.textTheme.bodyMedium,
            ),
            const SizedBox(height: 16),

            // Weekly Life Snapshot card (pulls data from WeeklySnapshotService).
            WeeklySnapshotDashboardCard(
              onTapOpen: () => _openWeeklySnapshot(context),
            ),

            const SizedBox(height: 24),

            // Placeholder area for other dashboard tiles (Neura avatar,
            // mood summary, goals, etc.) so you can expand later.
            Text(
              'Today',
              style: theme.textTheme.titleMedium?.copyWith(
                fontWeight: FontWeight.w600,
              ),
            ),
            const SizedBox(height: 8),
            Card(
              elevation: 1.5,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Text(
                  'Neura will surface your current mood, key rituals, and any active Care Mode plans here.',
                  style: theme.textTheme.bodyMedium,
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
