import 'package:provider/provider.dart';
import '../features/config/neura_config_model.dart';
import '../features/config/neura_config_screen.dart';
import '../features/diagnostics/diagnostics_hooks.dart';
import '../features/voice/viseme_timing_controller.dart';
import 'package:flutter/material.dart';
import 'modules/navigation/enhanced_navigation.dart';
import 'modules/core/ai_engine.dart';
import '../mood/services/mood_state_service.dart';
import '../mood/services/mood_visual_service.dart';

class NeuroCompanionApp extends StatelessWidget {
  const NeuroCompanionApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MultiProvider(
      providers: [
        ChangeNotifierProvider(create: (_) => NeuraConfigModel()..load()),
        Provider(create: (_) => VisemeTimingController()),
        ProxyProvider<VisemeTimingController, DiagnosticsHooks>(
          update: (_, timing, __) => DiagnosticsHooks(timing),
        ),
      ],
      child: Builder(
        builder: (context) {
          // Global mood → theme bridge: current mood subtly recolors the OS.
          final moodState = MoodStateService.instance.current;
          final visual = MoodVisualService.instance.styleFor(moodState);

          final baseTheme = ThemeData.dark();
          final themed = baseTheme.copyWith(
            scaffoldBackgroundColor: visual.backgroundBottom,
            colorScheme: baseTheme.colorScheme.copyWith(
              primary: visual.accent,
              secondary: visual.accent,
            ),
            appBarTheme: baseTheme.appBarTheme.copyWith(
              backgroundColor: visual.backgroundTop,
            ),
            floatingActionButtonTheme:
                baseTheme.floatingActionButtonTheme.copyWith(
              backgroundColor: visual.accent,
            ),
            elevatedButtonTheme: ElevatedButtonThemeData(
              style: ElevatedButton.styleFrom(
                backgroundColor: visual.accent,
              ),
            ),
          );

          return MaterialApp(
            title: 'Neuro Companion',
            theme: themed,
            home: const EnhancedNavigation(),
            routes: {
              '/config': (_) => const NeuraConfigScreen(),
            },
          );
        },
      ),
    );
  }
}
