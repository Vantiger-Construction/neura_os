import 'package:flutter/material.dart';

import '../../neura_legacy_engine.dart';
import '../../neura_legacy_models.dart';

class LegacyHallScreen extends StatefulWidget {
  const LegacyHallScreen({super.key});

  @override
  State<LegacyHallScreen> createState() => _LegacyHallScreenState();
}

class _LegacyHallScreenState extends State<LegacyHallScreen> {
  final NeuraLegacyEngine _engine = NeuraLegacyEngine();

  @override
  void initState() {
    super.initState();
    _engine.addListener(_onChanged);
    _engine.ensureLoaded();
  }

  void _onChanged() {
    if (mounted) {
      setState(() {});
    }
  }

  @override
  void dispose() {
    _engine.removeListener(_onChanged);
    super.dispose();
  }

  Future<void> _addOrEditEntry({NeuraLegacyEntry? existing}) async {
    final titleCtrl = TextEditingController(text: existing?.title ?? '');
    final bodyCtrl = TextEditingController(text: existing?.body ?? '');
    NeuraLegacyCategory category =
        existing?.category ?? NeuraLegacyCategory.memory;

    await showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) {
        return Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(ctx).viewInsets.bottom + 16,
            left: 16,
            right: 16,
            top: 16,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                existing == null ? 'New Legacy Entry' : 'Edit Legacy Entry',
                style: Theme.of(ctx).textTheme.titleMedium,
              ),
              const SizedBox(height: 12),
              TextField(
                controller: titleCtrl,
                decoration: const InputDecoration(
                  labelText: 'Title',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              DropdownButtonFormField<NeuraLegacyCategory>(
                value: category,
                decoration: const InputDecoration(
                  labelText: 'Category',
                  border: OutlineInputBorder(),
                ),
                items: NeuraLegacyCategory.values
                    .map(
                      (c) => DropdownMenuItem(
                        value: c,
                        child: Text(c.name),
                      ),
                    )
                    .toList(),
                onChanged: (value) {
                  if (value != null) {
                    category = value;
                  }
                },
              ),
              const SizedBox(height: 12),
              TextField(
                controller: bodyCtrl,
                maxLines: 6,
                decoration: const InputDecoration(
                  labelText: 'Story / Message / Lesson',
                  border: OutlineInputBorder(),
                ),
              ),
              const SizedBox(height: 12),
              SizedBox(
                width: double.infinity,
                child: ElevatedButton(
                  onPressed: () async {
                    final now = DateTime.now();
                    final entry = existing?.copyWith(
                          updatedAt: now,
                          category: category,
                          title: titleCtrl.text.trim().isEmpty
                              ? 'Untitled'
                              : titleCtrl.text.trim(),
                          body: bodyCtrl.text.trim(),
                        ) ??
                        NeuraLegacyEntry(
                          id: now.microsecondsSinceEpoch.toString(),
                          createdAt: now,
                          updatedAt: now,
                          category: category,
                          title: titleCtrl.text.trim().isEmpty
                              ? 'Untitled'
                              : titleCtrl.text.trim(),
                          body: bodyCtrl.text.trim(),
                          tags: const [],
                        );
                    await _engine.upsertEntry(entry);
                    if (context.mounted) {
                      Navigator.of(ctx).pop();
                    }
                  },
                  child: Text(existing == null ? 'Save Entry' : 'Save Changes'),
                ),
              ),
            ],
          ),
        );
      },
    );
  }

  Future<void> _confirmDelete(NeuraLegacyEntry entry) async {
    final confirmed = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete entry?'),
        content: const Text(
            'This will remove the entry from this device. It\'s not recoverable from Neura.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Cancel'),
          ),
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );

    if (confirmed == true) {
      await _engine.deleteEntry(entry.id);
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final entries = _engine.entries;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Legacy Hall'),
      ),
      body: entries.isEmpty
          ? const Center(
              child: Padding(
                padding: EdgeInsets.all(24.0),
                child: Text(
                  'This is your Legacy Hall.

'
                  'Here you can store stories, lessons, values, and messages '
                  'you want remembered. These stay on *this device* only.',
                  textAlign: TextAlign.center,
                ),
              ),
            )
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: entries.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (_, index) {
                final entry = entries[index];
                return Card(
                  child: ListTile(
                    title: Text(entry.title),
                    subtitle: Text(
                      entry.body,
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                    ),
                    leading: CircleAvatar(
                      child: Text(entry.category.name.substring(0, 1).toUpperCase()),
                    ),
                    onTap: () => _addOrEditEntry(existing: entry),
                    trailing: IconButton(
                      icon: const Icon(Icons.delete_outline),
                      onPressed: () => _confirmDelete(entry),
                    ),
                  ),
                );
              },
            ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => _addOrEditEntry(),
        child: const Icon(Icons.add),
      ),
    );
  }
}
