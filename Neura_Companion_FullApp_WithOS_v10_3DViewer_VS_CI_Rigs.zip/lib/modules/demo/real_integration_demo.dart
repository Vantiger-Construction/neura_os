import 'package:flutter/material.dart';
import 'package:in_app_purchase/in_app_purchase.dart';
import '../../services/billing/billing_service.dart';
import '../../services/notifications/notifications_service.dart';

class RealIntegrationDemo extends StatefulWidget {
  const RealIntegrationDemo({super.key});
  @override
  State<RealIntegrationDemo> createState() => _RealIntegrationDemoState();
}

class _RealIntegrationDemoState extends State<RealIntegrationDemo> {
  final billing = BillingService();
  final notifications = NotificationsService();
  ProductDetails? _product;
  String? _token;

  @override
  void initState() {
    super.initState();
    billing.init((p) {
      if (p.status == PurchaseStatus.purchased) {
        ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content: Text('Purchase complete!')));
      }
    });
    notifications.init().then((t) => setState(() => _token = t));
  }

  Future<void> _loadProduct() async {
    final res = await billing.queryProducts({'neura.pro'});
    if (res.productDetails.isNotEmpty) setState(() => _product = res.productDetails.first);
  }

  @override
  void dispose() {
    billing.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Real Integrations Demo')),
      body: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text('FCM Token: ${_token ?? '(requesting...)'}', maxLines: 2, overflow: TextOverflow.ellipsis),
            const SizedBox(height: 12),
            ElevatedButton(onPressed: _loadProduct, child: const Text('Load Product (neura.pro)')),
            const SizedBox(height: 8),
            if (_product != null) ElevatedButton(
              onPressed: () => billing.buy(_product!),
              child: Text('Buy ${_product!.title}'),
            ),
          ],
        ),
      ),
    );
  }
}
