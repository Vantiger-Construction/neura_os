import 'package:flutter/material.dart';

import '../mood/mood_checkin.dart';
import '../../widgets/neura_mascot_widget.dart';
import '../journal/journal.dart';
import '../goals/goal_tracker.dart';
import '../meditation/meditation.dart';
import '../settings/settings.dart';
import '../mirror/mirror_screen.dart';
import '../synaptic/synaptic_screen.dart';
import '../clinical/clinical_dashboard.dart';
import '../legacy/legacy_hall_screen.dart';
import '../../persona/screens/audience_settings_screen.dart';
import '../../neura_shell/screens/neura_shell_root_screen.dart';
import '../../care/screens/care_mode_home_screen.dart';
import '../../insights/screens/weekly_snapshot_screen.dart';
import '../../dreams/screens/dream_show2_screen.dart';

class DashboardScreen extends StatelessWidget {
  const DashboardScreen({super.key});

  void _open(BuildContext context, Widget screen) {
    Navigator.of(context).push(
      MaterialPageRoute(builder: (_) => screen),
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    final cards = <_DashCard>[
      _DashCard(
        title: 'Daily Check-In',
        subtitle: 'Log how you feel',
        icon: Icons.mood,
        tapBuilder: (ctx) => const MoodCheckinScreen(),
      ),
      _DashCard(
        title: 'Journal',
        subtitle: 'Write it out',
        icon: Icons.book_outlined,
        tapBuilder: (ctx) => const JournalScreen(),
      ),
      _DashCard(
        title: 'Goals',
        subtitle: 'Track your progress',
        icon: Icons.flag_outlined,
        tapBuilder: (ctx) => const GoalTrackerScreen(),
      ),
      _DashCard(
        title: 'Meditation',
        subtitle: 'Take a breathing break',
        icon: Icons.self_improvement,
        tapBuilder: (ctx) => const MeditationScreen(),
      ),
      _DashCard(
        title: 'Mirror Mode',
        subtitle: 'Narrated emotional reflection',
        icon: Icons.mirror,
        tapBuilder: (ctx) => const MirrorScreen(),
      ),
      _DashCard(
        title: 'Synaptic Growth',
        subtitle: 'Habits vs. mood insights',
        icon: Icons.bolt,
        tapBuilder: (ctx) => const SynapticGrowthScreen(),
      ),
      _DashCard(
        title: 'Legacy Hall',
        subtitle: 'Stories & messages that matter',
        icon: Icons.auto_stories,
        tapBuilder: (ctx) => const LegacyHallScreen(),
      ),
      _DashCard(
        title: 'Audience & Safety',
        subtitle: 'Child / Teen / Adult settings',
        icon: Icons.shield_outlined,
        tapBuilder: (ctx) => const AudienceSettingsScreen(),
      ),
      _DashCard(
        title: 'Clinical Mode',
        subtitle: 'Vitals, meds & safety checklist',
        icon: Icons.local_hospital,
        tapBuilder: (ctx) => ClinicalDashboardPage(),
      ),
      _DashCard(
        title: 'Settings',
        subtitle: 'Theme, account & more',
        icon: Icons.settings,
        tapBuilder: (ctx) => const SettingsScreen(),
      ),
      _DashCard(
        title: 'Neura OS World',
        subtitle: 'Enter Neura\'s penthouse & rooms',
        icon: Icons.hub_outlined,
        tapBuilder: (ctx) => const NeuraShellRootScreen(),
      ),
      _DashCard(
        title: 'Care Map',
        subtitle: 'Trusted contacts & crisis plan',
        icon: Icons.health_and_safety_outlined,
        tapBuilder: (ctx) => const CareModeHomeScreen(),
      ),
      _DashCard(
        title: 'Weekly Snapshot',
        subtitle: 'Therapist-style life summary',
        icon: Icons.timeline_outlined,
        tapBuilder: (ctx) => const WeeklySnapshotScreen(),
      ),
      _DashCard(
        title: 'Dream Show 2.0',
        subtitle: 'Replay recurring dream themes',
        icon: Icons.movie_filter_outlined,
        tapBuilder: (ctx) => const DreamShow2Screen(),
      ),
    ];

    return Scaffold(
      appBar: AppBar(
        title: const Text('Neura Companion'),
        actions: const [
          Padding(
            padding: EdgeInsets.only(right: 12.0),
            child: NeuraMascotWidget(size: 56),
          ),
        ],
      ),
      body: GridView.builder(
        padding: const EdgeInsets.all(16),
        gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
          crossAxisCount: 2,
          mainAxisSpacing: 12,
          crossAxisSpacing: 12,
          childAspectRatio: 1.2,
        ),
        itemCount: cards.length,
        itemBuilder: (ctx, index) {
          final card = cards[index];
          return _DashboardTile(
            card: card,
            theme: theme,
            onTap: () => _open(ctx, card.tapBuilder(ctx)),
          );
        },
      ),
    );
  }
}

class _DashCard {
  final String title;
  final String subtitle;
  final IconData icon;
  final Widget Function(BuildContext) tapBuilder;

  _DashCard({
    required this.title,
    required this.subtitle,
    required this.icon,
    required this.tapBuilder,
  });
}

class _DashboardTile extends StatelessWidget {
  final _DashCard card;
  final ThemeData theme;
  final VoidCallback onTap;

  const _DashboardTile({
    super.key,
    required this.card,
    required this.theme,
    required this.onTap,
  });

  @override
  Widget build(BuildContext context) {
    return InkWell(
      onTap: onTap,
      borderRadius: BorderRadius.circular(16),
      child: Ink(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(16),
          color: theme.colorScheme.surfaceVariant.withOpacity(0.5),
        ),
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Icon(card.icon, size: 32),
              const SizedBox(height: 12),
              Text(
                card.title,
                style: theme.textTheme.titleMedium,
              ),
              const SizedBox(height: 4),
              Text(
                card.subtitle,
                style: theme.textTheme.bodySmall,
              ),
            ],
          ),
        ),
      ),
    );
  }
}