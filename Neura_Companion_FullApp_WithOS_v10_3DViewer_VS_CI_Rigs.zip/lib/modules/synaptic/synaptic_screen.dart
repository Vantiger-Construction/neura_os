import 'package:flutter/material.dart';

import 'synaptic_mapper.dart';

class SynapticGrowthScreen extends StatefulWidget {
  const SynapticGrowthScreen({super.key});

  @override
  State<SynapticGrowthScreen> createState() => _SynapticGrowthScreenState();
}

class _SynapticGrowthScreenState extends State<SynapticGrowthScreen> {
  final _mapper = SynapticGrowthMapper();
  bool _loading = true;
  List<SynapticGrowthInsight> _insights = const [];

  @override
  void initState() {
    super.initState();
    _load();
  }

  Future<void> _load() async {
    final data = await _mapper.buildInsights();
    setState(() {
      _insights = data;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Synaptic Growth Mode'),
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView.separated(
              padding: const EdgeInsets.all(16),
              itemCount: _insights.length,
              separatorBuilder: (_, __) => const SizedBox(height: 12),
              itemBuilder: (_, index) {
                final insight = _insights[index];
                return Card(
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          insight.habitName,
                          style: theme.textTheme.titleMedium,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          'Mood impact: ${insight.moodImpact}',
                          style: theme.textTheme.bodySmall,
                        ),
                        const SizedBox(height: 8),
                        Text(
                          insight.suggestion,
                          style: theme.textTheme.bodyMedium,
                        ),
                      ],
                    ),
                  ),
                );
              },
            ),
    );
  }
}
