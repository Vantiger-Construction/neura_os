class SynapticGrowthInsight {
  final String habitName;
  final String moodImpact; // e.g. "lifts mood", "drains energy"
  final String suggestion;

  SynapticGrowthInsight({
    required this.habitName,
    required this.moodImpact,
    required this.suggestion,
  });
}

class SynapticGrowthMapper {
  /// In a real version this would crunch logs.
  /// For now we return a few example insights that can be shown in the UI.
  Future<List<SynapticGrowthInsight>> buildInsights() async {
    return [
      SynapticGrowthInsight(
        habitName: 'Evening scroll for 1+ hour',
        moodImpact: 'drains energy',
        suggestion: 'Try swapping the last 10 minutes of scrolling for something calming like music or stretching.',
      ),
      SynapticGrowthInsight(
        habitName: 'Short morning walk',
        moodImpact: 'lifts mood',
        suggestion: 'This seems powerful for you. Protect it like an appointment with yourself.',
      ),
      SynapticGrowthInsight(
        habitName: 'Skipping meals',
        moodImpact: 'adds irritability',
        suggestion: 'Tiny snacks or prepped food can keep your body from going into emergency mode.',
      ),
    ];
  }
}
