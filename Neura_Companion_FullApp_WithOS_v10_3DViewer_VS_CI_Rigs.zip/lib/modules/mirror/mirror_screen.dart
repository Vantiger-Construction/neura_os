import 'package:flutter/material.dart';

import 'mirror_ai.dart';
import '../../mood/services/mood_state_service.dart';

class MirrorScreen extends StatefulWidget {
  const MirrorScreen({super.key});

  @override
  State<MirrorScreen> createState() => _MirrorScreenState();
}

class _MirrorScreenState extends State<MirrorScreen> {
  final _narration = MirrorNarrationEngine();
  final _moodState = MoodStateService.instance;
  final _notesController = TextEditingController();
  String? _lastSummary;
  bool _loading = false;

  @override
  void dispose() {
    _notesController.dispose();
    super.dispose();
  }

  Future<void> _runMirror() async {
    setState(() {
      _loading = true;
    });

    final mood = _moodState.currentMoodLabel;
    final notes = _notesController.text;

    final summary = await _narration.narrate(
      moodLabel: mood,
      highlight: notes,
    );

    setState(() {
      _lastSummary = summary;
      _loading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('Reflective Mirror Mode'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(
              'Mirror Mode takes a quick emotional snapshot and reflects it back to you in words.',
              style: theme.textTheme.bodyMedium,
            ),
            const SizedBox(height: 16),
            TextField(
              controller: _notesController,
              maxLines: 3,
              decoration: const InputDecoration(
                labelText: 'Anything specific on your mind?',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            SizedBox(
              width: double.infinity,
              child: ElevatedButton(
                onPressed: _loading ? null : _runMirror,
                child: Text(_loading ? 'Thinking…' : 'Generate Reflection'),
              ),
            ),
            const SizedBox(height: 16),
            Expanded(
              child: _lastSummary == null
                  ? const Center(
                      child: Text('Your reflection will appear here.'),
                    )
                  : SingleChildScrollView(
                      child: Container(
                        width: double.infinity,
                        padding: const EdgeInsets.all(16),
                        decoration: BoxDecoration(
                          color: theme.colorScheme.surfaceVariant,
                          borderRadius: BorderRadius.circular(12),
                        ),
                        child: Text(
                          _lastSummary!,
                          style: theme.textTheme.bodyMedium,
                        ),
                      ),
                    ),
            ),
          ],
        ),
      ),
    );
  }
}
