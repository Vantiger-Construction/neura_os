class MirrorNarrationEngine {
  /// Builds a short reflective summary based on a mood label and optional notes.
  Future<String> narrate({
    String moodLabel = 'neutral',
    String? highlight,
  }) async {
    final buffer = StringBuffer();

    buffer.writeln('Neura Mirror Mode:');
    buffer.writeln('');

    switch (moodLabel.toLowerCase()) {
      case 'happy':
        buffer.writeln('You\'ve been carrying a lot of light lately.');
        buffer.writeln('Notice what you\'re doing that keeps you feeling this way – those are clues to your real needs.');
        break;
      case 'anxious':
        buffer.writeln('Your mind has been running ahead of you, scanning for danger.');
        buffer.writeln('That\'s not weakness – it\'s protection. Let\'s look at what truly needs attention, and what can be set down.');
        break;
      case 'sad':
        buffer.writeln('Your world has felt heavier than usual.');
        buffer.writeln('Sadness often means something mattered. We\'ll honor that, not rush past it.');
        break;
      case 'tired':
        buffer.writeln('Your energy has been low, probably for good reasons.');
        buffer.writeln('Rest isn\'t laziness – it\'s maintenance. Today you\'re allowed to be human-sized, not superhuman.');
        break;
      default:
        buffer.writeln('Your emotional pattern has been mixed lately.');
        buffer.writeln('That\'s normal. You\'re allowed to be complicated.');
        break;
    }

    if (highlight != null && highlight.trim().isNotEmpty) {
      buffer.writeln('');
      buffer.writeln('What stands out most:');
      buffer.writeln(highlight.trim());
    }

    buffer.writeln('');
    buffer.writeln('Question for you: what is one kind thing you could do for yourself in the next 24 hours?');

    return buffer.toString();
  }
}
