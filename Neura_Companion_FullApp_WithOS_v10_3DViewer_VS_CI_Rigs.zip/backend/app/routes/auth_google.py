import os, json, google.auth.transport.requests, google.oauth2.id_token
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from app.core.security import issue_token

router = APIRouter()
AUD = os.getenv("GOOGLE_OAUTH_AUDIENCE")

class TokenIn(BaseModel):
    id_token: str

@router.post("/verify")
def verify_google(payload: TokenIn):
    if not AUD:
        raise HTTPException(status_code=500, detail="Server missing GOOGLE_OAUTH_AUDIENCE")
    try:
        info = google.oauth2.id_token.verify_oauth2_token(payload.id_token, google.auth.transport.requests.Request(), AUD)
        sub = info.get("sub")
        email = info.get("email")
        jwt = issue_token(sub, extra={"email": email, "provider": "google"})
        return {"ok": True, "jwt": jwt, "claims": {"sub": sub, "email": email}}
    except Exception as e:
        raise HTTPException(status_code=401, detail=f"Google token invalid: {e}")
