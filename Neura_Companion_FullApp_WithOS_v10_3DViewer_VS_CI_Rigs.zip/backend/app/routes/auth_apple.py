import json, base64, httpx, jwt
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel
from app.core.security import issue_token

router = APIRouter()

APPLE_JWKS_URL = "https://appleid.apple.com/auth/keys"

class AppleTokenIn(BaseModel):
    identity_token: str
    audience: str  # your Services ID or App ID
    issuer: str = "https://appleid.apple.com"

def _b64url(data: str) -> bytes:
    rem = len(data) % 4
    if rem:
        data += "="*(4-rem)
    return base64.urlsafe_b64decode(data)

@router.post("/verify")
def verify_apple(payload: AppleTokenIn):
    # Decode headers to choose the right JWK
    try:
        header_b64 = payload.identity_token.split(".")[0]
        header = json.loads(_b64url(header_b64).decode())
        kid = header.get("kid")
        alg = header.get("alg")
        jwks = httpx.get(APPLE_JWKS_URL, timeout=10).json()
        key = next((k for k in jwks["keys"] if k["kid"] == kid and k["alg"] == alg), None)
        if not key:
            raise HTTPException(status_code=401, detail="Apple key not found")
        public_key = jwt.algorithms.RSAAlgorithm.from_jwk(json.dumps(key))
        claims = jwt.decode(payload.identity_token, public_key, algorithms=[alg], audience=payload.audience, issuer=payload.issuer)
        sub = claims["sub"]
        email = claims.get("email")
        app_jwt = issue_token(sub, extra={"email": email, "provider": "apple"})
        return {"ok": True, "jwt": app_jwt, "claims": {"sub": sub, "email": email}}
    except Exception as e:
        raise HTTPException(status_code=401, detail=f"Apple token invalid: {e}")
