import os, httpx
from fastapi import APIRouter, Response, HTTPException, Query

router = APIRouter()
AZ_KEY = os.getenv("AZURE_SPEECH_KEY")
AZ_REGION = os.getenv("AZURE_SPEECH_REGION")

SSML_TEMPLATE = """<speak version='1.0' xml:lang='en-US'>
  <voice xml:lang='{lang}' xml:gender='{gender}' name='{voice}'>
    {text}
  </voice>
</speak>"""

@router.get("/voices")
def voices():
    if not AZ_KEY or not AZ_REGION:
        raise HTTPException(status_code=500, detail="Azure Speech env not set")
    url = f"https://{AZ_REGION}.tts.speech.microsoft.com/cognitiveservices/voices/list"
    headers = {"Ocp-Apim-Subscription-Key": AZ_KEY}
    r = httpx.get(url, headers=headers, timeout=15)
    r.raise_for_status()
    return r.json()

@router.post("/speak", response_class=Response)
def speak(text: str = Query(...), voice: str = Query("en-US-JennyNeural"), lang: str = Query("en-US"), gender: str = Query("Female")):
    if not AZ_KEY or not AZ_REGION:
        raise HTTPException(status_code=500, detail="Azure Speech env not set")
    ssml = SSML_TEMPLATE.format(lang=lang, gender=gender, voice=voice, text=text)
    token_url = f"https://{AZ_REGION}.api.cognitive.microsoft.com/sts/v1.0/issueToken"
    token = httpx.post(token_url, headers={"Ocp-Apim-Subscription-Key": AZ_KEY}, timeout=10).text
    synth_url = f"https://{AZ_REGION}.tts.speech.microsoft.com/cognitiveservices/v1"
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/ssml+xml",
        "X-Microsoft-OutputFormat": "audio-24khz-48kbitrate-mono-mp3",
        "User-Agent": "NeuraCompanion/1.0",
    }
    r = httpx.post(synth_url, headers=headers, content=ssml.encode("utf-8"), timeout=30)
    if r.status_code != 200:
        raise HTTPException(status_code=502, detail=f"Azure TTS failure: {r.text}")
    return Response(content=r.content, media_type="audio/mpeg")
