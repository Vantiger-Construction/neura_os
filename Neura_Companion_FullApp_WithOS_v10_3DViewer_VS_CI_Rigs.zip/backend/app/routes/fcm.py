import os, httpx
from fastapi import APIRouter, HTTPException
from pydantic import BaseModel

router = APIRouter()
FCM_KEY = os.getenv("FCM_SERVER_KEY")

class PushIn(BaseModel):
    token: str
    title: str
    body: str

@router.post("/send")
def send_push(payload: PushIn):
    if not FCM_KEY:
        raise HTTPException(status_code=500, detail="Missing FCM_SERVER_KEY")
    url = "https://fcm.googleapis.com/fcm/send"
    headers = {"Authorization": f"key={FCM_KEY}", "Content-Type": "application/json"}
    body = {
        "to": payload.token,
        "notification": {"title": payload.title, "body": payload.body},
        "data": {"click_action": "FLUTTER_NOTIFICATION_CLICK"}
    }
    r = httpx.post(url, headers=headers, json=body, timeout=15)
    if r.status_code != 200:
        raise HTTPException(status_code=502, detail=f"FCM error: {r.text}")
    return r.json()
