import os, httpx
from fastapi import APIRouter, UploadFile, File, HTTPException, Form

router = APIRouter()
AZ_KEY = os.getenv("AZURE_SPEECH_KEY")
AZ_REGION = os.getenv("AZURE_SPEECH_REGION")

@router.post("/recognize")
async def recognize(file: UploadFile = File(...), language: str = Form("en-US")):
    if not AZ_KEY or not AZ_REGION:
        raise HTTPException(status_code=500, detail="Azure Speech env not set")
    # Use REST speech-to-text (short audio). Expect WAV/FLAC/OGG.
    url = f"https://{AZ_REGION}.stt.speech.microsoft.com/speech/recognition/conversation/cognitiveservices/v1?language={language}"
    headers = {
        "Ocp-Apim-Subscription-Key": AZ_KEY,
        "Content-Type": file.content_type or "audio/wav"
    }
    data = await file.read()
    r = httpx.post(url, headers=headers, content=data, timeout=60)
    if r.status_code != 200:
        raise HTTPException(status_code=502, detail=f"Azure STT failure: {r.text}")
    return r.json()
