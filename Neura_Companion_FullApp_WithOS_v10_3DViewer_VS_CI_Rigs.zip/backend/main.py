from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from app.routes import auth_google, auth_apple, tts_azure, stt_azure, fcm, health

app = FastAPI(title="Neura Companion – Real Integrations API")
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(health.router, prefix="/health", tags=["health"])
app.include_router(auth_google.router, prefix="/auth/google", tags=["auth"])
app.include_router(auth_apple.router, prefix="/auth/apple", tags=["auth"])
app.include_router(tts_azure.router, prefix="/tts/azure", tags=["tts"])
app.include_router(stt_azure.router, prefix="/stt/azure", tags=["stt"])
app.include_router(fcm.router, prefix="/push", tags=["push"])

@app.get("/")
def root():
    return {"ok": True}
