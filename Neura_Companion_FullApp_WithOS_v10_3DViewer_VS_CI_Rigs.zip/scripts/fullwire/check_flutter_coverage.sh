#!/usr/bin/env bash
set -e
FILE="coverage/lcov.info"
if [ ! -f "$FILE" ]; then echo "No coverage file at $FILE; failing."; exit 2; fi
MIN=${COV_MIN_FLUTTER:-0.60}
if command -v lcov >/dev/null 2>&1; then
  LINE=$(lcov --summary "$FILE" 2>/dev/null | awk -F'[:% ]+' '/lines\.*:/{print $4}')
  if [ -n "$LINE" ]; then TOTAL=$(awk -v v="$LINE" 'BEGIN{printf "%.2f", v/100}'); fi
fi
if [ -z "${TOTAL:-}" ]; then
  COVERED=$(grep -o "DA:[0-9]*,[0-9]*" "$FILE" | awk -F',' '{c+=($2>0)} END{print c+0}')
  LINES=$(grep -c "DA:" "$FILE")
  if [ "$LINES" -gt 0 ]; then TOTAL=$(awk -v c=$COVERED -v l=$LINES 'BEGIN{printf "%.2f", c/l}'); else TOTAL=0; fi
fi
echo "Flutter coverage: $TOTAL (min $MIN)"
awk -v t=$TOTAL -v m=$MIN 'BEGIN{exit (t+0.000001<m)}'
