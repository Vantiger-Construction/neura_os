#!/usr/bin/env bash
set -euo pipefail
GRAFANA_URL="${GRAFANA_URL:-http://localhost:3000}"
GRAFANA_USER="${GRAFANA_USER:-admin}"
GRAFANA_PASS="${GRAFANA_PASS:-admin}"
OUT_DIR="${OUT_DIR:-ops/grafana/dashboards}"
mkdir -p "$OUT_DIR"
for i in {1..60}; do
  if curl -sf "$GRAFANA_URL/api/health" >/dev/null; then break; fi
  sleep 2
done
LIST_JSON=$(curl -sS -u "$GRAFANA_USER:$GRAFANA_PASS" "$GRAFANA_URL/api/search?type=dash-db&query=")
command -v jq >/dev/null 2>&1 || { echo "[err] jq not installed"; exit 2; }
COUNT=$(echo "$LIST_JSON" | jq 'length')
if [ "$COUNT" -eq 0 ]; then exit 0; fi
for uid in $(echo "$LIST_JSON" | jq -r '.[].uid'); do
  DJSON=$(curl -sS -u "$GRAFANA_USER:$GRAFANA_PASS" "$GRAFANA_URL/api/dashboards/uid/$uid")
  TITLE=$(echo "$DJSON" | jq -r '.dashboard.title' | sed 's#[^A-Za-z0-9._-]#_#g')
  CLEAN=$(echo "$DJSON" | jq ' .dashboard | del(.id, .version, .time, .timepicker.nowDelay, .refresh, .iteration)')
  FILE="$OUT_DIR/${TITLE}.json"
  echo "$CLEAN" | jq . > "$FILE"
  echo "[save] $FILE"
done
