@echo off
echo ============================================
echo   Neura Companion - Auto Setup (Debug Run)
echo ============================================
echo.
echo This script will:
echo   1) flutter clean
echo   2) flutter pub get
echo   3) flutter run
echo.
echo Make sure:
echo   - Flutter is installed and on your PATH
echo   - An Android device or emulator is connected
echo.

pause

flutter clean
if %ERRORLEVEL% NEQ 0 (
  echo flutter clean failed. Check your Flutter install.
  pause
  exit /b %ERRORLEVEL%
)

flutter pub get
if %ERRORLEVEL% NEQ 0 (
  echo flutter pub get failed. Check pubspec.yaml / network.
  pause
  exit /b %ERRORLEVEL%
)

flutter run
echo.
echo If the app did not launch, check the log above.
pause
