@echo off
echo ============================================
echo   Neura Companion - Android Release Build
echo ============================================
echo.
echo This will:
echo   1) flutter clean
echo   2) flutter pub get
echo   3) flutter build apk --release
echo.
echo Make sure your keystore / signing config is set up if
echo you plan to upload this to the Play Store.
echo.

pause

flutter clean
if %ERRORLEVEL% NEQ 0 (
  echo flutter clean failed.
  pause
  exit /b %ERRORLEVEL%
)

flutter pub get
if %ERRORLEVEL% NEQ 0 (
  echo flutter pub get failed.
  pause
  exit /b %ERRORLEVEL%
)

flutter build apk --release
if %ERRORLEVEL% NEQ 0 (
  echo flutter build apk --release failed.
  pause
  exit /b %ERRORLEVEL%
)

echo.
echo Build complete. Check:
echo   build\app\outputs\flutter-apk\app-release.apk
pause
