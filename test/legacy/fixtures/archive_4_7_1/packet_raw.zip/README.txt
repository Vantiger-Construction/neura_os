Neura Companion — Legacy Delivery Packet
------------------------------------------------

This packet contains a single Legacy Capsule and its attachments.
If the capsule is encrypted, you will need the passphrase to read it.

Inside: 
- capsule.json
- attachments/ (optional)

Generated: 2026-11-26 07:57:01.168129
