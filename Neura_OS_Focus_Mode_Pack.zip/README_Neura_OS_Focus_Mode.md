
# Neura Companion OS – Focus & Mode Pack

This pack adds an explicit **Focus Mode** layer to Neura OS so she can
adapt behavior based on what the user is trying to do RIGHT NOW.

It includes:

1. `NeuraFocusModeController` (core):
   - Tracks current mode: normal, deep work, reflection, social, wind down.
   - Notifies listeners on change.
   - Optionally hooks into NeuraStatusCenter + NeuraModuleRegistry for
     environment + automation tweaks.
2. `NeuraFocusModeStrip` widget:
   - Horizontal pill selector for modes.
   - One-tap switching.
3. `NeuraFocusBanner` widget:
   - Small banner explaining the current mode + what Neura will do.

You can drop this on top of your existing Neura OS shell and mount the
strip on your dashboard or in the main OS shell under the status bar.
