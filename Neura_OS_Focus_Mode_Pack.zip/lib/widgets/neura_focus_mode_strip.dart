
import 'package:flutter/material.dart';

import '../neura_os_core/neura_focus_modes.dart';

/// Horizontal pill selector for Neura focus modes.
class NeuraFocusModeStrip extends StatelessWidget {
  const NeuraFocusModeStrip({super.key});

  @override
  Widget build(BuildContext context) {
    final ctrl = NeuraFocusModeController.instance;

    return AnimatedBuilder(
      animation: ctrl,
      builder: (context, _) {
        final current = ctrl.mode;
        return SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          child: Row(
            children: NeuraFocusMode.values.map((mode) {
              final selected = mode == current;
              return Padding(
                padding: const EdgeInsets.symmetric(horizontal: 4),
                child: ChoiceChip(
                  label: Text(mode.label),
                  selected: selected,
                  onSelected: (_) {
                    ctrl.setMode(mode);
                  },
                ),
              );
            }).toList(),
          ),
        );
      },
    );
  }
}
