
import 'package:flutter/material.dart';

import '../neura_os_core/neura_focus_modes.dart';

/// Small banner that shows the current focus mode and a one-line
/// description of what Neura is optimizing for.
class NeuraFocusBanner extends StatelessWidget {
  const NeuraFocusBanner({super.key});

  @override
  Widget build(BuildContext context) {
    final ctrl = NeuraFocusModeController.instance;

    return AnimatedBuilder(
      animation: ctrl,
      builder: (context, _) {
        final mode = ctrl.mode;
        final changed = ctrl.lastChanged;
        final subtitle = changed == null
            ? ''
            : 'Since ${_formatTime(changed)}';

        return Card(
          margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
          child: Padding(
            padding: const EdgeInsets.all(12),
            child: Row(
              children: [
                Icon(_iconForMode(mode)),
                const SizedBox(width: 12),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        '${mode.label} Mode',
                        style: Theme.of(context).textTheme.titleSmall,
                      ),
                      const SizedBox(height: 2),
                      Text(
                        mode.description,
                        style: Theme.of(context).textTheme.bodySmall,
                      ),
                      if (subtitle.isNotEmpty) ...[
                        const SizedBox(height: 2),
                        Text(
                          subtitle,
                          style: Theme.of(context)
                              .textTheme
                              .bodySmall
                              ?.copyWith(color: Colors.grey),
                        ),
                      ],
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }

  IconData _iconForMode(NeuraFocusMode mode) {
    switch (mode) {
      case NeuraFocusMode.normal:
        return Icons.balance;
      case NeuraFocusMode.deepWork:
        return Icons.center_focus_strong;
      case NeuraFocusMode.reflection:
        return Icons.self_improvement;
      case NeuraFocusMode.social:
        return Icons.people;
      case NeuraFocusMode.windDown:
        return Icons.nightlight_round;
    }
  }

  String _formatTime(DateTime ts) {
    final h = ts.hour.toString().padLeft(2, '0');
    final m = ts.minute.toString().padLeft(2, '0');
    return '$h:$m';
  }
}
