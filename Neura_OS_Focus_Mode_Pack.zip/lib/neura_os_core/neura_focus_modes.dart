
import 'package:flutter/foundation.dart';

import 'neura_status_center.dart';
import 'neura_module_registry.dart';

/// High-level focus modes for Neura OS.
enum NeuraFocusMode {
  normal,
  deepWork,
  reflection,
  social,
  windDown,
}

extension NeuraFocusModeX on NeuraFocusMode {
  String get id {
    switch (this) {
      case NeuraFocusMode.normal:
        return 'normal';
      case NeuraFocusMode.deepWork:
        return 'deep_work';
      case NeuraFocusMode.reflection:
        return 'reflection';
      case NeuraFocusMode.social:
        return 'social';
      case NeuraFocusMode.windDown:
        return 'wind_down';
    }
  }

  String get label {
    switch (this) {
      case NeuraFocusMode.normal:
        return 'Normal';
      case NeuraFocusMode.deepWork:
        return 'Deep Work';
      case NeuraFocusMode.reflection:
        return 'Reflection';
      case NeuraFocusMode.social:
        return 'Social';
      case NeuraFocusMode.windDown:
        return 'Wind Down';
    }
  }

  String get description {
    switch (this) {
      case NeuraFocusMode.normal:
        return 'Balanced assistance and gentle nudges.';
      case NeuraFocusMode.deepWork:
        return 'Fewer distractions, focus-first suggestions.';
      case NeuraFocusMode.reflection:
        return 'More journaling and introspection prompts.';
      case NeuraFocusMode.social:
        return 'Support for communication, empathy, and connection.';
      case NeuraFocusMode.windDown:
        return 'Calming rituals, softer lighting, and sleep prep.';
    }
  }
}

/// Controller for current focus mode. Integrates with NeuraStatusCenter
/// and NeuraModuleRegistry for environment and suggestion tweaks.
class NeuraFocusModeController extends ChangeNotifier {
  NeuraFocusModeController._();

  static final NeuraFocusModeController instance =
      NeuraFocusModeController._();

  NeuraFocusMode _mode = NeuraFocusMode.normal;
  DateTime? _lastChanged;

  NeuraFocusMode get mode => _mode;
  DateTime? get lastChanged => _lastChanged;

  Future<void> setMode(NeuraFocusMode newMode) async {
    if (newMode == _mode) return;
    _mode = newMode;
    _lastChanged = DateTime.now();

    // Adjust high-level OS status knobs.
    final status = NeuraStatusCenter.instance;
    final modules = NeuraModuleRegistry.instance;

    switch (newMode) {
      case NeuraFocusMode.normal:
        status.setAutomationsEnabled(true);
        status.setEnergy('medium');
        break;
      case NeuraFocusMode.deepWork:
        status.setAutomationsEnabled(true);
        status.setEnergy('high');
        // Example: reduce notifications or switch lights to "focus".
        await modules.smartHomeAction(
          deviceIdOrScene: 'focus_scene',
          payload: {'brightness': 0.7},
        );
        break;
      case NeuraFocusMode.reflection:
        status.setAutomationsEnabled(true);
        status.setEnergy('medium');
        await modules.smartHomeAction(
          deviceIdOrScene: 'reflection_scene',
          payload: {'warmth': 0.8},
        );
        break;
      case NeuraFocusMode.social:
        status.setAutomationsEnabled(true);
        status.setEnergy('high');
        break;
      case NeuraFocusMode.windDown:
        status.setAutomationsEnabled(true);
        status.setEnergy('low');
        await modules.smartHomeAction(
          deviceIdOrScene: 'wind_down_scene',
          payload: {'brightness': 0.3},
        );
        break;
    }

    notifyListeners();
  }
}
