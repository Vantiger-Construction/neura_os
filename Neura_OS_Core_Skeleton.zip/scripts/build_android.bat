@echo off
echo Neura OS Android build (skeleton).
echo 1) Export Unity as Android library (unityLibrary).
echo 2) Integrate unityLibrary into shell/android.
echo 3) Run flutter build apk from core.
echo.
echo This monorepo is a scaffold. Wire your Unity export + Gradle settings.
pause
