Write-Host "Neura OS Windows build (skeleton)."
Write-Host "1) Build Unity world as Windows x64 standalone."
Write-Host "2) Run: cd core; flutter build windows"
Write-Host "3) Place NeuraWorld.exe alongside the Flutter runner."
