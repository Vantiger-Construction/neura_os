import 'dart:async';
import 'package:flutter/material.dart';

import '../neura_bridge/neura_bridge.dart';
import 'neura_event_router.dart';

/// Wrap your MaterialApp (or app shell) with this binder so Unity events can drive navigation.
class NeuraUnityEventBinder extends StatefulWidget {
  final Widget child;
  const NeuraUnityEventBinder({super.key, required this.child});

  @override
  State<NeuraUnityEventBinder> createState() => _NeuraUnityEventBinderState();
}

class _NeuraUnityEventBinderState extends State<NeuraUnityEventBinder> {
  StreamSubscription<Map<String, dynamic>>? _sub;
  late final NeuraEventRouter _router;

  @override
  void initState() {
    super.initState();

    _router = NeuraEventRouter(
      pushNamed: (route, {arguments}) async {
        if (!mounted) return;
        await Navigator.of(context).pushNamed(route, arguments: arguments);
      },
      toast: (msg) {
        if (!mounted) return;
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text(msg), duration: const Duration(milliseconds: 800)),
        );
      },
    );

    _sub = NeuraBridge.instance.events.listen((msg) async {
      await _router.handle(msg);
    });
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => widget.child;
}
