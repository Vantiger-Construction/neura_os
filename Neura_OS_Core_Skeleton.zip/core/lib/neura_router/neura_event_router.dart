import 'dart:async';

/// Routes Unity events into Flutter navigation/actions.
///
/// Unity event examples:
/// { "type":"EVENT", "event":"PROP_CLICKED", "value":"journalDesk" }
/// { "type":"EVENT", "event":"ROOM_ENTERED", "value":"MoodDen" }
class NeuraEventRouter {
  final Future<void> Function(String routeName, {Object? arguments}) pushNamed;
  final void Function(String message)? toast;

  NeuraEventRouter({required this.pushNamed, this.toast});

  Future<void> handle(Map<String, dynamic> msg) async {
    if (msg['type']?.toString() != 'EVENT') return;

    final event = msg['event']?.toString();
    final value = msg['value']?.toString();
    if (event == null) return;

    switch (event) {
      case 'PROP_CLICKED':
        await _handlePropClicked(value);
        break;
      case 'ROOM_ENTERED':
        toast?.call('Entered: ${value ?? "Unknown"}');
        break;
      default:
        break;
    }
  }

  Future<void> _handlePropClicked(String? propId) async {
    if (propId == null || propId.isEmpty) return;

    final route = NeuraPropRouteMap.routeForProp(propId);
    if (route == null) {
      toast?.call('Neura tapped "$propId" (no route yet)');
      return;
    }

    toast?.call('Opening $route');
    await pushNamed(route, arguments: {'source': 'unity', 'propId': propId});
  }
}

/// Map Unity prop IDs to Flutter routes.
/// Keep prop IDs stable in Unity prefabs.
class NeuraPropRouteMap {
  static const Map<String, String> _map = {
    'journalDesk': '/journal',
    'ritualAltar': '/rituals',
    'moodMapWall': '/moodmap',
    'dreamPod': '/dreams',
    'settingsConsole': '/settings',
    'goalTerminal': '/goals',
    'feedbackPanel': '/feedback',
  };

  static String? routeForProp(String propId) => _map[propId];
}
