import 'package:flutter/material.dart';
import 'neura_ui/neura_control_panel.dart';
import 'neura_unity/neura_unity_event_binder.dart';
import 'core/intent/intent_engine.dart';
import 'core/memory/memory_graph_service.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const NeuraOSApp());
}

class NeuraOSApp extends StatefulWidget {
  const NeuraOSApp({super.key});

  @override
  State<NeuraOSApp> createState() => _NeuraOSAppState();
}

class _NeuraOSAppState extends State<NeuraOSApp> {
  late final MemoryGraphService memory;
  late final IntentEngine intent;

  @override
  void initState() {
    super.initState();
    memory = MemoryGraphService();
    intent = IntentEngine(memory);
  }

  @override
  void dispose() {
    intent.dispose();
    memory.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Neura OS',
      theme: ThemeData.dark(useMaterial3: true),
      home: NeuraUnityEventBinder(
        child: Scaffold(
          appBar: AppBar(
            title: const Text('Neura OS (Core Demo)'),
            actions: [
              IconButton(
                icon: const Icon(Icons.tune),
                onPressed: () {
                  Navigator.of(context).push(
                    MaterialPageRoute(
                      builder: (_) => NeuraControlPanel(memory: memory, intent: intent),
                    ),
                  );
                },
              )
            ],
          ),
          body: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                const Text(
                  'This build includes:\n• Unity bridge (Android + Windows TCP)\n• Intent Engine + Intent Weaving\n• Encrypted local-first Memory Graph',
                ),
                const SizedBox(height: 16),
                ElevatedButton(
                  onPressed: () async {
                    await intent.demoCheckIn();
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('Logged a demo check-in into encrypted memory.')),
                      );
                    }
                  },
                  child: const Text('Demo: Log Check-In'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
