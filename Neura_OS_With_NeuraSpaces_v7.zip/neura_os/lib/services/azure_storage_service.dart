import 'dart:async';

import 'package:azblob/azblob.dart';

/// Minimal Azure Blob storage wrapper.
///
/// Why this exists:
/// - The old implementation referenced `azure_storage_blobs`, which is not a Dart/Flutter pub.dev package.
/// - `azblob` is a real, lightweight Azure Blob REST client that works on Flutter & Dart.
///
/// Notes:
/// - Keep this service OPTIONAL. If you don't configure a connection string, it's effectively inert.
/// - If you later want Entra ID / Managed Identity, we can extend this with `azure_identity`.
class AzureStorageService {
  AzureStorageService({String? connectionString}) : _connectionString = connectionString;

  String? _connectionString;

  bool get isConfigured => (_connectionString ?? '').trim().isNotEmpty;

  void configure({required String connectionString}) {
    _connectionString = connectionString;
  }

  AzureStorage _clientOrThrow() {
    final cs = (_connectionString ?? '').trim();
    if (cs.isEmpty) {
      throw StateError('AzureStorageService is not configured. Provide a connection string first.');
    }
    return AzureStorage.parse(cs);
  }

  /// Uploads a blob to `/<container>/<path>`.
  Future<void> putText({
    required String container,
    required String blobPath,
    required String body,
    String contentType = 'text/plain; charset=utf-8',
  }) async {
    final storage = _clientOrThrow();
    final fullPath = '/$container/${blobPath.startsWith('/') ? blobPath.substring(1) : blobPath}';
    await storage.putBlob(fullPath, body: body, contentType: contentType);
  }

  /// Downloads a blob from `/<container>/<path>`.
  Future<String> getText({
    required String container,
    required String blobPath,
  }) async {
    final storage = _clientOrThrow();
    final fullPath = '/$container/${blobPath.startsWith('/') ? blobPath.substring(1) : blobPath}';
    final res = await storage.getBlob(fullPath);
    return await res.stream.bytesToString();
  }
}
