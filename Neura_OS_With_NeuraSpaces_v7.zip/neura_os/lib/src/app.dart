import 'package:flutter/material.dart';

import '../modules/core/error_handler.dart';
import '../modules/navigation/enhanced_navigation.dart';
import '../neura_shell/neura_shell_root.dart';

class NeuroCompanionApp extends StatelessWidget {
  const NeuroCompanionApp({super.key});

  @override
  Widget build(BuildContext context) {
    final base = ThemeData.dark(useMaterial3: true);

    return MaterialApp(
      title: 'Neura OS',
      theme: base.copyWith(
        scaffoldBackgroundColor: Colors.transparent,
        appBarTheme: const AppBarTheme(
          backgroundColor: Colors.transparent,
          elevation: 0,
          surfaceTintColor: Colors.transparent,
        ),
        cardTheme: CardTheme(
          color: Colors.black.withOpacity(0.35),
          elevation: 0,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        ),
      ),
      scaffoldMessengerKey: ErrorHandler.scaffoldMessengerKey,
      home: const EnhancedNavigation(),
      builder: (context, child) {
        return NeuraShellRoot(child: child ?? const SizedBox.shrink());
      },
    );
  }
}
