import 'package:flutter/foundation.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/material.dart' show Offset;

import 'models/neura_room.dart';
import 'services/neura_ambient_audio_service.dart';

class NeuraShellState extends ChangeNotifier {
  static const _kRoomId = 'neura_shell.room_id';
  static const _kShowAvatar = 'neura_shell.show_avatar';
  static const _kAmbientEnabled = 'neura_shell.ambient_enabled';
  static const _kAmbientVolume = 'neura_shell.ambient_volume';
  static const _kAutoRoomSync = 'neura_shell.auto_room_sync';

  // Per-room avatar placement (stored as normalized offsets in screen space).
  static String _kAvatarDx(String roomId) => 'neura_shell.avatar_dx.$roomId';
  static String _kAvatarDy(String roomId) => 'neura_shell.avatar_dy.$roomId';


  NeuraRoom _room = NeuraRoom.penthouse;
  bool _showAvatar = true;
  bool _ambientEnabled = false;
  double _ambientVolume = 0.35;
  bool _autoRoomSync = true;

  // Per-room avatar placement. Offsets are stored in logical pixels and
  // persisted per-room so Neura can "live" where the user left her.
  final Map<String, Offset> _avatarOffsets = <String, Offset>{};

  final NeuraAmbientAudioService _audio = NeuraAmbientAudioService();
  bool _loaded = false;

  bool get isLoaded => _loaded;
  NeuraRoom get room => _room;
  bool get showAvatar => _showAvatar;
  bool get ambientEnabled => _ambientEnabled;
  double get ambientVolume => _ambientVolume;
  bool get autoRoomSync => _autoRoomSync;

  /// User-defined avatar offset for the given room (null => use default anchor).
  Offset? avatarOffsetFor(NeuraRoom room) => _avatarOffsets[room.id];

  Future<void> load() async {
    final prefs = await SharedPreferences.getInstance();
    _room = NeuraRoom.fromId(prefs.getString(_kRoomId));
    _showAvatar = prefs.getBool(_kShowAvatar) ?? true;
    _ambientEnabled = prefs.getBool(_kAmbientEnabled) ?? false;
    _ambientVolume = (prefs.getDouble(_kAmbientVolume) ?? 0.35).clamp(0.0, 1.0);
    _autoRoomSync = prefs.getBool(_kAutoRoomSync) ?? true;

    // Load per-room avatar offsets.
    for (final r in NeuraRoom.all) {
      final dx = prefs.getDouble(_kAvatarDx(r.id));
      final dy = prefs.getDouble(_kAvatarDy(r.id));
      if (dx != null && dy != null) {
        _avatarOffsets[r.id] = Offset(dx, dy);
      }
    }

    await _audio.setVolume(_ambientVolume);
    await _audio.setEnabled(_ambientEnabled);
    final asset = _room.ambientSoundAsset;
    if (_ambientEnabled && asset != null) {
      await _audio.playLoop(asset);
    }

    _loaded = true;
    notifyListeners();
  }

  /// Persist a user-defined avatar offset for the current room.
  ///
  /// Offsets are stored in logical pixels relative to the bottom-right anchored avatar.
  Future<void> setAvatarOffset(NeuraRoom room, Offset? offset) async {
    if (offset == null) {
      _avatarOffsets.remove(room.id);
    } else {
      _avatarOffsets[room.id] = offset;
    }
    notifyListeners();

    final prefs = await SharedPreferences.getInstance();
    if (offset == null) {
      await prefs.remove(_kAvatarDx(room.id));
      await prefs.remove(_kAvatarDy(room.id));
    } else {
      await prefs.setDouble(_kAvatarDx(room.id), offset.dx);
      await prefs.setDouble(_kAvatarDy(room.id), offset.dy);
    }
  }

  Future<void> setRoom(NeuraRoom room) async {
    _room = room;
    notifyListeners();

    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kRoomId, room.id);

    final asset = room.ambientSoundAsset;
    if (_ambientEnabled && asset != null) {
      await _audio.playLoop(asset);
    }
  }

  Future<void> setShowAvatar(bool value) async {
    _showAvatar = value;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kShowAvatar, value);
  }

  Future<void> setAmbientEnabled(bool enabled) async {
    _ambientEnabled = enabled;
    notifyListeners();

    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kAmbientEnabled, enabled);

    await _audio.setEnabled(enabled);
    final asset = _room.ambientSoundAsset;
    if (enabled && asset != null) {
      await _audio.playLoop(asset);
    }
  }

  Future<void> setAmbientVolume(double volume) async {
    _ambientVolume = volume.clamp(0.0, 1.0);
    notifyListeners();

    final prefs = await SharedPreferences.getInstance();
    await prefs.setDouble(_kAmbientVolume, _ambientVolume);

    await _audio.setVolume(_ambientVolume);
  }

  Future<void> setAutoRoomSync(bool value) async {
    _autoRoomSync = value;
    notifyListeners();
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kAutoRoomSync, value);
  }

  @override
  void dispose() {
    _audio.dispose();
    super.dispose();
  }
}
