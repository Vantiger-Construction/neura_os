import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:rive/rive.dart';

import '../../services/neura_voice_pack.dart';
import '../models/neura_room.dart';
import '../neura_shell.dart';

const String kNeuraRiveAsset = 'assets/rive/Neura.riv';
const String kNeuraFallbackPng = 'assets/images/neura_fullbody.png';
const String kNeuraStateMachine = 'NeuraBrain';

/// A full-body, persistent Neura resident that lives in the penthouse overlay.
///
/// - If `assets/rive/Neura.riv` exists and exposes the expected state machine inputs,
///   this drives walk + mouth/visemes from [NeuraVoicePack].
/// - If the .riv file is missing (or fails to load), we fall back to a static image
///   so builds never break.
///
/// Expected Rive setup (recommended):
/// - State machine: `NeuraBrain`
/// - Inputs:
///   - `isWalking` (bool)
///   - `talkLevel` (number)
///   - `rest`, `aa`, `ee`, `oo`, `ff`, `mm` (number)
class NeuraRiveResident extends StatefulWidget {
  const NeuraRiveResident({super.key});

  @override
  State<NeuraRiveResident> createState() => _NeuraRiveResidentState();
}

class _NeuraRiveResidentState extends State<NeuraRiveResident> with TickerProviderStateMixin {
  static const String _smName = kNeuraStateMachine;

  // Position animation between room anchors.
  late final AnimationController _move;
  Offset _from = Offset.zero;
  Offset _to = Offset.zero;
  Offset _dragOffset = Offset.zero;
  NeuraRoom? _lastRoom;

  // Rive driver
  bool _riveOk = true;
  StateMachineController? _sm;
  SMIInput<bool>? _isWalking;
  SMIInput<double>? _talkLevel;
  SMIInput<double>? _rest;
  SMIInput<double>? _aa;
  SMIInput<double>? _ee;
  SMIInput<double>? _oo;
  SMIInput<double>? _ff;
  SMIInput<double>? _mm;

  StreamSubscription? _voiceSub;

  @override
  void initState() {
    super.initState();
    _move = AnimationController(vsync: this, duration: const Duration(milliseconds: 650));
    _move.addStatusListener((s) {
      if (s == AnimationStatus.completed || s == AnimationStatus.dismissed) {
        _setWalking(false);
      }
    });

    // Drive mouth from NeuraVoicePack.
    _voiceSub = NeuraVoicePack.I.stream.listen((f) {
      _talkLevel?.value = f.talkLevel;
      _rest?.value = f.rest;
      _aa?.value = f.aa;
      _ee?.value = f.ee;
      _oo?.value = f.oo;
      _ff?.value = f.ff;
      _mm?.value = f.mm;
    });
  }

  @override
  void dispose() {
    _voiceSub?.cancel();
    _move.dispose();
    super.dispose();
  }

  Offset _anchorFor(NeuraRoom room, Size size) {
    // Anchor points tuned for a full-body character.
    // Values are in logical pixels from the top-left.
    final w = size.width;
    final h = size.height;

    // Keep her in the lower-right quadrant by default.
    switch (room.id) {
      case 'penthouse':
        return Offset(w * 0.72, h * 0.55);
      case 'reflection_bay':
        return Offset(w * 0.18, h * 0.56);
      case 'joy_lounge':
        return Offset(w * 0.62, h * 0.52);
      case 'dream_atrium':
        return Offset(w * 0.50, h * 0.50);
      case 'legacy_vault':
        return Offset(w * 0.78, h * 0.58);
      case 'mood_den':
        return Offset(w * 0.35, h * 0.60);
      default:
        return Offset(w * 0.72, h * 0.55);
    }
  }

  void _setWalking(bool value) {
    if (_isWalking != null) {
      _isWalking!.value = value;
    }
  }

  void _beginRoomMove({required NeuraRoom room, required Size size}) {
    final state = NeuraShell.of(context);
    _from = _lastRoom == null ? _anchorFor(room, size) : _currentPos(size);
    _to = _anchorFor(room, size);

    // Apply per-room user offset if set.
    final user = state.avatarOffsetFor(room);
    _dragOffset = user ?? Offset.zero;

    _lastRoom = room;

    if ((_from - _to).distance < 6) {
      return;
    }
    _setWalking(true);
    _move.forward(from: 0);
  }

  Offset _currentPos(Size size) {
    final p = Curves.easeInOutCubic.transform(_move.value);
    final base = Offset(
      lerpDouble(_from.dx, _to.dx, p),
      lerpDouble(_from.dy, _to.dy, p),
    );
    return base + _dragOffset;
  }

  double lerpDouble(double a, double b, double t) => a + (b - a) * t;

  @override
  Widget build(BuildContext context) {
    final state = NeuraShell.of(context);

    return LayoutBuilder(
      builder: (context, constraints) {
        final size = Size(constraints.maxWidth, constraints.maxHeight);
        if (_lastRoom?.id != state.room.id) {
          _beginRoomMove(room: state.room, size: size);
        }

        return AnimatedBuilder(
          animation: _move,
          builder: (context, _) {
            final pos = _currentPos(size);

            // Gentle idle motion so she feels "present".
            final idle = 1.0 - (_move.isAnimating ? 1.0 : 0.0);
            final t = DateTime.now().millisecondsSinceEpoch / 1000.0;
            final bob = math.sin(t * 1.25) * 3.0 * idle;

            return Positioned(
              left: pos.dx,
              top: pos.dy + bob,
              child: _DraggableResident(
                riveOk: _riveOk,
                onDragDelta: (delta) async {
                  final newOffset = _dragOffset + delta;
                  _dragOffset = newOffset;
                  // Persist per-room.
                  await state.setAvatarOffset(state.room, _dragOffset);
                  setState(() {});
                },
                onSnapHome: () async {
                  _dragOffset = Offset.zero;
                  await state.setAvatarOffset(state.room, null);
                  setState(() {});
                },
                child: _NeuraArt(
                  onRiveInit: _onRiveInit,
                  onRiveError: () {
                    if (_riveOk) setState(() => _riveOk = false);
                  },
                ),
              ),
            );
          },
        );
      },
    );
  }

  void _onRiveInit(Artboard artboard) {
    try {
      final ctrl = StateMachineController.fromArtboard(artboard, _smName);
      if (ctrl == null) {
        setState(() => _riveOk = false);
        return;
      }
      artboard.addController(ctrl);
      _sm = ctrl;

      SMIInput<T>? find<T>(String name) {
        final i = ctrl.findInput(name);
        return i is SMIInput<T> ? i : null;
      }

      _isWalking = find<bool>('isWalking');
      _talkLevel = find<double>('talkLevel');
      _rest = find<double>('rest');
      _aa = find<double>('aa');
      _ee = find<double>('ee');
      _oo = find<double>('oo');
      _ff = find<double>('ff');
      _mm = find<double>('mm');

      // Default idle values.
      _talkLevel?.value = 0;
      _rest?.value = 0.9;
      _mm?.value = 0.1;
      _setWalking(false);
    } catch (_) {
      setState(() => _riveOk = false);
    }
  }
}

class _DraggableResident extends StatelessWidget {
  final Widget child;
  final bool riveOk;
  final ValueChanged<Offset> onDragDelta;
  final VoidCallback onSnapHome;

  const _DraggableResident({
    required this.child,
    required this.riveOk,
    required this.onDragDelta,
    required this.onSnapHome,
  });

  @override
  Widget build(BuildContext context) {
    // IMPORTANT: This should not eat all taps; it only responds when you drag Neura.
    return GestureDetector(
      onPanUpdate: (d) => onDragDelta(Offset(d.delta.dx, d.delta.dy)),
      onDoubleTap: onSnapHome,
      child: IgnorePointer(
        ignoring: false,
        child: Opacity(
          opacity: 0.95,
          child: Container(
            decoration: BoxDecoration(
              boxShadow: [
                BoxShadow(
                  blurRadius: 28,
                  spreadRadius: 2,
                  color: Colors.white.withOpacity(0.06),
                ),
              ],
            ),
            child: child,
          ),
        ),
      ),
    );
  }
}

class _NeuraArt extends StatelessWidget {
  final void Function(Artboard artboard) onRiveInit;
  final VoidCallback onRiveError;

  const _NeuraArt({required this.onRiveInit, required this.onRiveError});

  @override
  Widget build(BuildContext context) {
    // Keep size sane for phones/tablets.
    const double width = 240;
    const double height = 420;

    return SizedBox(
      width: width,
      height: height,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(18),
        child: Stack(
          children: [
            // Primary: Rive rig
            Positioned.fill(
              child: RiveAnimation.asset(
                kNeuraRiveAsset,
                fit: BoxFit.contain,
                onInit: onRiveInit,
                placeHolder: const SizedBox.shrink(),
                // If the .riv asset is missing, Rive throws during asset resolution.
                // We'll catch it via errorBuilder below.
                errorBuilder: (context, error, stack) {
                  onRiveError();
                  return _fallback(context);
                },
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _fallback(BuildContext context) {
    return Image.asset(
      kNeuraFallbackPng,
      fit: BoxFit.contain,
      errorBuilder: (_, __, ___) {
        // Ultimate fallback: just render a simple glyph.
        return Container(
          color: Colors.black.withOpacity(0.25),
          alignment: Alignment.center,
          child: Text(
            'NEURA',
            style: Theme.of(context).textTheme.titleLarge?.copyWith(fontWeight: FontWeight.w900),
          ),
        );
      },
    );
  }
}
